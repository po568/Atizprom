<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','production_manager','graphic_designer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$status = $_GET['status'] ?? '';
$where = ['1=1']; $params = []; $types = '';
if ($status) { $where[] = 'p.status=?'; $params[] = $status; $types .= 's'; }
$projects = $db->fetchAll("SELECT p.*, CONCAT(u.first_name,' ',u.last_name) as customer_name FROM projects p JOIN users u ON p.customer_id=u.id WHERE ".implode(' AND ',$where)." ORDER BY p.created_at DESC", $params, $types);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Projects – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Projects</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Projects</div></div>
    </div>
    <div class="header-actions">
      <a href="<?= BASE_URL ?>/admin/projects/create.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> New Project</a>
    </div>
  </div>
  <div class="content-body">
    <?php if (isset($_GET['created'])): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> Project created. A draft contract has also been generated automatically.</div><?php endif; ?>
    <div class="card">
      <div class="card-body">
        <div class="dt-filters mb-3">
          <a href="?" class="btn btn-sm <?= !$status?'btn-primary':'btn-outline-primary' ?>">All</a>
          <?php foreach (['pending'=>'Pending','approved'=>'Approved','in_progress'=>'In Progress','review'=>'Review','completed'=>'Completed','delivered'=>'Delivered','cancelled'=>'Cancelled'] as $k=>$v): ?>
          <a href="?status=<?= $k ?>" class="btn btn-sm <?= $status===$k?'btn-primary':'btn-outline-primary' ?>"><?= $v ?></a>
          <?php endforeach; ?>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Project #</th><th>Title</th><th>Customer</th><th>Progress</th><th>Deadline</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($projects as $p): ?>
              <tr>
                <td><strong style="color:var(--blue)"><?= $p['project_number'] ?></strong></td>
                <td><?= htmlspecialchars($p['title']) ?></td>
                <td><?= htmlspecialchars($p['customer_name']) ?></td>
                <td><div class="progress" style="width:100px;display:inline-block"><div class="progress-bar" style="width:<?= $p['progress'] ?>%"></div></div> <?= $p['progress'] ?>%</td>
                <td><?= $p['deadline'] ? formatDate($p['deadline']) : '-' ?></td>
                <td><?= getStatusBadge($p['status']) ?></td>
                <td><a href="<?= BASE_URL ?>/admin/projects/view.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-eye"></i> Manage</a></td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($projects)): ?>
              <tr><td colspan="7" class="text-center text-muted" style="padding:40px">No projects yet</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
