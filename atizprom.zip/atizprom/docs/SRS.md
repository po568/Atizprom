# Software Requirements Specification (SRS)
## Atiz Prom Company Management System

**Version:** 1.0 | **Date:** 2026 | **Prepared for:** Atiz Prom, Kyerwa, Kagera, Tanzania

---

## 1. Introduction

### 1.1 Purpose
This document specifies the requirements for the Atiz Prom Company Management System, a web-based platform unifying technology services, creative media production, computer training, and product advertisement management under a single system.

### 1.2 Scope
The system serves two primary user groups: **customers** (booking services, requesting quotes, enrolling in courses) and **staff/administrators** (managing operations across photography, videography, film production, graphics design, events, courses, products, finance, and projects).

### 1.3 Intended Audience
Developers, system administrators, Atiz Prom management and staff, and quality assurance personnel.

---

## 2. Overall Description

### 2.1 Product Perspective
A standalone, self-hosted web application built on PHP 8 / MySQL / Apache, deployable on XAMPP, with no dependency on external frameworks.

### 2.2 User Classes

| Role | Description |
|---|---|
| Super Admin | Full system access across all branches and modules |
| Admin | Manages customers, services, bookings, quotations, projects |
| Finance Officer | Revenue, invoices, payments, financial reporting |
| Production Manager | Film, photography, videography, events projects |
| Graphic Designer | Design requests and graphics projects |
| Course Instructor | Course content, lessons, assignments, exams |
| Inventory Officer | Product catalog and stock advertisement |
| Customer | Self-service booking, tracking, and account management |

### 2.3 Operating Environment
- Server: Apache 2.4+ (XAMPP bundled)
- Backend: PHP 8.0+
- Database: MySQL 5.7+ / MariaDB 10.4+
- Client: Modern web browsers (Chrome, Firefox, Edge, Safari), responsive on mobile devices

---

## 3. Functional Requirements

### 3.1 Authentication & Access Control
- FR-1: Users can register, log in, recover password, and verify email
- FR-2: System enforces RBAC across 8 distinct roles
- FR-3: Accounts lock after 5 failed login attempts for 30 minutes
- FR-4: All sessions expire after 2 hours of inactivity

### 3.2 Booking Management
- FR-5: Customers can book photography, videography, film, design, and event coverage services
- FR-6: Bookings capture date, time, venue, guest count, and special requirements
- FR-7: Staff can update booking status (pending → confirmed → in progress → completed)

### 3.3 Quotation Management
- FR-8: Customers can request itemized quotations with attachments
- FR-9: System auto-generates sequential quotation numbers
- FR-10: Quotations support approve/reject workflows with expiry dates

### 3.4 Project Tracking
- FR-11: Projects link to bookings/quotations and track milestones, deadlines, and file deliverables
- FR-12: Customers view real-time progress percentages and status

### 3.5 Course Management
- FR-13: Students enroll in online/offline/hybrid courses across 8 categories
- FR-14: System supports lessons, assignments, quizzes, and certificate issuance

### 3.6 E-Commerce Advertisement (Non-Transactional)
- FR-15: Products are browsable by category with price and stock status
- FR-16: No online purchasing is permitted; customers may only request quotations

### 3.7 Support & Communication
- FR-17: Ticketing system with categorized, prioritized support requests
- FR-18: Real-time chat sessions between customers and staff
- FR-19: Email notifications for key events (booking, payment, enrollment, etc.)

### 3.8 Financial Management
- FR-20: Invoice generation with line items, tax, and discount calculation
- FR-21: Payment recording across Cash, M-Pesa, Airtel Money, Tigo Pesa, HaloPesa, Bank Transfer
- FR-22: Revenue dashboards with monthly/annual reporting

---

## 4. Non-Functional Requirements

| Category | Requirement |
|---|---|
| Performance | Page load under 2 seconds on standard broadband |
| Security | Bcrypt hashing, prepared statements, CSRF/XSS protection |
| Usability | Mobile-responsive, accessible navigation, consistent branding |
| Scalability | Multi-branch architecture supports future branch additions |
| Availability | Designed for continuous operation on standard Apache hosting |
| Maintainability | Modular PHP classes, documented codebase, no framework lock-in |

---

## 5. External Interface Requirements

- **Email:** SMTP (Gmail-compatible) for transactional notifications
- **Payment Confirmation:** Manual recording (no live payment gateway integration per requirements — cash-first model)
- **Social Media:** Outbound links to Facebook, Instagram, TikTok, YouTube (Atiz Prom Arts)

---

## 6. Appendix: Data Dictionary Summary

See `database/atizprom.sql` for full schema. Key entities: `users`, `roles`, `branches`, `services`, `bookings`, `quotations`, `projects`, `invoices`, `payments`, `courses`, `course_enrollments`, `products`, `portfolio`, `tickets`, `contracts`.
