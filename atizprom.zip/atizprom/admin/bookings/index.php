<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','production_manager']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();

// Filters
$status  = $_GET['status'] ?? '';
$search  = $_GET['search'] ?? '';
$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$offset  = ($page - 1) * $perPage;

$where = ['1=1']; $params = []; $types = '';
if ($status) { $where[] = 'b.status = ?'; $params[] = $status; $types .= 's'; }
if ($search) { $where[] = "(b.booking_number LIKE ? OR CONCAT(u.first_name,' ',u.last_name) LIKE ? OR s.name LIKE ?)"; $q='%'.$search.'%'; $params=array_merge($params,[$q,$q,$q]); $types.='sss'; }

$whereStr = implode(' AND ', $where);
$totalRows= $db->fetchOne("SELECT COUNT(*) as c FROM bookings b JOIN users u ON b.customer_id=u.id JOIN services s ON b.service_id=s.id WHERE $whereStr", $params, $types)['c'] ?? 0;
$totalPages = ceil($totalRows / $perPage);

$params[] = $perPage; $params[] = $offset; $types .= 'ii';
$bookings = $db->fetchAll("SELECT b.*, s.name as service_name, sc.name as category, CONCAT(u.first_name,' ',u.last_name) as customer_name, u.email as customer_email, u.phone as customer_phone FROM bookings b JOIN users u ON b.customer_id=u.id JOIN services s ON b.service_id=s.id JOIN service_categories sc ON s.category_id=sc.id WHERE $whereStr ORDER BY b.created_at DESC LIMIT ? OFFSET ?", $params, $types);

$notifCount = getNotificationCount($user['id']);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bookings – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div>
        <div class="header-title">Bookings</div>
        <div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Bookings</div>
      </div>
    </div>
    <div class="header-actions">
      <a href="<?= BASE_URL ?>/admin/notifications.php" class="header-icon-btn">
        <i class="fas fa-bell"></i><?php if ($notifCount > 0): ?><span class="notif-badge"><?= $notifCount ?></span><?php endif; ?>
      </a>
      <a href="<?= BASE_URL ?>/admin/bookings/create.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> New Booking</a>
    </div>
  </div>
  <div class="content-body">
    <div class="card">
      <div class="card-body">
        <!-- TOOLBAR -->
        <div class="dt-toolbar">
          <form method="GET" class="d-flex gap-2" style="flex-wrap:wrap;flex:1">
            <div class="dt-search">
              <i class="fas fa-search"></i>
              <input type="text" name="search" class="form-control" placeholder="Search bookings..." value="<?= htmlspecialchars($search) ?>">
            </div>
            <select name="status" class="form-control" style="width:auto" onchange="this.form.submit()">
              <option value="">All Status</option>
              <?php foreach (['pending','confirmed','in_progress','completed','cancelled'] as $s): ?>
              <option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">Filter</button>
            <a href="<?= BASE_URL ?>/admin/bookings/" class="btn btn-sm" style="border:1px solid var(--border)">Clear</a>
          </form>
          <div class="d-flex gap-2">
            <button onclick="Admin.exportTable('bookingsTable','bookings')" class="btn btn-sm" style="border:1px solid var(--border)"><i class="fas fa-download"></i> Export</button>
          </div>
        </div>

        <div class="table-wrap">
          <table class="table" id="bookingsTable">
            <thead>
              <tr>
                <th>Booking #</th><th>Customer</th><th>Service</th><th>Category</th>
                <th>Event Date</th><th>Amount</th><th>Status</th><th>Created</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($bookings as $b): ?>
              <tr>
                <td><strong style="color:var(--blue)"><?= $b['booking_number'] ?></strong></td>
                <td>
                  <div style="font-weight:600"><?= htmlspecialchars($b['customer_name']) ?></div>
                  <small class="text-muted"><?= htmlspecialchars($b['customer_email']) ?></small>
                </td>
                <td><?= htmlspecialchars($b['service_name']) ?></td>
                <td><?= htmlspecialchars($b['category']) ?></td>
                <td><?= $b['event_date'] ? formatDate($b['event_date']) : '<span class="text-muted">-</span>' ?></td>
                <td><?= $b['total_amount'] ? formatCurrency($b['total_amount']) : '<span class="text-muted">Pending</span>' ?></td>
                <td><?= getStatusBadge($b['status']) ?></td>
                <td><?= timeAgo($b['created_at']) ?></td>
                <td>
                  <div class="d-flex gap-1">
                    <a href="<?= BASE_URL ?>/admin/bookings/view.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-eye"></i></a>
                    <a href="<?= BASE_URL ?>/admin/bookings/view.php?id=<?= $b['id'] ?>" class="btn btn-sm" style="border:1px solid var(--border)"><i class="fas fa-edit"></i></a>
                    <?php if (in_array($b['status'], ['confirmed','in_progress','completed'])): ?>
                    <a href="<?= BASE_URL ?>/admin/invoices/create.php?booking_id=<?= $b['id'] ?>" class="btn btn-sm btn-primary" title="Create Invoice"><i class="fas fa-file-invoice-dollar"></i></a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($bookings)): ?>
              <tr><td colspan="9" class="text-center text-muted" style="padding:40px">
                <i class="fas fa-calendar-times" style="font-size:2rem;display:block;margin-bottom:10px;opacity:0.3"></i>
                No bookings found
              </td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <!-- PAGINATION -->
        <?php if ($totalPages > 1): ?>
        <div class="d-flex justify-content-between align-items-center mt-3">
          <small class="text-muted">Showing <?= min($offset+1,$totalRows) ?>–<?= min($offset+$perPage,$totalRows) ?> of <?= $totalRows ?> bookings</small>
          <div class="pagination">
            <?php if ($page > 1): ?>
            <a href="?page=<?= $page-1 ?>&status=<?= $status ?>&search=<?= urlencode($search) ?>" class="page-btn"><i class="fas fa-chevron-left"></i></a>
            <?php endif; ?>
            <?php for ($i=max(1,$page-2);$i<=min($totalPages,$page+2);$i++): ?>
            <a href="?page=<?= $i ?>&status=<?= $status ?>&search=<?= urlencode($search) ?>" class="page-btn <?= $i===$page?'active':'' ?>"><?= $i ?></a>
            <?php endfor; ?>
            <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page+1 ?>&status=<?= $status ?>&search=<?= urlencode($search) ?>" class="page-btn"><i class="fas fa-chevron-right"></i></a>
            <?php endif; ?>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
