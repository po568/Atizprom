<?php
// =====================================================
// ATIZ PROM - Authentication Class
// =====================================================

class Auth {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
        if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
            $this->startSecureSession();
        }
    }

    private function startSecureSession() {
        // These ini_set calls only work before headers are sent; if something
        // upstream (a stray output, a misconfigured php.ini auto-start, etc.)
        // already sent headers, skip silently rather than emit warnings that
        // can clutter logs and, on some setups, cascade into worse failures.
        if (!headers_sent()) {
            @ini_set('session.cookie_httponly', 1);
            @ini_set('session.cookie_secure', 0);
            @ini_set('session.use_strict_mode', 1);
            @session_start();
        }
    }

    public function login($email, $password) {
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'message' => 'Invalid email format.'];
        }

        $ip = $this->getIP();

        // Check lockout
        $user = $this->db->fetchOne("SELECT * FROM users WHERE email = ?", [$email]);
        if ($user && $user['locked_until'] && strtotime($user['locked_until']) > time()) {
            $remaining = ceil((strtotime($user['locked_until']) - time()) / 60);
            $this->logLogin(null, $email, 'locked', $ip);
            return ['success' => false, 'message' => "Account locked. Try again in {$remaining} minutes."];
        }

        if (!$user || !$user['is_active']) {
            $this->logLogin(null, $email, 'failed', $ip);
            return ['success' => false, 'message' => 'Invalid email or password.'];
        }

        if (!password_verify($password, $user['password'])) {
            $attempts = $user['login_attempts'] + 1;
            $lockUntil = null;
            if ($attempts >= MAX_LOGIN_ATTEMPTS) {
                $lockUntil = date('Y-m-d H:i:s', time() + LOCKOUT_DURATION);
            }
            $this->db->execute(
                "UPDATE users SET login_attempts = ?, locked_until = ? WHERE id = ?",
                [$attempts, $lockUntil, $user['id']], 'isi'
            );
            $this->logLogin($user['id'], $email, 'failed', $ip);
            return ['success' => false, 'message' => 'Invalid email or password.'];
        }

        if (!$user['email_verified']) {
            return ['success' => false, 'message' => 'Please verify your email first.'];
        }

        // Reset attempts, update last login
        $this->db->execute(
            "UPDATE users SET login_attempts = 0, locked_until = NULL, last_login = NOW() WHERE id = ?",
            [$user['id']], 'i'
        );

        // Set session
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role_id'];
        $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
        $_SESSION['user_picture'] = $user['profile_picture'];
        $_SESSION['branch_id'] = $user['branch_id'];
        $_SESSION['login_time'] = time();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

        $this->logLogin($user['id'], $email, 'success', $ip);
        $this->logAudit($user['id'], 'USER_LOGIN', 'users', $user['id']);

        $role = $this->db->fetchOne("SELECT slug FROM roles WHERE id = ?", [$user['role_id']]);
        return [
            'success' => true,
            'message' => 'Login successful.',
            'role' => $role['slug'],
            'redirect' => $role['slug'] === 'customer' ? BASE_URL . '/customer/' : BASE_URL . '/admin/'
        ];
    }

    public function register($data) {
        $email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'message' => 'Invalid email format.'];
        }

        $existing = $this->db->fetchOne("SELECT id FROM users WHERE email = ?", [$email]);
        if ($existing) {
            return ['success' => false, 'message' => 'Email already registered.'];
        }

        $password = $data['password'];
        if (strlen($password) < 8) {
            return ['success' => false, 'message' => 'Password must be at least 8 characters.'];
        }

        $hashed = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
        $token = bin2hex(random_bytes(32));

        $id = $this->db->insert(
            "INSERT INTO users (role_id, first_name, last_name, email, phone, password, verification_token, email_verified) VALUES (8, ?, ?, ?, ?, ?, ?, 1)",
            [$data['first_name'], $data['last_name'], $email, $data['phone'] ?? '', $hashed, $token]
        );

        if ($id) {
            $this->logAudit($id, 'USER_REGISTER', 'users', $id);
            return ['success' => true, 'message' => 'Registration successful! You can now login.'];
        }
        return ['success' => false, 'message' => 'Registration failed. Please try again.'];
    }

    public function logout() {
        if (isset($_SESSION['user_id'])) {
            $this->logAudit($_SESSION['user_id'], 'USER_LOGOUT', 'users', $_SESSION['user_id']);
        }
        session_unset();
        session_destroy();
        header('Location: ' . BASE_URL . '/');
        exit;
    }

    public function isLoggedIn() {
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['login_time'])) return false;
        if (time() - $_SESSION['login_time'] > SESSION_TIMEOUT) {
            $this->logout();
            return false;
        }
        $_SESSION['login_time'] = time();
        return true;
    }

    public function requireLogin($redirect = null) {
        if (!$this->isLoggedIn()) {
            $redirect = $redirect ?? BASE_URL . '/';
            header('Location: ' . $redirect);
            exit;
        }
    }

    public function requireRole($roles) {
        if (!is_array($roles)) $roles = [$roles];
        $roleMap = [1=>'super_admin',2=>'admin',3=>'finance_officer',4=>'production_manager',5=>'graphic_designer',6=>'course_instructor',7=>'inventory_officer',8=>'customer'];
        $userRole = $roleMap[$_SESSION['user_role']] ?? 'customer';
        if (!in_array($userRole, $roles)) {
            header('Location: ' . BASE_URL . '/');
            exit;
        }
    }

    public function isAdmin() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] <= 7;
    }

    public function isSuperAdmin() {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] == 1;
    }

    public function getCSRFToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    public function validateCSRF($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }

    public function getCurrentUser() {
        if (!$this->isLoggedIn()) return null;
        return $this->db->fetchOne("SELECT u.*, r.name as role_name, r.slug as role_slug, b.name as branch_name FROM users u JOIN roles r ON u.role_id = r.id LEFT JOIN branches b ON u.branch_id = b.id WHERE u.id = ?", [$_SESSION['user_id']]);
    }

    private function getIP() {
        foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_X_REAL_IP','REMOTE_ADDR'] as $key) {
            if (!empty($_SERVER[$key])) return trim(explode(',', $_SERVER[$key])[0]);
        }
        return '0.0.0.0';
    }

    private function logLogin($userId, $email, $status, $ip) {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $this->db->execute(
            "INSERT INTO login_logs (user_id, email, status, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)",
            [$userId, $email, $status, $ip, $ua]
        );
    }

    public function logAudit($userId, $action, $table = null, $recordId = null, $old = null, $new = null) {
        $ip = $this->getIP();
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $this->db->execute(
            "INSERT INTO audit_logs (user_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent) VALUES (?,?,?,?,?,?,?,?)",
            [$userId, $action, $table, $recordId, $old ? json_encode($old) : null, $new ? json_encode($new) : null, $ip, $ua]
        );
    }

    public function generateNumber($prefix, $table, $column) {
        $year = date('Y');
        $month = date('m');
        $count = $this->db->fetchOne("SELECT COUNT(*) as c FROM $table WHERE YEAR(created_at)=? AND MONTH(created_at)=?", [$year, $month]);
        $seq = str_pad(($count['c'] ?? 0) + 1, 4, '0', STR_PAD_LEFT);
        return $prefix . $year . $month . $seq;
    }
}
