<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','finance_officer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$method = $_GET['method'] ?? '';
$where = ['1=1']; $params = []; $types = '';
if ($method) { $where[] = 'p.payment_method=?'; $params[] = $method; $types .= 's'; }

$payments = $db->fetchAll(
    "SELECT p.*, i.invoice_number, CONCAT(u.first_name,' ',u.last_name) as customer_name
     FROM payments p
     JOIN invoices i ON p.invoice_id=i.id
     JOIN users u ON p.customer_id=u.id
     WHERE ".implode(' AND ',$where)." ORDER BY p.payment_date DESC, p.created_at DESC",
    $params, $types
);
$totalCollected = $db->fetchOne("SELECT COALESCE(SUM(amount),0) as t FROM payments WHERE status='confirmed'")['t'] ?? 0;
$thisMonth = $db->fetchOne("SELECT COALESCE(SUM(amount),0) as t FROM payments WHERE status='confirmed' AND MONTH(payment_date)=MONTH(CURDATE()) AND YEAR(payment_date)=YEAR(CURDATE())")['t'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payments – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Payments</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Payments</div></div>
    </div>
  </div>
  <div class="content-body">
    <div class="stats-grid mb-3">
      <div class="stat-card"><div class="stat-icon green"><i class="fas fa-coins"></i></div><div class="stat-info"><strong><?= formatCurrency($totalCollected) ?></strong><span>Total Collected</span></div></div>
      <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-calendar-check"></i></div><div class="stat-info"><strong><?= formatCurrency($thisMonth) ?></strong><span>This Month</span></div></div>
    </div>
    <div class="card">
      <div class="card-body">
        <div class="dt-filters mb-3">
          <a href="?" class="btn btn-sm <?= !$method?'btn-primary':'btn-outline-primary' ?>">All Methods</a>
          <?php foreach (['cash'=>'Cash','mpesa'=>'M-Pesa','airtel_money'=>'Airtel Money','tigo_pesa'=>'Tigo Pesa','halopesa'=>'HaloPesa','bank_transfer'=>'Bank Transfer'] as $k=>$v): ?>
          <a href="?method=<?= $k ?>" class="btn btn-sm <?= $method===$k?'btn-primary':'btn-outline-primary' ?>"><?= $v ?></a>
          <?php endforeach; ?>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Date</th><th>Customer</th><th>Invoice</th><th>Amount</th><th>Method</th><th>Reference</th><th>Status</th></tr></thead>
            <tbody>
              <?php foreach ($payments as $p): ?>
              <tr>
                <td><?= formatDate($p['payment_date']) ?></td>
                <td><?= htmlspecialchars($p['customer_name']) ?></td>
                <td><a href="<?= BASE_URL ?>/admin/invoices/view.php?id=<?= $p['invoice_id'] ?>" style="color:var(--blue)"><?= $p['invoice_number'] ?></a></td>
                <td style="color:#155724"><strong><?= formatCurrency($p['amount']) ?></strong></td>
                <td><?= htmlspecialchars(ucfirst(str_replace('_',' ',$p['payment_method']))) ?></td>
                <td><?= htmlspecialchars($p['transaction_ref'] ?: '-') ?></td>
                <td><?= getStatusBadge($p['status']) ?></td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($payments)): ?>
              <tr><td colspan="7" class="text-center text-muted" style="padding:40px">No payments recorded yet — payments are added from an invoice's detail page</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
