<?php
// Admin Sidebar - shared across all admin pages, role-aware navigation
$currentPage = basename($_SERVER['PHP_SELF']);
$currentDir  = basename(dirname($_SERVER['PHP_SELF']));
$roleId = $_SESSION['user_role'] ?? 8;

// Role groups for nav visibility
$isExecutive = in_array($roleId, [1,2,3]);     // super_admin, admin, finance_officer
$isFinance   = in_array($roleId, [1,2,3]);     // finance_officer + admins
$isProduction= in_array($roleId, [1,2,4]);     // production_manager + admins
$isDesigner  = in_array($roleId, [1,2,5]);     // graphic_designer + admins
$isInstructor= in_array($roleId, [1,2,6]);     // course_instructor + admins
$isInventory = in_array($roleId, [1,2,7]);     // inventory_officer + admins
$isSuperOrAdmin = in_array($roleId, [1,2]);
$isSuper     = $roleId == 1;
?>
<div class="sidebar-brand">
  <div class="sidebar-brand-inner">
    <a href="<?= BASE_URL ?>/admin/" class="sidebar-logo" style="text-decoration:none">
      <div class="logo-icon" style="width:38px;height:38px;border-radius:8px;font-size:0.85rem">
        <img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo">
      </div>
      <div class="logo-text">
        <strong style="color:#fff;font-size:0.95rem">ATIZ PROM</strong>
        <small style="color:rgba(255,255,255,0.5);font-size:0.65rem"><?= t('admin_panel_label') ?></small>
      </div>
    </a>
    <button class="sidebar-toggle-btn" id="sidebarToggle" title="<?= t('admin_toggle_sidebar') ?>">
      <i class="fas fa-chevron-left"></i>
    </button>
  </div>
</div>

<nav class="sidebar-nav">

  <!-- MAIN -->
  <div class="nav-section-title"><?= t('sidebar_main') ?></div>
  <a href="<?= BASE_URL ?>/admin/" class="sidebar-link <?= $currentDir==='admin'&&$currentPage==='index.php'?'active':'' ?>">
    <i class="fas fa-tachometer-alt"></i> <?= t('nav_dashboard') ?>
  </a>

  <?php if ($isSuperOrAdmin): ?>
  <!-- SERVICES (Admin/Super Admin only) -->
  <div class="nav-section-title"><?= t('sidebar_catalog') ?></div>
  <a href="<?= BASE_URL ?>/admin/services/" class="sidebar-link <?= $currentDir==='services'?'active':'' ?>">
    <i class="fas fa-concierge-bell"></i> <?= t('sidebar_services') ?>
  </a>
  <?php endif; ?>

  <?php if ($isSuperOrAdmin): ?>
  <!-- CRM (Admin roles only — finance does not manage customers/bookings/contracts directly) -->
  <div class="nav-section-title"><?= t('sidebar_crm') ?></div>
  <a href="<?= BASE_URL ?>/admin/customers/" class="sidebar-link <?= $currentDir==='customers'?'active':'' ?>">
    <i class="fas fa-users"></i> <?= t('sidebar_customers') ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/bookings/" class="sidebar-link <?= $currentDir==='bookings'?'active':'' ?>">
    <i class="fas fa-calendar-check"></i> <?= t('sidebar_bookings') ?>
    <?php $pb = Database::getInstance()->fetchOne("SELECT COUNT(*) c FROM bookings WHERE status='pending'")['c'] ?? 0; if ($pb > 0): ?>
    <span class="badge"><?= $pb ?></span>
    <?php endif; ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/contracts/" class="sidebar-link <?= $currentDir==='contracts'?'active':'' ?>">
    <i class="fas fa-file-signature"></i> <?= t('sidebar_contracts') ?>
  </a>
  <?php endif; ?>

  <?php if ($isExecutive): ?>
  <!-- Quotations: finance officers give final pricing approval here, so they keep this link -->
  <div class="nav-section-title"><?= t('sidebar_quotations') ?></div>
  <a href="<?= BASE_URL ?>/admin/quotations/" class="sidebar-link <?= $currentDir==='quotations'?'active':'' ?>">
    <i class="fas fa-file-invoice"></i> <?= t('sidebar_quotations') ?>
  </a>
  <?php endif; ?>

  <?php if ($isProduction): ?>
  <!-- PRODUCTION (Production Manager + Executives) -->
  <div class="nav-section-title"><?= t('sidebar_production') ?></div>
  <a href="<?= BASE_URL ?>/admin/bookings/" class="sidebar-link <?= $currentDir==='bookings'?'active':'' ?>">
    <i class="fas fa-calendar-check"></i> <?= t('admin_service_bookings') ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/projects/" class="sidebar-link <?= $currentDir==='projects'?'active':'' ?>">
    <i class="fas fa-project-diagram"></i> <?= t('sidebar_projects') ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/portfolio/" class="sidebar-link <?= $currentDir==='portfolio'?'active':'' ?>">
    <i class="fas fa-images"></i> <?= t('nav_portfolio') ?>
  </a>
  <?php endif; ?>

  <?php if ($isDesigner && !$isProduction): ?>
  <!-- DESIGN (Graphic Designer + Executives, if not already shown via Production) -->
  <div class="nav-section-title"><?= t('sidebar_design') ?></div>
  <a href="<?= BASE_URL ?>/admin/projects/" class="sidebar-link <?= $currentDir==='projects'?'active':'' ?>">
    <i class="fas fa-project-diagram"></i> <?= t('admin_design_projects') ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/portfolio/" class="sidebar-link <?= $currentDir==='portfolio'?'active':'' ?>">
    <i class="fas fa-images"></i> <?= t('nav_portfolio') ?>
  </a>
  <?php elseif ($isDesigner && $isProduction && !$isExecutive): ?>
  <a href="<?= BASE_URL ?>/admin/portfolio/" class="sidebar-link <?= $currentDir==='portfolio'?'active':'' ?>">
    <i class="fas fa-palette"></i> <?= t('admin_design_portfolio') ?>
  </a>
  <?php endif; ?>

  <?php if ($isInstructor): ?>
  <!-- COURSES (Course Instructor + Executives) -->
  <div class="nav-section-title"><?= t('sidebar_training') ?></div>
  <a href="<?= BASE_URL ?>/admin/courses/" class="sidebar-link <?= $currentDir==='courses'?'active':'' ?>">
    <i class="fas fa-graduation-cap"></i> <?= t('sidebar_my_courses') ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/enrollments/" class="sidebar-link <?= $currentDir==='enrollments'?'active':'' ?>">
    <i class="fas fa-user-graduate"></i> <?= t('sidebar_enrollment_requests') ?>
  </a>
  <?php elseif ($roleId == 3): ?>
  <!-- Finance officer needs enrollment access too, even though they don't see the Training section above -->
  <div class="nav-section-title"><?= t('sidebar_training') ?></div>
  <a href="<?= BASE_URL ?>/admin/enrollments/" class="sidebar-link <?= $currentDir==='enrollments'?'active':'' ?>">
    <i class="fas fa-user-graduate"></i> <?= t('sidebar_enrollment_requests') ?>
  </a>
  <?php endif; ?>

  <?php if ($isInventory): ?>
  <!-- INVENTORY (Inventory Officer + Executives) -->
  <div class="nav-section-title"><?= t('sidebar_inventory') ?></div>
  <a href="<?= BASE_URL ?>/admin/products/" class="sidebar-link <?= $currentDir==='products'?'active':'' ?>">
    <i class="fas fa-box-open"></i> <?= t('sidebar_product_catalog') ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/products/records.php" class="sidebar-link <?= $currentPage==='records.php'?'active':'' ?>">
    <i class="fas fa-clipboard-list"></i> <?= t('sidebar_stock_records') ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/products/reports.php" class="sidebar-link <?= $currentPage==='reports.php'?'active':'' ?>">
    <i class="fas fa-chart-line"></i> <?= t('sidebar_sales_report') ?>
  </a>
  <?php endif; ?>

  <?php if ($isSuperOrAdmin): ?>
  <!-- SUPPORT (Admin roles only — finance has no ticket-handling function) -->
  <div class="nav-section-title"><?= t('sidebar_support') ?></div>
  <a href="<?= BASE_URL ?>/admin/tickets/" class="sidebar-link <?= $currentDir==='tickets'?'active':'' ?>">
    <i class="fas fa-headset"></i> <?= t('sidebar_support_tickets') ?>
    <?php $ot = Database::getInstance()->fetchOne("SELECT COUNT(*) c FROM tickets WHERE status='open'")['c'] ?? 0; if ($ot > 0): ?>
    <span class="badge"><?= $ot ?></span>
    <?php endif; ?>
  </a>
  <?php endif; ?>

  <?php if ($isFinance): ?>
  <!-- FINANCE -->
  <div class="nav-section-title"><?= t('sidebar_finance') ?></div>
  <a href="<?= BASE_URL ?>/admin/invoices/" class="sidebar-link <?= $currentDir==='invoices'?'active':'' ?>">
    <i class="fas fa-receipt"></i> <?= t('sidebar_invoices') ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/payments/" class="sidebar-link <?= $currentDir==='payments'?'active':'' ?>">
    <i class="fas fa-money-bill-wave"></i> <?= t('sidebar_payments') ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/reports/" class="sidebar-link <?= $currentDir==='reports'?'active':'' ?>">
    <i class="fas fa-chart-bar"></i> <?= t('sidebar_reports') ?>
  </a>
  <?php endif; ?>

  <?php if ($isSuperOrAdmin): ?>
  <!-- ADMINISTRATION -->
  <div class="nav-section-title"><?= t('sidebar_administration') ?></div>
  <a href="<?= BASE_URL ?>/admin/users/" class="sidebar-link <?= $currentDir==='users'?'active':'' ?>">
    <i class="fas fa-user-cog"></i> <?= t('sidebar_users_roles') ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/branches/" class="sidebar-link <?= $currentDir==='branches'?'active':'' ?>">
    <i class="fas fa-building"></i> <?= t('sidebar_branches') ?>
  </a>
  <?php endif; ?>
  <?php if ($isSuper): ?>
  <a href="<?= BASE_URL ?>/admin/settings/" class="sidebar-link <?= $currentDir==='settings'?'active':'' ?>">
    <i class="fas fa-sliders-h"></i> <?= t('sidebar_settings') ?>
  </a>
  <?php endif; ?>

  <!-- ACCOUNT -->
  <div class="nav-section-title"><?= t('sidebar_account') ?></div>
  <a href="<?= BASE_URL ?>/admin/profile.php" class="sidebar-link <?= $currentPage==='profile.php'?'active':'' ?>">
    <i class="fas fa-user-circle"></i> <?= t('nav_my_profile') ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/notifications.php" class="sidebar-link">
    <i class="fas fa-bell"></i> <?= t('nav_notifications') ?>
  </a>
  <a href="<?= BASE_URL ?>/admin/logout.php" class="sidebar-link" style="color:rgba(255,100,100,0.8)">
    <i class="fas fa-sign-out-alt"></i> <?= t('nav_logout') ?>
  </a>

  <div style="padding:20px;margin-top:auto">
    <div style="background:rgba(255,193,7,0.1);border:1px solid rgba(255,193,7,0.2);border-radius:10px;padding:14px;text-align:center">
      <small style="color:rgba(255,255,255,0.5);font-size:0.75rem"><?= t('admin_version_label') ?></small><br>
      <a href="<?= BASE_URL ?>" target="_blank" style="color:var(--yellow);font-size:0.78rem"><i class="fas fa-external-link-alt"></i> <?= t('sidebar_view_website') ?></a>
    </div>
  </div>
</nav>
