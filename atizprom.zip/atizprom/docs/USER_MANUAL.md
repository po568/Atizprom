# User Manual – Atiz Prom Customer Portal

## 1. Creating an Account
1. Visit the homepage and click **Get Started** or **Login → Create Free Account**
2. Fill in your name, email, phone, and a secure password (minimum 8 characters)
3. Agree to the Terms of Service and submit
4. Log in immediately with your new credentials

## 2. Booking a Service
1. From your dashboard, click **Book a Service**
2. Select a service category and specific service (e.g., Wedding Photography)
3. Choose your event date, time, venue, and guest count
4. Add any special requirements and optionally attach reference files
5. Submit — our team will confirm within 24 hours

## 3. Requesting a Quotation
1. Navigate to **Request Quotation**
2. Enter a title and description of what you need
3. Optionally add an itemized list with quantities and estimated prices
4. Attach supporting documents if needed
5. Submit and await our priced response in **My Quotations**

## 4. Tracking Projects
- Visit **My Projects** to see all active and completed work
- Each project displays a progress bar, milestones, and status (Pending → Approved → In Progress → Review → Completed → Delivered)

## 5. Enrolling in Courses
1. Browse **Courses** by category (Computer Basics, Microsoft Office, Web Development, etc.)
2. Click a course to view syllabus, requirements, and pricing
3. Click **Enroll Now** — our team will follow up with payment instructions
4. Once active, access lessons and materials via **My Courses**

## 6. Browsing the Product Catalog
- Visit **Products Catalog** to view office supplies, stationery, technology products, and printing materials
- **Note:** Online purchase is not available. Click **Request Quote** on any product to inquire about ordering

## 7. Getting Support
- **Support Tickets:** Open a ticket under Category (Inquiry, Complaint, Technical, Billing) and Priority level; reply within the ticket thread
- **Live Chat:** Use the chat icon in the header for real-time assistance

## 8. Managing Your Profile
- Update your name, phone, and address under **My Profile → Personal Info**
- Change your password under **My Profile → Security**
- View your login and activity history under the respective tabs

## 9. Invoices & Contracts
- View invoices issued for your bookings/projects under **Invoices**
- Review and digitally sign service contracts under **Contracts**

---
For further assistance, contact **atizpromltd@gmail.com** or open a support ticket.
