<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$db = Database::getInstance();

$isLoggedIn = $auth->isLoggedIn();
$user = $isLoggedIn ? $auth->getCurrentUser() : null;

$courseId = (int)($_GET['id'] ?? 0);
$category = $_GET['category'] ?? '';
$search   = $_GET['search'] ?? '';

$success = ''; $error = '';

// Handle enrollment
if ($isLoggedIn && $user && isPost() && isset($_POST['enroll_course_id'])) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) { $error = 'Invalid token.'; }
    else {
        $cId = (int)$_POST['enroll_course_id'];
        $existing = $db->fetchOne("SELECT id FROM course_enrollments WHERE course_id=? AND student_id=?", [$cId,$user['id']]);
        if ($existing) { $error = 'You are already enrolled in this course.'; }
        else {
            $enrollNum = $auth->generateNumber('EN','course_enrollments','enrollment_number');
            $id = $db->insert("INSERT INTO course_enrollments (course_id,student_id,enrollment_number,status) VALUES (?,?,?,'pending')", [$cId,$user['id'],$enrollNum]);
            if ($id) {
                $auth->logAudit($user['id'],'COURSE_ENROLL','course_enrollments',$id);
                $success = 'Enrollment request submitted! We will confirm your enrollment and provide payment details shortly.';
            } else $error = 'Enrollment failed.';
        }
    }
}

if ($courseId) {
    $course = $db->fetchOne("SELECT c.*, u.first_name, u.last_name FROM courses c LEFT JOIN users u ON c.instructor_id=u.id WHERE c.id=? AND c.is_active=1", [$courseId]);
    $lessons = $db->fetchAll("SELECT * FROM course_lessons WHERE course_id=? AND is_active=1 ORDER BY sort_order", [$courseId]);
    $myEnrollment = $isLoggedIn ? $db->fetchOne("SELECT * FROM course_enrollments WHERE course_id=? AND student_id=?", [$courseId,$user['id']]) : null;
} else {
    $course = null;
    $where = ['c.is_active=1']; $params = []; $types = '';
    if ($category) { $where[] = 'c.category=?'; $params[]=$category; $types.='s'; }
    if ($search) { $where[] = '(c.title LIKE ? OR c.description LIKE ?)'; $q='%'.$search.'%'; $params=array_merge($params,[$q,$q]); $types.='ss'; }
    $courses = $db->fetchAll("SELECT c.*, u.first_name as instructor_fname, u.last_name as instructor_lname, (SELECT COUNT(*) FROM course_enrollments WHERE course_id=c.id AND status='active') as enrolled_count FROM courses c LEFT JOIN users u ON c.instructor_id=u.id WHERE ".implode(' AND ',$where)." ORDER BY c.is_featured DESC, c.created_at DESC", $params, $types);
}

$catLabels = ['computer_basics'=>'Computer Basics','microsoft_office'=>'Microsoft Office','graphic_design'=>'Graphic Design','web_development'=>'Web Development','video_editing'=>'Video Editing','networking'=>'Networking','programming'=>'Programming','digital_marketing'=>'Digital Marketing'];
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $course ? htmlspecialchars($course['title']) : 'Courses' ?> – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php if ($isLoggedIn && $user && $user['role_slug']==='customer'): ?>
<?php include __DIR__ . '/includes/header.php'; ?>
<div class="customer-layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="customer-main">
<?php else: ?>
<nav class="navbar"><div class="container"><a href="<?= BASE_URL ?>" class="navbar-brand"><div class="logo-icon"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div><div class="logo-text"><strong>ATIZ PROM</strong></div></a></div></nav>
<div style="background:#F0F2F5;min-height:calc(100vh - 60px)"><main>
<?php endif; ?>

<div class="customer-content">
  <?php if ($success): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
  <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>

  <?php if ($course): ?>
  <!-- SINGLE COURSE VIEW -->
  <div style="max-width:900px">
    <a href="<?= BASE_URL ?>/customer/courses.php" style="font-size:0.85rem;color:var(--text-muted)"><i class="fas fa-arrow-left"></i> Back to Courses</a>
    <div style="margin-top:20px;display:grid;grid-template-columns:2fr 1fr;gap:30px;align-items:start">
      <div>
        <div class="section-tag mb-2"><?= $catLabels[$course['category']] ?? $course['category'] ?></div>
        <h2 style="margin-bottom:12px"><?= htmlspecialchars($course['title']) ?></h2>
        <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:0.85rem;color:var(--text-muted);margin-bottom:20px">
          <span><i class="fas fa-clock"></i> <?= htmlspecialchars($course['duration'] ?? 'Flexible') ?></span>
          <span><i class="fas <?= $course['mode']==='online'?'fa-wifi':($course['mode']==='hybrid'?'fa-laptop':'fa-school') ?>"></i> <?= ucfirst($course['mode']) ?></span>
          <?php if ($course['first_name']): ?><span><i class="fas fa-chalkboard-teacher"></i> <?= htmlspecialchars($course['first_name'].' '.$course['last_name']) ?></span><?php endif; ?>
          <span><i class="fas fa-users"></i> Max <?= $course['max_students'] ?> students</span>
        </div>
        <p><?= nl2br(htmlspecialchars($course['description'] ?? '')) ?></p>
        <?php if ($course['requirements']): ?>
        <div class="card mt-3"><div class="card-header"><h4>Requirements</h4></div><div class="card-body"><p><?= nl2br(htmlspecialchars($course['requirements'])) ?></p></div></div>
        <?php endif; ?>
        <?php if ($course['syllabus']): ?>
        <div class="card mt-3"><div class="card-header"><h4>Syllabus</h4></div><div class="card-body"><p><?= nl2br(htmlspecialchars($course['syllabus'])) ?></p></div></div>
        <?php endif; ?>
      </div>

      <!-- Enrollment Card -->
      <div class="card" style="position:sticky;top:90px">
        <div style="background:linear-gradient(135deg,var(--blue),var(--blue-dark));padding:20px;text-align:center">
          <div style="font-size:2rem;font-weight:900;color:var(--white)"><?= formatCurrency($course['price']) ?></div>
          <small style="color:rgba(255,255,255,0.7)">One-time enrollment fee</small>
        </div>
        <div class="card-body">
          <?php if ($myEnrollment): ?>
            <?php if ($myEnrollment['status'] === 'active'): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> You're enrolled and can access course materials</div>
            <div><strong>Progress:</strong> <?= $myEnrollment['progress'] ?>%</div>
            <div class="progress mt-2"><div class="progress-bar" style="width:<?= $myEnrollment['progress'] ?>%"></div></div>
            <a href="<?= BASE_URL ?>/customer/my-courses.php?id=<?= $courseId ?>" class="btn btn-primary btn-block mt-3">Go to Course</a>
            <?php elseif ($myEnrollment['status'] === 'completed'): ?>
            <div class="alert alert-success"><i class="fas fa-trophy"></i> You completed this course!</div>
            <a href="<?= BASE_URL ?>/customer/my-courses.php?id=<?= $courseId ?>" class="btn btn-primary btn-block mt-3">View Course</a>
            <?php else: ?>
            <div class="alert" style="background:#FFF3CD;color:#856404"><i class="fas fa-hourglass-half"></i> Enrollment in progress</div>
            <div style="font-size:0.85rem;display:flex;flex-direction:column;gap:8px;margin-top:10px">
              <div class="d-flex align-items-center gap-2">
                <i class="fas <?= $myEnrollment['admin_approved']?'fa-check-circle':'fa-circle' ?>" style="color:<?= $myEnrollment['admin_approved']?'#28A745':'var(--border)' ?>"></i>
                Admin acceptance <?= $myEnrollment['admin_approved']?'<strong>(done)</strong>':'<span class="text-muted">(pending)</span>' ?>
              </div>
              <div class="d-flex align-items-center gap-2">
                <i class="fas <?= $myEnrollment['finance_approved']?'fa-check-circle':'fa-circle' ?>" style="color:<?= $myEnrollment['finance_approved']?'#28A745':'var(--border)' ?>"></i>
                Finance approval <?= $myEnrollment['finance_approved']?'<strong>(done)</strong>':'<span class="text-muted">(pending)</span>' ?>
              </div>
            </div>
            <p class="text-muted mt-2" style="font-size:0.8rem">Course materials unlock once both steps are complete. We'll notify you.</p>
            <?php endif; ?>
          <?php elseif ($isLoggedIn): ?>
          <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
            <input type="hidden" name="enroll_course_id" value="<?= $courseId ?>">
            <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fas fa-graduation-cap"></i> Enroll Now</button>
          </form>
          <p class="text-muted text-center mt-2" style="font-size:0.8rem">Your enrollment will be reviewed by our admin team, then approved by finance once payment is confirmed</p>
          <?php else: ?>
          <a href="<?= BASE_URL ?>/customer/login.php" class="btn btn-primary btn-block btn-lg"><i class="fas fa-sign-in-alt"></i> Login to Enroll</a>
          <a href="<?= BASE_URL ?>/customer/register.php" class="btn btn-outline-primary btn-block mt-2">Create Free Account</a>
          <?php endif; ?>

          <div style="margin-top:20px;border-top:1px solid var(--border);padding-top:16px">
            <div style="display:flex;flex-direction:column;gap:8px;font-size:0.85rem">
              <div class="d-flex gap-2 align-items-center"><i class="fas fa-certificate" style="color:var(--blue);width:20px"></i> Certificate of completion</div>
              <div class="d-flex gap-2 align-items-center"><i class="fas fa-download" style="color:var(--blue);width:20px"></i> Downloadable materials</div>
              <div class="d-flex gap-2 align-items-center"><i class="fas fa-headset" style="color:var(--blue);width:20px"></i> Instructor support</div>
              <div class="d-flex gap-2 align-items-center"><i class="fas fa-infinity" style="color:var(--blue);width:20px"></i> Lifetime access</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php else: ?>
  <!-- COURSES LIST -->
  <div style="margin-bottom:24px"><h2><i class="fas fa-book-open text-primary"></i> Computer Courses</h2><p class="text-muted">Professional IT training for individuals and businesses</p></div>

  <!-- Search/Filter -->
  <div class="card mb-4">
    <div class="card-body" style="padding:14px">
      <form method="GET" class="d-flex gap-2 flex-wrap">
        <input type="text" name="search" class="form-control" placeholder="Search courses..." value="<?= htmlspecialchars($search) ?>" style="flex:1;min-width:200px">
        <select name="category" class="form-control" style="width:auto" onchange="this.form.submit()">
          <option value="">All Categories</option>
          <?php foreach ($catLabels as $k=>$v): ?><option value="<?= $k ?>" <?= $category===$k?'selected':'' ?>><?= $v ?></option><?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if ($search||$category): ?><a href="<?= BASE_URL ?>/customer/courses.php" class="btn" style="border:1px solid var(--border)">Clear</a><?php endif; ?>
      </form>
    </div>
  </div>

  <!-- Category Tabs -->
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px">
    <a href="?" class="btn btn-sm <?= !$category?'btn-primary':'btn-outline-primary' ?>">All</a>
    <?php foreach ($catLabels as $k=>$v): ?>
    <a href="?category=<?= $k ?>" class="btn btn-sm <?= $category===$k?'btn-primary':'btn-outline-primary' ?>"><?= $v ?></a>
    <?php endforeach; ?>
  </div>

  <?php if (empty($courses)): ?>
  <div class="card"><div class="card-body text-center" style="padding:60px"><i class="fas fa-book" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i><h4>No courses found</h4></div></div>
  <?php else: ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:24px">
    <?php foreach ($courses as $c): ?>
    <div class="card" style="overflow:hidden">
      <div style="background:linear-gradient(135deg,var(--blue),var(--blue-dark));padding:24px;text-align:center">
        <div style="width:60px;height:60px;border-radius:50%;background:rgba(255,255,255,0.2);display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:1.5rem;color:#fff">
          <?php $icons=['computer_basics'=>'fa-desktop','microsoft_office'=>'fa-file-word','graphic_design'=>'fa-palette','web_development'=>'fa-code','video_editing'=>'fa-film','networking'=>'fa-network-wired','programming'=>'fa-laptop-code','digital_marketing'=>'fa-bullhorn']; ?>
          <i class="fas <?= $icons[$c['category']] ?? 'fa-book' ?>"></i>
        </div>
        <?php if ($c['is_featured']): ?><span class="badge badge-yellow" style="margin-bottom:8px">Featured</span><?php endif; ?>
      </div>
      <div class="card-body">
        <div style="font-size:0.72rem;font-weight:700;text-transform:uppercase;color:var(--blue);letter-spacing:0.5px;margin-bottom:4px"><?= $catLabels[$c['category']] ?? '' ?></div>
        <h4 style="margin-bottom:8px"><?= htmlspecialchars($c['title']) ?></h4>
        <p style="font-size:0.85rem;color:var(--text-muted);margin-bottom:12px"><?= htmlspecialchars(substr($c['description'],0,100)) ?>...</p>
        <div style="display:flex;gap:12px;font-size:0.8rem;color:var(--text-muted);margin-bottom:14px;flex-wrap:wrap">
          <?php if ($c['duration']): ?><span><i class="fas fa-clock"></i> <?= $c['duration'] ?></span><?php endif; ?>
          <span><i class="fas fa-signal"></i> <?= ucfirst($c['mode']) ?></span>
          <span><i class="fas fa-users"></i> <?= $c['enrolled_count'] ?> enrolled</span>
        </div>
        <div class="d-flex align-items-center justify-content-between">
          <div style="font-size:1.1rem;font-weight:800;color:var(--blue)"><?= formatCurrency($c['price']) ?></div>
          <a href="<?= BASE_URL ?>/customer/courses.php?id=<?= $c['id'] ?>" class="btn btn-primary btn-sm">View Course</a>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>

<?php if ($isLoggedIn && $user && $user['role_slug']==='customer'): ?>
  </main></div>
<?php else: ?>
</main></div>
<?php endif; ?>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
</body>
</html>
