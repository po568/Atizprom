<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$step = (int)($_GET['step'] ?? 1);
$basePath = dirname(__DIR__);
$configFile = $basePath . '/config/config.php';

// If already installed, redirect
if (file_exists($basePath . '/config/installed.lock') && $step !== 99) {
    header('Location: ../index.php');
    exit;
}

$errors = [];
$success = '';

// STEP 2: Requirements check is shown via GET
// STEP 3: Database configuration + import
if ($step === 3 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $dbHost = $_POST['db_host'] ?? 'localhost';
    $dbUser = $_POST['db_user'] ?? 'root';
    $dbPass = $_POST['db_pass'] ?? '';
    $dbName = $_POST['db_name'] ?? 'atizprom_db';
    $baseUrl = rtrim($_POST['base_url'] ?? 'http://localhost/atizprom', '/');

    try {
        $mysqli = new mysqli($dbHost, $dbUser, $dbPass);
        if ($mysqli->connect_error) throw new Exception('Connection failed: ' . $mysqli->connect_error);

        // Run SQL file
        $sql = file_get_contents($basePath . '/database/atizprom.sql');
        $sql = str_replace('atizprom_db', $dbName, $sql);

        if ($mysqli->multi_query($sql)) {
            do {
                if ($result = $mysqli->store_result()) $result->free();
            } while ($mysqli->more_results() && $mysqli->next_result());
        }
        if ($mysqli->error) throw new Exception('SQL Error: ' . $mysqli->error);

        // Write config file
        $configContent = "<?php\n";
        $configContent .= "define('DB_HOST', '" . addslashes($dbHost) . "');\n";
        $configContent .= "define('DB_USER', '" . addslashes($dbUser) . "');\n";
        $configContent .= "define('DB_PASS', '" . addslashes($dbPass) . "');\n";
        $configContent .= "define('DB_NAME', '" . addslashes($dbName) . "');\n\n";
        $configContent .= "define('BASE_URL', '" . addslashes($baseUrl) . "');\n";
        $configContent .= "if (!defined('BASE_PATH')) {\n    define('BASE_PATH', dirname(__DIR__));\n}\n\n";
        $configContent .= "define('SITE_NAME', 'Atiz Prom');\n";
        $configContent .= "define('SITE_SLOGAN', 'Atiz Prom – Home of All Tech Solutions');\n";
        $configContent .= "define('SITE_EMAIL', 'atizpromltd@gmail.com');\n";
        $configContent .= "define('SITE_PHONE', '+255626296753');\n\n";
        $configContent .= "define('UPLOAD_DIR', BASE_PATH . '/uploads/');\n";
        $configContent .= "define('UPLOAD_URL', BASE_URL . '/uploads/');\n";
        $configContent .= "define('MAX_FILE_SIZE', 10 * 1024 * 1024);\n";
        $configContent .= "define('ALLOWED_IMAGE_TYPES', ['image/jpeg','image/png','image/gif','image/webp']);\n";
        $configContent .= "define('ALLOWED_DOC_TYPES', ['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/zip','audio/mpeg','video/mp4']);\n\n";
        $configContent .= "define('CURRENCY', 'TZS');\n";
        $configContent .= "define('TAX_RATE', 0.18);\n\n";
        $configContent .= "define('SESSION_TIMEOUT', 7200);\n";
        $configContent .= "define('MAX_LOGIN_ATTEMPTS', 5);\n";
        $configContent .= "define('LOCKOUT_DURATION', 1800);\n\n";
        $configContent .= "define('SMTP_HOST', 'smtp.gmail.com');\n";
        $configContent .= "define('SMTP_PORT', 587);\n";
        $configContent .= "define('SMTP_USER', 'atizpromltd@gmail.com');\n";
        $configContent .= "define('SMTP_PASS', '');\n";
        $configContent .= "define('SMTP_FROM_NAME', 'Atiz Prom');\n\n";
        $configContent .= "define('VERSION', '1.0.0');\n";
        $configContent .= "define('INSTALLED', true);\n\n";
        $configContent .= "error_reporting(E_ALL);\nini_set('display_errors', 0);\nini_set('log_errors', 1);\n\n";
        $configContent .= "date_default_timezone_set('Africa/Dar_es_Salaam');\n";

        file_put_contents($configFile, $configContent);
        file_put_contents($basePath . '/config/installed.lock', date('Y-m-d H:i:s'));

        // Create upload dirs
        foreach (['profiles','portfolio','projects','documents','products','contracts'] as $dir) {
            $p = $basePath . '/uploads/' . $dir;
            if (!is_dir($p)) mkdir($p, 0755, true);
        }

        header('Location: index.php?step=4');
        exit;

    } catch (Exception $e) {
        $errors[] = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Atiz Prom – Installation Wizard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root { --yellow:#FFC107; --blue:#1565C0; --dark:#0A0A1A; }
* { margin:0; padding:0; box-sizing:border-box; font-family:'Segoe UI',sans-serif; }
body { background:linear-gradient(135deg,#0A0A1A,#16213E); min-height:100vh; padding:40px 20px; }
.wrap { max-width:720px; margin:0 auto; }
.header { text-align:center; margin-bottom:30px; }
.header .logo { width:70px; height:70px; border-radius:18px; background:#FFC107; display:flex; align-items:center; justify-content:center; margin:0 auto 16px; overflow:hidden; }
.header .logo img { width:100%; height:100%; object-fit:cover; }
.header h1 { color:#fff; font-size:1.6rem; margin-bottom:6px; }
.header p { color:rgba(255,255,255,0.6); }
.steps { display:flex; justify-content:center; gap:8px; margin-bottom:30px; }
.step-dot { width:34px; height:34px; border-radius:50%; background:rgba(255,255,255,0.1); color:rgba(255,255,255,0.5); display:flex; align-items:center; justify-content:center; font-weight:700; font-size:0.9rem; }
.step-dot.active { background:var(--yellow); color:var(--dark); }
.step-dot.done { background:#28A745; color:#fff; }
.card { background:#fff; border-radius:16px; padding:36px; box-shadow:0 20px 60px rgba(0,0,0,0.4); }
.card h2 { margin-bottom:8px; color:#212529; }
.card p.desc { color:#6c757d; margin-bottom:24px; }
.check-item { display:flex; align-items:center; gap:12px; padding:12px 0; border-bottom:1px solid #eee; }
.check-item:last-child { border-bottom:none; }
.check-status { width:24px; height:24px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:0.75rem; }
.check-status.pass { background:#D4EDDA; color:#155724; }
.check-status.fail { background:#F8D7DA; color:#721C24; }
.form-group { margin-bottom:18px; }
.form-group label { display:block; font-weight:600; margin-bottom:6px; font-size:0.9rem; }
.form-control { width:100%; padding:11px 14px; border:2px solid #DEE2E6; border-radius:8px; font-size:0.95rem; }
.form-control:focus { outline:none; border-color:var(--blue); }
.btn { display:inline-flex; align-items:center; gap:8px; padding:12px 28px; border-radius:8px; font-weight:600; border:2px solid var(--blue); background:var(--blue); color:#fff; cursor:pointer; text-decoration:none; font-size:0.95rem; }
.btn:hover { background:#0D47A1; }
.btn-block { width:100%; justify-content:center; }
.alert { padding:12px 16px; border-radius:8px; margin-bottom:16px; font-size:0.9rem; }
.alert-danger { background:#F8D7DA; color:#721C24; }
.alert-success { background:#D4EDDA; color:#155724; }
.creds-box { background:#E3F2FD; border-radius:10px; padding:18px; margin:16px 0; }
.creds-box strong { color:var(--blue); }
.creds-row { display:flex; justify-content:space-between; padding:6px 0; font-size:0.9rem; }
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <div class="logo"><img src="../assets/images/logo.webp" alt="Atiz Prom Logo"></div>
    <h1>Atiz Prom Installation Wizard</h1>
    <p>Home of All Tech Solutions — System Setup</p>
  </div>
  <div class="steps">
    <div class="step-dot <?= $step==1?'active':($step>1?'done':'') ?>">1</div>
    <div class="step-dot <?= $step==2?'active':($step>2?'done':'') ?>">2</div>
    <div class="step-dot <?= $step==3?'active':($step>3?'done':'') ?>">3</div>
    <div class="step-dot <?= $step==4?'active':'' ?>">4</div>
  </div>

  <div class="card">
  <?php if ($step === 1): ?>
    <h2><i class="fas fa-rocket"></i> Welcome</h2>
    <p class="desc">This wizard will guide you through installing the Atiz Prom Company Management System on your XAMPP server.</p>
    <ul style="margin-bottom:24px;padding-left:20px;color:#495057;line-height:1.8">
      <li>Make sure XAMPP (Apache + MySQL) is running</li>
      <li>This package should be placed in <code>xampp/htdocs/atizprom/</code></li>
      <li>Have your MySQL credentials ready (default: root / no password)</li>
    </ul>
    <a href="?step=2" class="btn btn-block">Get Started <i class="fas fa-arrow-right"></i></a>

  <?php elseif ($step === 2): ?>
    <h2><i class="fas fa-clipboard-check"></i> System Requirements</h2>
    <p class="desc">Checking your server environment...</p>
    <?php
    $checks = [
        'PHP Version >= 8.0' => version_compare(PHP_VERSION, '8.0.0', '>='),
        'MySQLi Extension' => extension_loaded('mysqli'),
        'GD Extension (Image Processing)' => extension_loaded('gd'),
        'File Uploads Enabled' => ini_get('file_uploads'),
        'config/ directory writable' => is_writable($basePath . '/config'),
        'uploads/ directory writable' => is_writable($basePath . '/uploads') || is_writable($basePath),
    ];
    $allPass = true;
    foreach ($checks as $label => $pass) {
        if (!$pass) $allPass = false;
        echo '<div class="check-item"><div class="check-status '.($pass?'pass':'fail').'"><i class="fas fa-'.($pass?'check':'times').'"></i></div><div>'.$label.'</div></div>';
    }
    ?>
    <div style="margin-top:24px">
      <?php if ($allPass): ?>
      <a href="?step=3" class="btn btn-block">Continue <i class="fas fa-arrow-right"></i></a>
      <?php else: ?>
      <div class="alert alert-danger">Please fix the failed requirements above before continuing.</div>
      <a href="?step=2" class="btn btn-block">Re-check</a>
      <?php endif; ?>
    </div>

  <?php elseif ($step === 3): ?>
    <h2><i class="fas fa-database"></i> Database Configuration</h2>
    <p class="desc">Enter your MySQL database connection details. The database will be created automatically if it doesn't exist.</p>
    <?php foreach ($errors as $e): ?><div class="alert alert-danger"><?= htmlspecialchars($e) ?></div><?php endforeach; ?>
    <form method="POST">
      <div class="form-group">
        <label>Database Host</label>
        <input type="text" name="db_host" class="form-control" value="localhost" required>
      </div>
      <div class="form-group">
        <label>Database Username</label>
        <input type="text" name="db_user" class="form-control" value="root" required>
      </div>
      <div class="form-group">
        <label>Database Password</label>
        <input type="password" name="db_pass" class="form-control" placeholder="(leave blank if none)">
      </div>
      <div class="form-group">
        <label>Database Name</label>
        <input type="text" name="db_name" class="form-control" value="atizprom_db" required>
      </div>
      <div class="form-group">
        <label>Site Base URL</label>
        <input type="text" name="base_url" class="form-control" value="http://localhost/atizprom" required>
      </div>
      <button type="submit" class="btn btn-block"><i class="fas fa-cogs"></i> Install Database</button>
    </form>

  <?php elseif ($step === 4): ?>
    <h2><i class="fas fa-check-circle" style="color:#28A745"></i> Installation Complete!</h2>
    <p class="desc">Atiz Prom Management System has been installed successfully.</p>

    <div class="creds-box" style="max-height:260px;overflow-y:auto">
      <strong><i class="fas fa-user-shield"></i> Default Staff Accounts</strong>
      <div class="creds-row"><span>Super Admin:</span><strong>superadmin@atizprom.com</strong></div>
      <div class="creds-row"><span>Admin:</span><strong>admin@atizprom.com</strong></div>
      <div class="creds-row"><span>Finance Officer:</span><strong>finance@atizprom.com</strong></div>
      <div class="creds-row"><span>Production Manager:</span><strong>production@atizprom.com</strong></div>
      <div class="creds-row"><span>Graphic Designer:</span><strong>designer@atizprom.com</strong></div>
      <div class="creds-row"><span>Course Instructor:</span><strong>instructor@atizprom.com</strong></div>
      <div class="creds-row"><span>Inventory Officer:</span><strong>inventory@atizprom.com</strong></div>
      <div class="creds-row"><span>Password (all):</span><strong>password</strong></div>
    </div>
    <div class="creds-box" style="background:#FFF8E1">
      <strong style="color:#856404"><i class="fas fa-user"></i> Demo Customer Account</strong>
      <div class="creds-row"><span>Email:</span><strong>customer@demo.com</strong></div>
      <div class="creds-row"><span>Password:</span><strong>password</strong></div>
    </div>
    <div class="alert alert-danger" style="margin-top:16px">
      <i class="fas fa-exclamation-triangle"></i> <strong>Important:</strong> Please change all default passwords immediately and delete this <code>installer/</code> folder before going to production.
    </div>
    <div style="display:flex;gap:10px;margin-top:20px">
      <a href="../admin/login.php" class="btn" style="flex:1">Admin Login <i class="fas fa-arrow-right"></i></a>
      <a href="../index.php" class="btn" style="flex:1;background:var(--yellow);border-color:var(--yellow);color:#000">Visit Website</a>
    </div>
  <?php endif; ?>
  </div>
</div>
</body>
</html>
