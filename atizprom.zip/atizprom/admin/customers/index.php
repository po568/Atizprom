<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$search = $_GET['search'] ?? '';

$where = ['role_id=8']; $params=[]; $types='';
if ($search) { $where[]="(CONCAT(first_name,' ',last_name) LIKE ? OR email LIKE ? OR phone LIKE ?)"; $q='%'.$search.'%'; $params=[$q,$q,$q]; $types='sss'; }

$customers = $db->fetchAll("SELECT u.*, (SELECT COUNT(*) FROM bookings WHERE customer_id=u.id) as booking_count, (SELECT COUNT(*) FROM projects WHERE customer_id=u.id) as project_count FROM users u WHERE ".implode(' AND ',$where)." ORDER BY u.created_at DESC", $params, $types);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customers – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Customers</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Customers</div></div>
    </div>
    <div class="header-actions">
      <a href="<?= BASE_URL ?>/admin/customers/create.php" class="btn btn-primary btn-sm"><i class="fas fa-user-plus"></i> Add Customer</a>
    </div>
  </div>
  <div class="content-body">
    <div class="card">
      <div class="card-body">
        <form method="GET" class="dt-toolbar">
          <div class="dt-search" style="flex:1;max-width:400px">
            <i class="fas fa-search"></i>
            <input type="text" name="search" class="form-control" placeholder="Search by name, email, or phone..." value="<?= htmlspecialchars($search) ?>">
          </div>
          <button type="submit" class="btn btn-primary btn-sm">Search</button>
        </form>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Customer</th><th>Contact</th><th>Bookings</th><th>Projects</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($customers as $c): ?>
              <tr>
                <td>
                  <div class="d-flex align-items-center gap-2">
                    <div style="width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,var(--blue),var(--yellow));color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.85rem"><?= strtoupper(substr($c['first_name'],0,1)) ?></div>
                    <strong><?= htmlspecialchars($c['first_name'].' '.$c['last_name']) ?></strong>
                  </div>
                </td>
                <td><?= htmlspecialchars($c['email']) ?><br><small class="text-muted"><?= htmlspecialchars($c['phone'] ?: '-') ?></small></td>
                <td><span class="badge badge-primary"><?= $c['booking_count'] ?></span></td>
                <td><span class="badge badge-info"><?= $c['project_count'] ?></span></td>
                <td><?= $c['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>' ?></td>
                <td><?= formatDate($c['created_at']) ?></td>
                <td>
                  <div class="d-flex gap-1">
                    <a href="<?= BASE_URL ?>/admin/customers/view.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-eye"></i></a>
                    <a href="<?= BASE_URL ?>/admin/customers/edit.php?id=<?= $c['id'] ?>" class="btn btn-sm" style="border:1px solid var(--border)"><i class="fas fa-edit"></i></a>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($customers)): ?>
              <tr><td colspan="7" class="text-center text-muted" style="padding:40px">No customers found</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
