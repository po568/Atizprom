<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','finance_officer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$error = '';

// Pre-fill from query string (e.g. came from booking/quotation/enrollment page)
$prefill = [];
if (isset($_GET['booking_id']))    $prefill['booking_id']    = (int)$_GET['booking_id'];
if (isset($_GET['quotation_id']))  $prefill['quotation_id']  = (int)$_GET['quotation_id'];
if (isset($_GET['enrollment_id'])) $prefill['enrollment_id'] = (int)$_GET['enrollment_id'];

$customers   = $db->fetchAll("SELECT id, first_name, last_name, email FROM users WHERE role_id=8 ORDER BY first_name");
$bookings    = $db->fetchAll("SELECT id, booking_number, customer_id, total_amount FROM bookings WHERE status IN ('confirmed','in_progress','completed') ORDER BY created_at DESC");
$quotations  = $db->fetchAll("SELECT id, quotation_number, customer_id, total FROM quotations WHERE status='approved' ORDER BY created_at DESC");
$enrollments = $db->fetchAll(
    "SELECT ce.id, ce.enrollment_number, ce.student_id, c.title, c.price
     FROM course_enrollments ce JOIN courses c ON ce.course_id=c.id
     WHERE ce.status='active' ORDER BY ce.enrolled_at DESC"
);
$products = $db->fetchAll("SELECT id, name, price FROM products WHERE is_active=1 ORDER BY name");

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $customerId  = (int)$_POST['customer_id'];
        $subtotal    = (float)$_POST['subtotal'];
        $discount    = (float)($_POST['discount'] ?? 0);
        $taxRate     = (float)(getSetting('tax_rate', 18)) / 100;
        $tax         = round(($subtotal - $discount) * $taxRate, 2);
        $total       = $subtotal - $discount + $tax;
        $items       = json_encode($_POST['items'] ?? []);
        $invoiceNum  = $auth->generateNumber('INV', 'invoices', 'invoice_number');
        $dueDate     = $_POST['due_date'] ?: date('Y-m-d', strtotime('+14 days'));

        $id = $db->insert(
            "INSERT INTO invoices (invoice_number, customer_id, booking_id, quotation_id, enrollment_id, items, subtotal, discount, tax, total, balance, due_date, status, notes, created_by, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())",
            [$invoiceNum, $customerId, $_POST['booking_id']?:null, $_POST['quotation_id']?:null, $_POST['enrollment_id']?:null, $items, $subtotal, $discount, $tax, $total, $total, $dueDate, 'sent', trim($_POST['notes']??''), $user['id']]
        );
        $auth->logAudit($user['id'], 'INVOICE_CREATED', 'invoices', $id);

        // Notify customer
        $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
            [$customerId, 'New Invoice Ready', "Invoice #$invoiceNum for ".formatCurrency($total)." has been sent. Due: ".formatDate($dueDate), 'invoice', BASE_URL.'/customer/invoices.php?id='.$id]);

        redirect(BASE_URL.'/admin/invoices/?created=1');
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Invoice – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Create Invoice</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/invoices/">Invoices</a> <span class="sep">/</span> New</div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:820px">
    <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST" id="invoiceForm">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <div class="card mb-3">
        <div class="card-header"><h4>Invoice Details</h4></div>
        <div class="card-body">
          <div class="form-row">
            <div class="form-group">
              <label>Customer *</label>
              <select name="customer_id" id="customerSelect" class="form-control" required onchange="updateFromCustomer(this.value)">
                <option value="">Select customer</option>
                <?php foreach ($customers as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['first_name'].' '.$c['last_name']) ?> (<?= htmlspecialchars($c['email']) ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Due Date *</label>
              <input type="date" name="due_date" class="form-control" value="<?= date('Y-m-d', strtotime('+14 days')) ?>">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Link to Booking (optional)</label>
              <select name="booking_id" id="bookingSelect" class="form-control" onchange="autoFillFromBooking(this)">
                <option value="">None</option>
                <?php foreach ($bookings as $b): ?>
                <option value="<?= $b['id'] ?>" data-customer="<?= $b['customer_id'] ?>" data-amount="<?= $b['total_amount'] ?>" <?= ($prefill['booking_id']??0)==$b['id']?'selected':'' ?>>
                  <?= $b['booking_number'] ?> (<?= formatCurrency($b['total_amount']) ?>)
                </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Link to Quotation (optional)</label>
              <select name="quotation_id" id="quotationSelect" class="form-control" onchange="autoFillFromQuotation(this)">
                <option value="">None</option>
                <?php foreach ($quotations as $q): ?>
                <option value="<?= $q['id'] ?>" data-customer="<?= $q['customer_id'] ?>" data-amount="<?= $q['total'] ?>" <?= ($prefill['quotation_id']??0)==$q['id']?'selected':'' ?>>
                  <?= $q['quotation_number'] ?> (<?= formatCurrency($q['total']) ?>)
                </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Link to Enrollment (optional)</label>
              <select name="enrollment_id" id="enrollmentSelect" class="form-control" onchange="autoFillFromEnrollment(this)">
                <option value="">None</option>
                <?php foreach ($enrollments as $e): ?>
                <option value="<?= $e['id'] ?>" data-customer="<?= $e['student_id'] ?>" data-amount="<?= $e['price'] ?>" data-title="<?= htmlspecialchars($e['title']) ?>" <?= ($prefill['enrollment_id']??0)==$e['id']?'selected':'' ?>>
                  <?= $e['enrollment_number'] ?> – <?= htmlspecialchars(substr($e['title'],0,30)) ?> (<?= formatCurrency($e['price']) ?>)
                </option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div class="card mb-3">
        <div class="card-header d-flex justify-content-between align-items-center">
          <h4>Line Items</h4>
          <button type="button" onclick="addItem()" class="btn btn-sm btn-outline-primary"><i class="fas fa-plus"></i> Add Item</button>
        </div>
        <div class="card-body">
          <div class="form-group" style="margin-bottom:16px;padding-bottom:14px;border-bottom:1px solid var(--border)">
            <label>Add a Catalogue Product (optional)</label>
            <select id="productPicker" class="form-control" onchange="addCatalogueItem(this)">
              <option value="">Select a product to add as a line item...</option>
              <?php foreach ($products as $p): ?>
              <option value="<?= $p['id'] ?>" data-name="<?= htmlspecialchars($p['name']) ?>" data-price="<?= $p['price'] ?>"><?= htmlspecialchars($p['name']) ?> (<?= formatCurrency($p['price']) ?>)</option>
              <?php endforeach; ?>
            </select>
            <div class="form-text">Selecting a product tags this line item so it appears in Inventory's sales reports.</div>
          </div>
          <div id="itemsContainer">
            <div class="item-row" style="display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center;margin-bottom:8px">
              <input type="hidden" name="items[0][product_id]" value="">
              <input type="text" name="items[0][description]" class="form-control" placeholder="Item description" required>
              <input type="number" name="items[0][qty]" class="form-control" style="width:70px" value="1" min="1" oninput="recalc(this)">
              <input type="number" name="items[0][unit_price]" class="form-control" style="width:120px" placeholder="Price" min="0" step="100" oninput="recalc(this)">
              <button type="button" onclick="removeItem(this)" class="btn btn-sm btn-danger"><i class="fas fa-times"></i></button>
            </div>
          </div>
        </div>
        <div class="card-footer">
          <div style="max-width:300px;margin-left:auto">
            <div class="d-flex justify-content-between mb-2"><span>Subtotal</span><strong id="subtotalDisplay">TZS 0</strong></div>
            <div class="d-flex justify-content-between mb-2 align-items-center">
              <span>Discount</span>
              <input type="number" name="discount" id="discountInput" class="form-control" style="width:120px" value="0" min="0" step="1000" oninput="updateTotals()">
            </div>
            <div class="d-flex justify-content-between mb-2"><span>Tax (<?= getSetting('tax_rate','18') ?>%)</span><strong id="taxDisplay">TZS 0</strong></div>
            <div class="d-flex justify-content-between" style="font-size:1.1rem"><strong>Total</strong><strong id="totalDisplay" style="color:var(--blue)">TZS 0</strong></div>
            <input type="hidden" name="subtotal" id="subtotalInput">
          </div>
        </div>
      </div>

      <div class="card mb-3">
        <div class="card-header"><h4>Notes</h4></div>
        <div class="card-body">
          <textarea name="notes" class="form-control" rows="2" placeholder="Payment instructions, terms, reference details..."></textarea>
        </div>
      </div>

      <div class="d-flex justify-content-end gap-2">
        <a href="<?= BASE_URL ?>/admin/invoices/" class="btn" style="border:1px solid var(--border)">Cancel</a>
        <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Create & Send Invoice</button>
      </div>
    </form>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
<script>
const TAX_RATE = <?= (float)getSetting('tax_rate', 18) / 100 ?>;
let itemCount = 1;

function addItem() {
  const c = document.getElementById('itemsContainer');
  const d = document.createElement('div');
  d.className = 'item-row';
  d.style = 'display:grid;grid-template-columns:1fr auto auto auto;gap:8px;align-items:center;margin-bottom:8px';
  d.innerHTML = `<input type="hidden" name="items[${itemCount}][product_id]" value="">
    <input type="text" name="items[${itemCount}][description]" class="form-control" placeholder="Item description" required>
    <input type="number" name="items[${itemCount}][qty]" class="form-control" style="width:70px" value="1" min="1" oninput="recalc(this)">
    <input type="number" name="items[${itemCount}][unit_price]" class="form-control" style="width:120px" placeholder="Price" min="0" step="100" oninput="recalc(this)">
    <button type="button" onclick="removeItem(this)" class="btn btn-sm btn-danger"><i class="fas fa-times"></i></button>`;
  c.appendChild(d); itemCount++;
  return d;
}
function addCatalogueItem(sel) {
  const opt = sel.options[sel.selectedIndex];
  if (!opt.value) return;
  // Use the first row if it's still empty, otherwise add a new one
  let row = document.querySelector('.item-row');
  const descInput = row.querySelector('[name*="[description]"]');
  if (descInput.value.trim() !== '') {
    row = addItem();
  }
  row.querySelector('[name*="[product_id]"]').value = opt.value;
  row.querySelector('[name*="[description]"]').value = opt.dataset.name;
  row.querySelector('[name*="[unit_price]"]').value = opt.dataset.price;
  updateTotals();
  sel.value = '';
}
function removeItem(btn) {
  if (document.querySelectorAll('.item-row').length > 1) { btn.closest('.item-row').remove(); updateTotals(); }
}
function recalc(input) { updateTotals(); }
function updateTotals() {
  let sub = 0;
  document.querySelectorAll('.item-row').forEach(row => {
    const qty = parseFloat(row.querySelector('[name*="[qty]"]')?.value) || 0;
    const up  = parseFloat(row.querySelector('[name*="[unit_price]"]')?.value) || 0;
    sub += qty * up;
  });
  const disc = parseFloat(document.getElementById('discountInput').value) || 0;
  const tax  = Math.round((sub - disc) * TAX_RATE);
  const total = sub - disc + tax;
  document.getElementById('subtotalDisplay').textContent = 'TZS ' + sub.toLocaleString();
  document.getElementById('taxDisplay').textContent = 'TZS ' + tax.toLocaleString();
  document.getElementById('totalDisplay').textContent = 'TZS ' + total.toLocaleString();
  document.getElementById('subtotalInput').value = sub;
}
function setCustomer(id) {
  const sel = document.getElementById('customerSelect');
  for (let opt of sel.options) { if (opt.value == id) { opt.selected = true; break; } }
}
function autoFillFromBooking(sel) {
  const opt = sel.options[sel.selectedIndex];
  if (opt.value) {
    setCustomer(opt.dataset.customer);
    const row = document.querySelector('.item-row');
    row.querySelector('[name*="[unit_price]"]').value = opt.dataset.amount;
    row.querySelector('[name*="[description]"]').value = 'Service Booking – ' + opt.text.split(' ')[0];
    updateTotals();
  }
}
function autoFillFromQuotation(sel) {
  const opt = sel.options[sel.selectedIndex];
  if (opt.value) {
    setCustomer(opt.dataset.customer);
    const row = document.querySelector('.item-row');
    row.querySelector('[name*="[unit_price]"]').value = opt.dataset.amount;
    row.querySelector('[name*="[description]"]').value = 'Approved Quotation – ' + opt.text.split(' ')[0];
    updateTotals();
  }
}
function autoFillFromEnrollment(sel) {
  const opt = sel.options[sel.selectedIndex];
  if (opt.value) {
    setCustomer(opt.dataset.customer);
    const row = document.querySelector('.item-row');
    row.querySelector('[name*="[unit_price]"]').value = opt.dataset.amount;
    row.querySelector('[name*="[description]"]').value = 'Course Enrollment – ' + (opt.dataset.title || opt.text);
    updateTotals();
  }
}
</script>
</body>
</html>
