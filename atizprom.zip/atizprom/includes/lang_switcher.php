<?php
// Reusable language switcher dropdown. Include this from any header.
// Requires bootstrap.php to already be loaded (for currentLang()).
$__curLang = currentLang();
?>
<div class="lang-switch">
  <button type="button" class="lang-switch-btn" onclick="this.parentElement.classList.toggle('open')">
    <i class="fas fa-globe"></i> <?= $__curLang === 'sw' ? 'SW' : 'EN' ?> <i class="fas fa-chevron-down" style="font-size:0.65em"></i>
  </button>
  <div class="lang-switch-menu">
    <a href="#" data-set-lang="en" class="<?= $__curLang === 'en' ? 'active' : '' ?>">🇬🇧 English</a>
    <a href="#" data-set-lang="sw" class="<?= $__curLang === 'sw' ? 'active' : '' ?>">🇹🇿 Kiswahili</a>
  </div>
</div>
