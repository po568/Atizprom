/**
 * Atiz Prom - Light/Dark Theme Toggle
 * Persists choice in a cookie (1 year) so server-rendered pages can read it
 * and apply data-theme before first paint via themeAttr() in the <html> tag.
 * Injects a small floating toggle button so no per-page markup edits are needed.
 */
(function () {
  function getCookie(name) {
    const match = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
    return match ? decodeURIComponent(match[2]) : null;
  }
  function setCookie(name, value, days) {
    const maxAge = days * 24 * 60 * 60;
    document.cookie = name + '=' + encodeURIComponent(value) + ';path=/;max-age=' + maxAge + ';SameSite=Lax';
  }

  window.AtizTheme = {
    get: function () {
      return document.documentElement.getAttribute('data-theme') || 'light';
    },
    set: function (theme) {
      if (theme === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
      } else {
        document.documentElement.removeAttribute('data-theme');
      }
      setCookie('atiz_theme', theme, 365);
      document.querySelectorAll('.theme-toggle').forEach(function (btn) {
        btn.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
        const icon = btn.querySelector('i');
        if (icon) icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
      });
    },
    toggle: function () {
      window.AtizTheme.set(window.AtizTheme.get() === 'dark' ? 'light' : 'dark');
    }
  };

  function injectToggleButton() {
    if (document.querySelector('.theme-toggle')) return; // already present (e.g. manually placed in a header)
    const btn = document.createElement('button');
    btn.className = 'theme-toggle theme-toggle-floating';
    btn.type = 'button';
    btn.title = 'Toggle light / dark theme';
    btn.setAttribute('aria-label', 'Toggle light / dark theme');
    const isDark = window.AtizTheme.get() === 'dark';
    btn.innerHTML = '<i class="fas ' + (isDark ? 'fa-sun' : 'fa-moon') + '"></i>';
    btn.addEventListener('click', window.AtizTheme.toggle);
    document.body.appendChild(btn);
  }

  document.addEventListener('DOMContentLoaded', function () {
    // Wire up any toggle buttons already present in the page markup
    document.querySelectorAll('.theme-toggle').forEach(function (btn) {
      btn.addEventListener('click', window.AtizTheme.toggle);
    });
    injectToggleButton();
  });
})();
