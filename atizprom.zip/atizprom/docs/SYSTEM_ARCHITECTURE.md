# System Architecture – Atiz Prom Management System

## 1. Architectural Style
A **monolithic, server-rendered MVC-like architecture** using plain PHP (no framework), chosen per project constraints. Logic is organized into:

- **Presentation Layer:** PHP files mixing HTML output with embedded PHP (views)
- **Application Layer:** `classes/Auth.php`, `classes/Database.php` encapsulate business logic
- **Data Layer:** MySQL via `mysqli` with prepared statements

```
┌─────────────────────────────────────────────┐
│                  Browser (Client)             │
│   HTML5 / CSS3 / Vanilla JS / Chart.js (CDN)  │
└───────────────────┬───────────────────────────┘
                     │ HTTP(S)
┌───────────────────▼───────────────────────────┐
│              Apache + PHP 8 (XAMPP)            │
│  ┌─────────────┐  ┌──────────────┐             │
│  │ Public Site │  │ Customer     │             │
│  │ index.php   │  │ Portal       │             │
│  └─────────────┘  └──────────────┘             │
│  ┌─────────────┐  ┌──────────────┐             │
│  │ Admin Portal│  │ API Layer    │             │
│  │ (RBAC)      │  │ (AJAX/JSON)  │             │
│  └─────────────┘  └──────────────┘             │
│         classes/Auth.php, Database.php         │
└───────────────────┬───────────────────────────┘
                     │ mysqli (prepared statements)
┌───────────────────▼───────────────────────────┐
│                MySQL Database                  │
│   35+ tables: users, bookings, projects, ...    │
└─────────────────────────────────────────────────┘
```

## 2. Module Breakdown

| Module | Path | Responsibility |
|---|---|---|
| Public Site | `/index.php`, `/assets` | Marketing site, SEO landing pages |
| Customer Portal | `/customer/*` | Self-service bookings, courses, tickets |
| Admin Portal | `/admin/*` | Staff operations across all business domains |
| API Layer | `/api/*` | JSON endpoints for AJAX interactions (status updates, contact form) |
| Core Classes | `/classes/*` | `Database` (singleton connection + query helpers), `Auth` (session, RBAC, CSRF, audit) |
| Bootstrap | `/includes/bootstrap.php` | Central include: config, classes, helper functions |
| Installer | `/installer/*` | Guided DB setup wizard, writes `config/config.php` |

## 3. Request Lifecycle
1. Browser requests a `.php` page (e.g., `/customer/booking.php`)
2. Page includes `includes/bootstrap.php`, which loads config, `Database`, `Auth`
3. `Auth::requireLogin()` / `requireRole()` enforce access control
4. Business logic queries via `Database::fetchAll/fetchOne/insert/execute` (all parameterized)
5. View renders HTML with embedded PHP, using shared `assets/css` and `assets/js`
6. AJAX-driven actions (status changes, contact form) hit `/api/*.php`, returning JSON

## 4. Security Architecture
- **Authentication:** Bcrypt-hashed passwords, session-based auth with regenerated session IDs on login
- **Authorization:** Role IDs (1–8) checked via `Auth::requireRole()` against a role-slug map
- **CSRF:** Per-session token validated on every state-changing POST request
- **SQL Injection Prevention:** 100% prepared statements via `mysqli` bind_param
- **XSS Prevention:** All user-supplied output passed through `htmlspecialchars()`
- **Audit Trail:** `audit_logs` table records actor, action, before/after values, IP, and user agent for sensitive operations

## 5. Multi-Branch Design
The `branches` table is referenced by `users`, `bookings`, `projects`, `invoices`, and `products`, allowing the system to scale to multiple physical locations beyond the default Kyerwa Branch without schema changes.

## 6. Deployment Topology
Single-server deployment: Apache + PHP + MySQL co-located (standard XAMPP stack). No load balancer, message queue, or external services required — aligned with the project's "no external frameworks" constraint.
