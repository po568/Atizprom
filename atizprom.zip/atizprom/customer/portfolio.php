<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$db = Database::getInstance();
$isLoggedIn = $auth->isLoggedIn();
$user = $isLoggedIn ? $auth->getCurrentUser() : null;

$cat = $_GET['cat'] ?? '';
$where = ['is_active=1']; $params=[]; $types='';
if ($cat) { $where[]='category=?'; $params[]=$cat; $types.='s'; }
$items = $db->fetchAll("SELECT * FROM portfolio WHERE ".implode(' AND ',$where)." ORDER BY is_featured DESC, created_at DESC", $params, $types);
$catLabels = ['photography'=>'Photography','videography'=>'Videography','films'=>'Films','graphics_design'=>'Graphics Design','events_coverage'=>'Events Coverage'];
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Our Portfolio – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/home.css">
<?php if ($isLoggedIn): ?><link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css"><?php endif; ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php if ($isLoggedIn && $user && $user['role_slug']==='customer'): ?>
<?php include __DIR__ . '/includes/header.php'; ?>
<div class="customer-layout"><?php include __DIR__ . '/includes/sidebar.php'; ?>
<main class="customer-main"><div class="customer-content">
<?php else: ?>
<nav class="navbar"><div class="container"><a href="<?= BASE_URL ?>" class="navbar-brand"><div class="logo-icon"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div><div class="logo-text"><strong>ATIZ PROM</strong></div></a>
<ul class="nav-menu"><li><a href="<?= BASE_URL ?>">Home</a></li><li><a href="<?= BASE_URL ?>/customer/services.php">Services</a></li><li><a href="<?= BASE_URL ?>/customer/login.php" class="btn-nav-login">Login</a></li></ul>
</div></nav>
<div style="background:#fff"><main><div class="container" style="padding:40px 20px">
<?php endif; ?>

<div class="section-header"><div class="section-tag">Our Work</div><h2>Our <span class="text-primary">Portfolio</span></h2><p>Browse our completed projects across all creative disciplines</p></div>
<div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-bottom:30px">
  <a href="?" class="btn btn-sm <?= !$cat?'btn-primary':'btn-outline-primary' ?>">All</a>
  <?php foreach ($catLabels as $k=>$v): ?>
  <a href="?cat=<?= $k ?>" class="btn btn-sm <?= $cat===$k?'btn-primary':'btn-outline-primary' ?>"><?= $v ?></a>
  <?php endforeach; ?>
</div>

<?php if (empty($items)): ?>
<div class="text-center" style="padding:60px"><i class="fas fa-images" style="font-size:3rem;color:var(--border)"></i><h4 class="mt-3">No items in this category yet</h4></div>
<?php else: ?>
<div class="portfolio-grid">
  <?php foreach ($items as $p): ?>
  <div class="portfolio-item" onclick='openPortfolioModal(<?= htmlspecialchars(json_encode($p)) ?>)' style="cursor:pointer">
    <div class="portfolio-thumb">
      <?php if ($p['thumbnail']): ?><img src="<?= UPLOAD_URL . $p['thumbnail'] ?>" alt="<?= htmlspecialchars($p['title']) ?>">
      <?php else: ?><div class="portfolio-placeholder"><i class="fas fa-image"></i></div><?php endif; ?>
      <div class="portfolio-overlay">
        <div class="portfolio-info">
          <span class="portfolio-cat"><?= $catLabels[$p['category']] ?? $p['category'] ?></span>
          <h4><?= htmlspecialchars($p['title']) ?></h4>
          <?php if ($p['client_name']): ?><p><i class="fas fa-user"></i> <?= htmlspecialchars($p['client_name']) ?></p><?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($isLoggedIn && $user && $user['role_slug']==='customer'): ?>
</div></main></div>
<?php else: ?>
</div></main></div>
<?php include BASE_PATH . '/includes/footer_public.php'; ?>
<?php endif; ?>

<div class="modal-overlay" id="portfolioModal">
  <div class="modal" style="max-width:700px">
    <div class="modal-header"><h4 id="pfTitle"></h4><button class="modal-close" onclick="AtizProm.closeModal('portfolioModal')"><i class="fas fa-times"></i></button></div>
    <div class="modal-body" id="pfBody"></div>
  </div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script>
function openPortfolioModal(p) {
  document.getElementById('pfTitle').textContent = p.title;
  document.getElementById('pfBody').innerHTML = `
    ${p.thumbnail ? `<img src="<?= UPLOAD_URL ?>${p.thumbnail}" style="width:100%;border-radius:10px;margin-bottom:16px;max-height:350px;object-fit:cover">` : ''}
    <p><strong>Client:</strong> ${p.client_name || 'Confidential'}</p>
    <p><strong>Date:</strong> ${p.project_date || '-'}</p>
    <p>${p.description || ''}</p>`;
  AtizProm.openModal('portfolioModal');
}
</script>
</body>
</html>
