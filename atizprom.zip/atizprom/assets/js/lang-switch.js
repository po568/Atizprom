/**
 * Atiz Prom - Language Switcher (English / Kiswahili)
 * Persists choice in a cookie (1 year). Unlike the theme toggle, switching
 * language requires a full page reload since translated text is rendered
 * server-side via t() in PHP, not styled client-side via CSS.
 *
 * On pages that already render the dropdown in markup (via includes/lang_switcher.php,
 * used on the public homepage), this script just wires up the existing buttons.
 * On admin/customer pages where header markup is hand-rolled per file, this script
 * injects a small language toggle button into the top header bar automatically,
 * so language switching works everywhere without editing dozens of header blocks.
 */
(function () {
  function setCookie(name, value, days) {
    const maxAge = days * 24 * 60 * 60;
    document.cookie = name + '=' + encodeURIComponent(value) + ';path=/;max-age=' + maxAge + ';SameSite=Lax';
  }
  function getCookie(name) {
    const match = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
    return match ? decodeURIComponent(match[2]) : 'en';
  }

  window.AtizLang = {
    get: function () { return getCookie('atiz_lang') || 'en'; },
    set: function (lang) {
      setCookie('atiz_lang', lang, 365);
      window.location.reload();
    }
  };

  function injectHeaderSwitcher() {
    if (document.querySelector('.lang-switch')) return; // already present in page markup
    const target = document.querySelector('.header-actions')
      || document.querySelector('.customer-header-actions')
      || document.querySelector('.top-header');
    if (!target) return; // no admin/customer header on this page (e.g. public site already has its own)

    const current = window.AtizLang.get();
    const wrap = document.createElement('div');
    wrap.className = 'lang-switch';
    wrap.innerHTML =
      '<button type="button" class="lang-switch-btn header-icon-btn" title="Change language">' +
        '<i class="fas fa-globe"></i> ' + (current === 'sw' ? 'SW' : 'EN') +
      '</button>' +
      '<div class="lang-switch-menu">' +
        '<a href="#" data-set-lang="en" class="' + (current === 'en' ? 'active' : '') + '">🇬🇧 English</a>' +
        '<a href="#" data-set-lang="sw" class="' + (current === 'sw' ? 'active' : '') + '">🇹🇿 Kiswahili</a>' +
      '</div>';
    wrap.querySelector('.lang-switch-btn').addEventListener('click', function (e) {
      e.stopPropagation();
      wrap.classList.toggle('open');
    });
    if (target.classList.contains('top-header')) {
      target.appendChild(wrap); // top-header has no dedicated actions slot on every page, so just append
    } else {
      target.insertBefore(wrap, target.firstChild);
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-set-lang]').forEach(function (el) {
      el.addEventListener('click', function (e) {
        e.preventDefault();
        window.AtizLang.set(el.getAttribute('data-set-lang'));
      });
    });
    injectHeaderSwitcher();
    // Close any open language dropdown when clicking outside of it
    document.addEventListener('click', function (e) {
      document.querySelectorAll('.lang-switch.open').forEach(function (el) {
        if (!el.contains(e.target)) el.classList.remove('open');
      });
    });
  });
})();
