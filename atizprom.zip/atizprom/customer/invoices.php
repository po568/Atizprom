<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();
$id = (int)($_GET['id'] ?? 0);

if ($id) {
    $invoice = $db->fetchOne("SELECT * FROM invoices WHERE id=? AND customer_id=?", [$id, $user['id']]);
    if (!$invoice) redirect(BASE_URL.'/customer/invoices.php');
    $items = $invoice['items'] ? json_decode($invoice['items'], true) : [];
    $payments = $db->fetchAll("SELECT * FROM payments WHERE invoice_id=? ORDER BY payment_date DESC", [$id]);
} else {
    $invoices = $db->fetchAll("SELECT * FROM invoices WHERE customer_id=? ORDER BY created_at DESC", [$user['id']]);
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Invoices – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include __DIR__ . '/includes/header.php'; ?>
<div class="customer-layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content" style="max-width:820px">

    <?php if ($id && $invoice): ?>
      <a href="<?= BASE_URL ?>/customer/invoices.php" class="customer-breadcrumb" style="display:inline-block"><i class="fas fa-arrow-left"></i> Back to Invoices</a>
      <div class="d-flex justify-content-between align-items-center mt-3 mb-3">
        <div>
          <h2 style="margin-bottom:2px">Invoice #<?= $invoice['invoice_number'] ?></h2>
          <p class="text-muted" style="margin:0">Issued <?= formatDate($invoice['created_at']) ?> · Due <?= formatDate($invoice['due_date']) ?></p>
        </div>
        <?= getStatusBadge($invoice['status']) ?>
      </div>

      <div class="card mb-3">
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Description</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr></thead>
            <tbody>
              <?php foreach ($items as $item): ?>
              <tr>
                <td><?= htmlspecialchars($item['description'] ?? '') ?></td>
                <td><?= (int)($item['qty'] ?? 1) ?></td>
                <td><?= formatCurrency($item['unit_price'] ?? 0) ?></td>
                <td><?= formatCurrency(($item['qty']??1) * ($item['unit_price']??0)) ?></td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($items)): ?><tr><td colspan="4" class="text-muted text-center">No line items</td></tr><?php endif; ?>
            </tbody>
            <tfoot>
              <tr><td colspan="3" style="text-align:right"><strong>Subtotal</strong></td><td><?= formatCurrency($invoice['subtotal']) ?></td></tr>
              <?php if ($invoice['discount'] > 0): ?><tr><td colspan="3" style="text-align:right">Discount</td><td>-<?= formatCurrency($invoice['discount']) ?></td></tr><?php endif; ?>
              <tr><td colspan="3" style="text-align:right">Tax</td><td><?= formatCurrency($invoice['tax']) ?></td></tr>
              <tr style="font-size:1.1rem"><td colspan="3" style="text-align:right"><strong>Total</strong></td><td><strong><?= formatCurrency($invoice['total']) ?></strong></td></tr>
              <tr><td colspan="3" style="text-align:right;color:#155724">Amount Paid</td><td style="color:#155724"><?= formatCurrency($invoice['amount_paid']) ?></td></tr>
              <?php if ($invoice['balance'] < 0): ?>
              <tr><td colspan="3" style="text-align:right;color:#155724"><strong>Credit Balance</strong></td><td style="color:#155724"><strong><?= formatCurrency(abs($invoice['balance'])) ?> overpaid</strong></td></tr>
              <?php else: ?>
              <tr><td colspan="3" style="text-align:right;color:#721C24"><strong>Balance Due</strong></td><td style="color:#721C24"><strong><?= formatCurrency($invoice['balance']) ?></strong></td></tr>
              <?php endif; ?>
            </tfoot>
          </table>
        </div>
        <?php if ($invoice['notes']): ?><div class="card-body" style="border-top:1px solid var(--border)"><small class="text-muted"><strong>Notes:</strong> <?= nl2br(htmlspecialchars($invoice['notes'])) ?></small></div><?php endif; ?>
      </div>

      <div class="card mb-3" style="background:var(--blue-light)">
        <div class="card-body">
          <strong><i class="fas fa-info-circle"></i> How to Pay</strong>
          <p style="margin:6px 0 0;font-size:0.88rem">Payment accepted via Cash, M-Pesa, Airtel Money, Tigo Pesa, HaloPesa, or Bank Transfer. Contact us once you've made payment so we can confirm and update your invoice.</p>
        </div>
      </div>

      <?php if (!empty($payments)): ?>
      <div class="card">
        <div class="card-header"><h4>Payment History</h4></div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Date</th><th>Amount</th><th>Method</th></tr></thead>
            <tbody>
              <?php foreach ($payments as $p): ?>
              <tr><td><?= formatDate($p['payment_date']) ?></td><td style="color:#155724"><strong><?= formatCurrency($p['amount']) ?></strong></td><td><?= htmlspecialchars(ucfirst(str_replace('_',' ',$p['payment_method']))) ?></td></tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endif; ?>

    <?php else: ?>
      <div class="customer-page-header">
        <div class="cph-left">
          <div class="cph-icon"><i class="fas fa-receipt"></i></div>
          <div><h2>Invoices</h2><div class="cph-subtitle">Invoices issued for your approved bookings, quotations, and course enrollments</div></div>
        </div>
      </div>

      <?php if (empty($invoices)): ?>
      <div class="card"><div class="card-body text-center" style="padding:60px">
        <i class="fas fa-receipt" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i>
        <h4>No invoices yet</h4>
        <p class="text-muted">An invoice is issued once your booking or quotation is approved, or your course enrollment is confirmed.</p>
      </div></div>
      <?php else: ?>
      <div style="display:grid;gap:14px">
        <?php foreach ($invoices as $inv): ?>
        <a href="?id=<?= $inv['id'] ?>" class="card" style="text-decoration:none;color:inherit">
          <div class="card-body d-flex align-items-center justify-content-between" style="flex-wrap:wrap">
            <div>
              <strong>Invoice #<?= $inv['invoice_number'] ?></strong><br>
              <small class="text-muted">Due <?= formatDate($inv['due_date']) ?> · Total <?= formatCurrency($inv['total']) ?></small>
            </div>
            <?= getStatusBadge($inv['status']) ?>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    <?php endif; ?>

    </div>
  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
</body>
</html>
