<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();

if ($auth->isLoggedIn()) {
    if ($auth->isAdmin()) redirect(BASE_URL . '/admin/');
    else redirect(BASE_URL . '/customer/');
}

$error = '';
$success = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $result = $auth->login($_POST['email'] ?? '', $_POST['password'] ?? '');
        if ($result['success']) {
            redirect($result['redirect']);
        } else {
            $error = $result['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
body { background: var(--dark-2); display: flex; align-items: center; justify-content: center; min-height: 100vh; }
.login-wrap { width: 100%; max-width: 440px; padding: 20px; }
.login-card { background: var(--white); border-radius: 20px; overflow: hidden; box-shadow: 0 20px 60px rgba(0,0,0,0.4); }
.login-header { background: linear-gradient(135deg, var(--dark-2) 0%, var(--dark-3) 100%); padding: 36px; text-align: center; }
.login-header .logo-icon { width: 64px; height: 64px; border-radius: 16px; font-size: 1.3rem; margin: 0 auto 14px; }
.login-header h1 { color: var(--white); font-size: 1.4rem; margin-bottom: 4px; }
.login-header p { color: rgba(255,255,255,0.6); font-size: 0.85rem; margin: 0; }
.login-body { padding: 36px; }
.login-divider { text-align: center; margin: 16px 0; font-size: 0.8rem; color: var(--text-muted); }
.demo-creds { background: var(--blue-light); border-radius: 10px; padding: 14px; margin-bottom: 20px; font-size: 0.82rem; }
.demo-creds strong { color: var(--blue); display: block; margin-bottom: 8px; }
.demo-creds p { margin: 4px 0; color: var(--text); }
</style>
</head>
<body>
<div class="login-wrap">
  <div class="login-card">
    <div class="login-header">
      <div class="logo-icon d-flex align-items-center justify-content-center" style="background:var(--yellow)">
        <img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo">
      </div>
      <h1>Admin Portal</h1>
      <p>Atiz Prom Management System</p>
    </div>
    <div class="login-body">
      <?php if ($error): ?>
      <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <div class="demo-creds" style="max-height:220px;overflow-y:auto">
        <strong><i class="fas fa-info-circle"></i> Demo Credentials (password for all: <code>password</code>)</strong>
        <p><b>Super Admin:</b> superadmin@atizprom.com</p>
        <p><b>Admin:</b> admin@atizprom.com</p>
        <p><b>Finance Officer:</b> finance@atizprom.com</p>
        <p><b>Production Manager:</b> production@atizprom.com</p>
        <p><b>Graphic Designer:</b> designer@atizprom.com</p>
        <p><b>Course Instructor:</b> instructor@atizprom.com</p>
        <p><b>Inventory Officer:</b> inventory@atizprom.com</p>
      </div>

      <form method="POST" id="loginForm">
        <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
        <div class="form-group">
          <label><i class="fas fa-envelope"></i> Email Address</label>
          <input type="email" name="email" class="form-control" required autocomplete="email"
            placeholder="admin@atizprom.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label><i class="fas fa-lock"></i> Password</label>
          <div style="position:relative">
            <input type="password" name="password" class="form-control" required autocomplete="current-password"
              placeholder="••••••••" id="passwordInput" style="padding-right:44px">
            <button type="button" onclick="togglePwd()" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-muted);cursor:pointer">
              <i class="fas fa-eye" id="pwdIcon"></i>
            </button>
          </div>
        </div>
        <div class="d-flex justify-content-between align-items-center mb-3" style="font-size:0.85rem">
          <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
            <input type="checkbox" name="remember"> Remember me
          </label>
          <a href="<?= BASE_URL ?>/admin/forgot-password.php" style="color:var(--blue)">Forgot password?</a>
        </div>
        <button type="submit" class="btn btn-primary btn-block btn-lg">
          <i class="fas fa-sign-in-alt"></i> Sign In
        </button>
      </form>
      <div class="login-divider">or</div>
      <a href="<?= BASE_URL ?>/customer/" class="btn btn-outline-primary btn-block">
        <i class="fas fa-user"></i> Customer Portal
      </a>
      <p class="text-center text-muted mt-3" style="font-size:0.8rem">
        <a href="<?= BASE_URL ?>"><i class="fas fa-arrow-left"></i> Back to Website</a>
      </p>
    </div>
  </div>
</div>
<script>
function togglePwd() {
  const input = document.getElementById('passwordInput');
  const icon  = document.getElementById('pwdIcon');
  input.type = input.type === 'password' ? 'text' : 'password';
  icon.className = input.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
}
</script>
</body>
</html>
