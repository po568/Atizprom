<?php
// =====================================================
// ATIZ PROM - Bootstrap / Global Include
// =====================================================

if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

require_once BASE_PATH . '/config/config.php';
require_once BASE_PATH . '/classes/Database.php';
require_once BASE_PATH . '/classes/Auth.php';

// Helper Functions
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function formatCurrency($amount) {
    return 'TZS ' . number_format($amount, 0, '.', ',');
}

function formatDate($date, $format = 'd M Y') {
    return $date ? date($format, strtotime($date)) : '-';
}

function timeAgo($datetime) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);
    if ($diff->y > 0) return $diff->y . ' year' . ($diff->y > 1 ? 's' : '') . ' ago';
    if ($diff->m > 0) return $diff->m . ' month' . ($diff->m > 1 ? 's' : '') . ' ago';
    if ($diff->d > 0) return $diff->d . ' day' . ($diff->d > 1 ? 's' : '') . ' ago';
    if ($diff->h > 0) return $diff->h . ' hour' . ($diff->h > 1 ? 's' : '') . ' ago';
    if ($diff->i > 0) return $diff->i . ' minute' . ($diff->i > 1 ? 's' : '') . ' ago';
    return 'Just now';
}

function uploadFile($file, $subdir = 'documents') {
    $allowedTypes = array_merge(ALLOWED_IMAGE_TYPES, ALLOWED_DOC_TYPES);
    if ($file['size'] > MAX_FILE_SIZE) return ['success' => false, 'message' => 'File too large (max 10MB).'];
    if (!in_array($file['type'], $allowedTypes)) return ['success' => false, 'message' => 'File type not allowed.'];
    
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = bin2hex(random_bytes(16)) . '.' . $ext;
    $dir = UPLOAD_DIR . $subdir . '/';
    
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    if (move_uploaded_file($file['tmp_name'], $dir . $filename)) {
        return ['success' => true, 'path' => $subdir . '/' . $filename, 'url' => UPLOAD_URL . $subdir . '/' . $filename];
    }
    return ['success' => false, 'message' => 'Upload failed.'];
}

function getStatusBadge($status) {
    $map = [
        'pending' => 'warning', 'confirmed' => 'info', 'approved' => 'info',
        'in_progress' => 'primary', 'review' => 'secondary', 'completed' => 'success',
        'delivered' => 'success', 'cancelled' => 'danger', 'sent' => 'info',
        'rejected' => 'danger', 'expired' => 'secondary', 'draft' => 'light',
        'paid' => 'success', 'partial' => 'warning', 'overdue' => 'danger',
        'open' => 'warning', 'resolved' => 'success', 'closed' => 'secondary',
        'active' => 'success', 'signed' => 'success', 'accepted' => 'info',
        'admin_approved' => 'info', 'dropped' => 'danger', 'suspended' => 'secondary',
        'limited' => 'warning', 'out_of_stock' => 'danger', 'in_stock' => 'success',
        'unpaid' => 'danger',
    ];
    $color = $map[$status] ?? 'secondary';
    return "<span class='badge badge-{$color}'>" . ucfirst(str_replace('_', ' ', $status)) . "</span>";
}

function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function redirect($url) {
    if (!headers_sent()) {
        header('Location: ' . $url);
        exit;
    }
    // Headers were already sent (e.g. due to an environment-level output-before-PHP
    // issue) -- fall back to a client-side redirect so navigation still works.
    echo '<script>window.location.href=' . json_encode($url) . ';</script>';
    echo '<meta http-equiv="refresh" content="0;url=' . htmlspecialchars($url) . '">';
    echo '<p>Redirecting... <a href="' . htmlspecialchars($url) . '">Click here if not redirected automatically</a>.</p>';
    exit;
}

function isPost() { return $_SERVER['REQUEST_METHOD'] === 'POST'; }
function isAjax() { return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest'; }

// Returns 'dark' or 'light' based on the atiz_theme cookie, defaulting to light.
// Used in the html tag via themeAttr() so the correct theme applies on first paint, no JS flash.
if (!function_exists('currentTheme')) {
    function currentTheme() {
        $theme = $_COOKIE['atiz_theme'] ?? 'light';
        return $theme === 'dark' ? 'dark' : 'light';
    }
}
if (!function_exists('themeAttr')) {
    function themeAttr() {
        return currentTheme() === 'dark' ? 'data-theme="dark"' : '';
    }
}

// =====================================================
// LANGUAGE / TRANSLATION SYSTEM
// Returns 'en' or 'sw' based on the atiz_lang cookie, defaulting to English.
// t('some_key') looks up the current language's array in /lang/{code}.php and
// falls back to the English value, then to the key itself, so a missing
// translation never breaks the page -- it just shows readable English text.
// =====================================================
if (!function_exists('currentLang')) {
    function currentLang() {
        $lang = isset($_COOKIE['atiz_lang']) ? $_COOKIE['atiz_lang'] : 'en';
        return $lang === 'sw' ? 'sw' : 'en';
    }
}
if (!function_exists('langAttr')) {
    function langAttr() {
        return currentLang();
    }
}
if (!function_exists('loadTranslations')) {
    function loadTranslations($code) {
        static $cache = array();
        if (isset($cache[$code])) return $cache[$code];
        $path = BASE_PATH . '/lang/' . $code . '.php';
        $cache[$code] = file_exists($path) ? include $path : array();
        return $cache[$code];
    }
}
if (!function_exists('t')) {
    function t($key, $replacements = array()) {
        $lang = currentLang();
        $strings = loadTranslations($lang);
        if (isset($strings[$key])) {
            $text = $strings[$key];
        } else {
            // Fall back to English if the key is missing from the active language file
            $en = loadTranslations('en');
            $text = isset($en[$key]) ? $en[$key] : $key;
        }
        if (!empty($replacements)) {
            foreach ($replacements as $find => $replace) {
                $text = str_replace('{' . $find . '}', $replace, $text);
            }
        }
        return $text;
    }
}

function getSetting($key, $default = '') {
    $db = Database::getInstance();
    $row = $db->fetchOne("SELECT setting_value FROM settings WHERE setting_key = ?", [$key]);
    return $row ? $row['setting_value'] : $default;
}

function getNotificationCount($userId) {
    $db = Database::getInstance();
    $row = $db->fetchOne("SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0", [$userId]);
    return $row['c'] ?? 0;
}

// Auto-create a draft digital contract for a booking or project if one doesn't already exist.
// Called when a booking is confirmed or a project is created, so every confirmed piece of work
// has a contract ready for the admin to review and send to the customer for digital sign-off.
// Admins are notified immediately so a draft contract is never silently left unsent.
function ensureContractExists($auth, $type, $recordId) {
    $db = Database::getInstance();

    if ($type === 'booking') {
        $existing = $db->fetchOne("SELECT id FROM contracts WHERE booking_id=?", [$recordId]);
        if ($existing) return $existing['id'];

        $b = $db->fetchOne("SELECT b.*, s.name as service_name, CONCAT(u.first_name,' ',u.last_name) as customer_name FROM bookings b JOIN services s ON b.service_id=s.id JOIN users u ON b.customer_id=u.id WHERE b.id=?", [$recordId]);
        if (!$b) return null;

        $title = "Service Agreement – " . $b['service_name'];
        $content = "This Service Agreement (\"Contract\") is entered into between Atiz Prom (\"Service Provider\") and {$b['customer_name']} (\"Client\") for the provision of {$b['service_name']} services.\n\n"
            . "Booking Reference: {$b['booking_number']}\n"
            . "Event/Service Date: " . ($b['event_date'] ?: 'To be confirmed') . "\n"
            . "Venue: " . ($b['venue'] ?: 'To be confirmed') . "\n\n"
            . "1. SCOPE OF WORK\nThe Service Provider agrees to deliver the {$b['service_name']} service as booked, in line with the standard quality and timelines communicated to the Client.\n\n"
            . "2. PAYMENT TERMS\nTotal agreed amount: " . ($b['total_amount'] ? formatCurrency($b['total_amount']) : 'To be confirmed via quotation') . ". Payment may be made via Cash, M-Pesa, Airtel Money, Tigo Pesa, HaloPesa, or Bank Transfer, as agreed between both parties.\n\n"
            . "3. CANCELLATION\nEither party may request cancellation or rescheduling with reasonable notice. Refund terms, if applicable, will be handled on a case-by-case basis.\n\n"
            . "4. ACCEPTANCE\nBy signing below, both parties agree to the terms of this Contract.";

        $contractNumber = $auth->generateNumber('CT', 'contracts', 'contract_number');
        $id = $db->insert(
            "INSERT INTO contracts (contract_number, customer_id, booking_id, title, content, value, start_date, status, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?,NOW())",
            [$contractNumber, $b['customer_id'], $recordId, $title, $content, $b['total_amount'] ?: null, $b['event_date'] ?: null, 'draft', $_SESSION['user_id'] ?? null]
        );
        notifyAdminsOfDraftContract($db, $contractNumber, $title);
        return $id;
    }

    if ($type === 'project') {
        $existing = $db->fetchOne("SELECT id FROM contracts WHERE project_id=?", [$recordId]);
        if ($existing) return $existing['id'];

        $p = $db->fetchOne("SELECT pr.*, CONCAT(u.first_name,' ',u.last_name) as customer_name FROM projects pr JOIN users u ON pr.customer_id=u.id WHERE pr.id=?", [$recordId]);
        if (!$p) return null;

        $title = "Project Agreement – " . $p['title'];
        $content = "This Project Agreement (\"Contract\") is entered into between Atiz Prom (\"Service Provider\") and {$p['customer_name']} (\"Client\") for the project: {$p['title']}.\n\n"
            . "Project Reference: {$p['project_number']}\n"
            . "Start Date: " . ($p['start_date'] ?: 'To be confirmed') . "\n"
            . "Deadline: " . ($p['deadline'] ?: 'To be confirmed') . "\n\n"
            . "1. SCOPE OF WORK\n" . ($p['description'] ?: 'As discussed and agreed between both parties.') . "\n\n"
            . "2. PAYMENT TERMS\nTotal agreed budget: " . ($p['budget'] ? formatCurrency($p['budget']) : 'To be confirmed') . ". Payment may be made via Cash, M-Pesa, Airtel Money, Tigo Pesa, HaloPesa, or Bank Transfer, as agreed between both parties.\n\n"
            . "3. DELIVERY\nThe Service Provider agrees to deliver the agreed milestones within the timeline above, subject to reasonable adjustments communicated to the Client.\n\n"
            . "4. ACCEPTANCE\nBy signing below, both parties agree to the terms of this Contract.";

        $contractNumber = $auth->generateNumber('CT', 'contracts', 'contract_number');
        $id = $db->insert(
            "INSERT INTO contracts (contract_number, customer_id, project_id, title, content, value, start_date, end_date, status, created_by, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,NOW())",
            [$contractNumber, $p['customer_id'], $recordId, $title, $content, $p['budget'] ?: null, $p['start_date'] ?: null, $p['deadline'] ?: null, 'draft', $_SESSION['user_id'] ?? null]
        );
        notifyAdminsOfDraftContract($db, $contractNumber, $title);
        return $id;
    }

    return null;
}

// Helper used by ensureContractExists() so a newly-drafted contract is never silently
// left unsent -- every super_admin/admin gets an in-app notification immediately.
function notifyAdminsOfDraftContract($db, $contractNumber, $title) {
    $admins = $db->fetchAll("SELECT id FROM users WHERE role_id IN (1,2)");
    foreach ($admins as $a) {
        $db->execute(
            "INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
            [$a['id'], 'New Contract Drafted', "A draft contract \"{$title}\" (#{$contractNumber}) was created and is waiting to be reviewed and sent to the customer.", 'contract', BASE_URL.'/admin/contracts/']
        );
    }
}
