<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();
$id = (int)($_GET['id'] ?? 0);

if (isPost() && isset($_POST['quotation_action'])) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $postId = (int)($_POST['quotation_id'] ?? $id);
        $newStatus = $_POST['quotation_action']==='accept' ? 'accepted' : 'rejected';
        $db->execute("UPDATE quotations SET status=? WHERE id=? AND customer_id=? AND status='sent'", [$newStatus,$postId,$user['id']]);
        $auth->logAudit($user['id'],'QUOTATION_'.strtoupper($newStatus),'quotations',$postId);
        if ($newStatus === 'accepted') {
            $q = $db->fetchOne("SELECT * FROM quotations WHERE id=?", [$postId]);
            $admins = $db->fetchAll("SELECT id FROM users WHERE role_id IN (1,2)");
            foreach ($admins as $a) {
                $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                    [$a['id'], 'Quotation Accepted by Customer', "{$user['first_name']} {$user['last_name']} accepted quotation #{$q['quotation_number']}. Final approval needed.", 'quotation', BASE_URL.'/admin/quotations/']);
            }
        }
        redirect(BASE_URL.'/customer/quotations/view.php?id='.$postId.'&done=1');
    }
}

$q = $db->fetchOne("SELECT * FROM quotations WHERE id=? AND customer_id=?", [$id, $user['id']]);
if (!$q) redirect(BASE_URL.'/customer/quotations/');
$items = $q['items'] ? json_decode($q['items'], true) : [];
$attachments = $q['attachments'] ? json_decode($q['attachments'], true) : [];
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Quotation <?= $q['quotation_number'] ?> – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include BASE_PATH . '/customer/includes/header.php'; ?>
<div class="customer-layout">
  <?php include BASE_PATH . '/customer/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content" style="max-width:800px">
      <a href="<?= BASE_URL ?>/customer/quotations/" class="customer-breadcrumb" style="display:inline-block"><i class="fas fa-arrow-left"></i> Back to Quotations</a>

      <?php if (isset($_GET['done'])): ?><div class="alert alert-success mt-3">Your response has been recorded.</div><?php endif; ?>

      <div class="d-flex align-items-center justify-content-between mt-3 mb-4">
        <div>
          <h2 style="margin-bottom:4px"><?= htmlspecialchars($q['title']) ?></h2>
          <p class="text-muted" style="margin:0">Quote #<?= $q['quotation_number'] ?> · Requested <?= timeAgo($q['created_at']) ?></p>
        </div>
        <?= getStatusBadge($q['status']) ?>
      </div>

      <div class="card mb-3">
        <div class="card-header"><h4>Description</h4></div>
        <div class="card-body"><p><?= nl2br(htmlspecialchars($q['description'] ?: 'No description provided.')) ?></p></div>
      </div>

      <?php if (!empty($items)): ?>
      <div class="card mb-3">
        <div class="card-header"><h4>Itemized Request</h4></div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Item</th><th>Qty</th><th>Est. Price</th><th>Total</th></tr></thead>
            <tbody>
              <?php foreach ($items as $it): ?>
              <tr><td><?= htmlspecialchars($it['name'] ?? '') ?></td><td><?= htmlspecialchars($it['qty'] ?? '') ?></td><td><?= formatCurrency($it['unit_price'] ?? 0) ?></td><td><?= formatCurrency($it['total'] ?? 0) ?></td></tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endif; ?>

      <?php if (!empty($attachments)): ?>
      <div class="card mb-3">
        <div class="card-header"><h4>Attachments</h4></div>
        <div class="card-body">
          <?php foreach ($attachments as $a): ?>
          <a href="<?= UPLOAD_URL . $a ?>" target="_blank" class="d-flex align-items-center gap-2" style="padding:8px 0;border-bottom:1px solid var(--border)"><i class="fas fa-paperclip text-primary"></i> <?= basename($a) ?></a>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <div class="card">
        <div style="background:linear-gradient(135deg,var(--blue),var(--blue-dark));padding:24px;text-align:center;border-radius:14px 14px 0 0">
          <div style="font-size:1.6rem;font-weight:900;color:#fff"><?= $q['total']>0 ? formatCurrency($q['total']) : 'Awaiting Price' ?></div>
          <small style="color:rgba(255,255,255,0.7)">Quoted Total</small>
        </div>
        <?php if ($q['admin_notes']): ?>
        <div class="card-body">
          <strong>Note from Atiz Prom:</strong>
          <p style="margin-top:6px"><?= nl2br(htmlspecialchars($q['admin_notes'])) ?></p>
        </div>
        <?php endif; ?>
        <?php if ($q['status']==='sent'): ?>
        <div class="card-footer d-flex gap-2 justify-content-end">
          <form method="POST" style="display:inline">
            <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
            <input type="hidden" name="quotation_id" value="<?= $q['id'] ?>">
            <button type="submit" name="quotation_action" value="reject" class="btn" style="border:1px solid #DC3545;color:#DC3545" onclick="return confirm('Decline this quotation?')"><i class="fas fa-times"></i> Decline</button>
          </form>
          <form method="POST" style="display:inline">
            <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
            <input type="hidden" name="quotation_id" value="<?= $q['id'] ?>">
            <button type="submit" name="quotation_action" value="accept" class="btn btn-success"><i class="fas fa-check"></i> Accept Price</button>
          </form>
        </div>
        <?php elseif ($q['status']==='accepted'): ?>
        <div class="card-footer text-center">
          <span class="badge badge-info"><i class="fas fa-clock"></i> You accepted this price — awaiting Atiz Prom's final approval</span>
        </div>
        <?php endif; ?>
      </div>

    </div>
  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
</body>
</html>
