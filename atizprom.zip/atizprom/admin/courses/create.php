<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$instructors = $db->fetchAll("SELECT id, first_name, last_name FROM users WHERE role_id=6 AND is_active=1 ORDER BY first_name");
$catLabels = ['computer_basics'=>'Computer Basics','microsoft_office'=>'Microsoft Office','graphic_design'=>'Graphic Design','web_development'=>'Web Development','video_editing'=>'Video Editing','networking'=>'Networking','programming'=>'Programming','digital_marketing'=>'Digital Marketing'];
$error = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $slug = strtolower(trim(preg_replace('/[^a-zA-Z0-9]+/', '-', $_POST['title'])), '-');
        $thumbnail = null;
        if (!empty($_FILES['thumbnail']['tmp_name'])) {
            $r = uploadFile($_FILES['thumbnail'], 'courses');
            if ($r['success']) $thumbnail = $r['path'];
        }
        $id = $db->insert(
            "INSERT INTO courses (instructor_id, title, slug, description, category, mode, duration, price, max_students, thumbnail, syllabus, requirements, is_active, is_featured, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())",
            [$_POST['instructor_id']?:null, trim($_POST['title']), $slug.'-'.substr(md5(microtime()),0,5), trim($_POST['description']??''), $_POST['category'], $_POST['mode'], trim($_POST['duration']??''), (float)$_POST['price'], (int)$_POST['max_students'], $thumbnail, trim($_POST['syllabus']??''), trim($_POST['requirements']??''), isset($_POST['is_active'])?1:0, isset($_POST['is_featured'])?1:0]
        );
        $auth->logAudit($user['id'], 'COURSE_CREATED', 'courses', $id);
        redirect(BASE_URL.'/admin/courses/?created=1');
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>New Course – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">New Course</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/courses/">Courses</a> <span class="sep">/</span> New</div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:720px">
    <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <div class="card">
        <div class="card-header"><h4>Course Details</h4></div>
        <div class="card-body">
          <div class="form-group"><label>Course Title *</label><input type="text" name="title" class="form-control" required></div>
          <div class="form-group"><label>Description</label><textarea name="description" class="form-control" rows="3"></textarea></div>
          <div class="form-row">
            <div class="form-group">
              <label>Category *</label>
              <select name="category" class="form-control" required>
                <?php foreach ($catLabels as $k=>$v): ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Mode</label>
              <select name="mode" class="form-control">
                <option value="offline">Offline</option><option value="online">Online</option><option value="hybrid">Hybrid</option>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group"><label>Duration</label><input type="text" name="duration" class="form-control" placeholder="e.g. 6 Weeks"></div>
            <div class="form-group"><label>Price (TZS) *</label><input type="number" name="price" class="form-control" required min="0" step="1000"></div>
          </div>
          <div class="form-row">
            <div class="form-group"><label>Max Students</label><input type="number" name="max_students" class="form-control" value="30" min="1"></div>
            <div class="form-group">
              <label>Assign Instructor</label>
              <select name="instructor_id" class="form-control">
                <option value="">Unassigned for now</option>
                <?php foreach ($instructors as $i): ?><option value="<?= $i['id'] ?>"><?= htmlspecialchars($i['first_name'].' '.$i['last_name']) ?></option><?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="form-group"><label>Syllabus</label><textarea name="syllabus" class="form-control" rows="3" placeholder="Topics covered, week by week"></textarea></div>
          <div class="form-group"><label>Requirements</label><textarea name="requirements" class="form-control" rows="2" placeholder="Prerequisites, equipment needed"></textarea></div>
          <div class="form-group"><label>Course Thumbnail</label><input type="file" name="thumbnail" class="form-control" accept="image/*"></div>
          <div class="form-row">
            <div class="form-group"><label><input type="checkbox" name="is_active" value="1" checked> Active (visible to customers)</label></div>
            <div class="form-group"><label><input type="checkbox" name="is_featured" value="1"> Feature on homepage</label></div>
          </div>
        </div>
        <div class="card-footer d-flex justify-content-end gap-2">
          <a href="<?= BASE_URL ?>/admin/courses/" class="btn" style="border:1px solid var(--border)">Cancel</a>
          <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create Course</button>
        </div>
      </div>
    </form>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
