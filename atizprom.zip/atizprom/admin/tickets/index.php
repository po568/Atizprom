<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$success = ''; $error = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } elseif (isset($_POST['ticket_id']) && isset($_POST['reply'])) {
        $tid = (int)$_POST['ticket_id'];
        $db->insert("INSERT INTO ticket_replies (ticket_id,user_id,message) VALUES (?,?,?)", [$tid, $user['id'], trim($_POST['reply'])]);
        $newStatus = $_POST['set_status'] ?: 'in_progress';
        $db->execute("UPDATE tickets SET status=?, updated_at=NOW()".($newStatus==='closed'?', closed_at=NOW()':'')." WHERE id=?", [$newStatus, $tid]);
        $t = $db->fetchOne("SELECT * FROM tickets WHERE id=?", [$tid]);
        $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
            [$t['customer_id'], 'Reply to Your Ticket', "Atiz Prom replied to ticket #{$t['ticket_number']}: \"{$t['subject']}\"", 'ticket', BASE_URL.'/customer/tickets/?view='.$tid]);
        $auth->logAudit($user['id'], 'TICKET_REPLY', 'tickets', $tid);
        $success = 'Reply sent to customer.';
    } elseif (isset($_POST['assign_ticket'])) {
        $tid = (int)$_POST['ticket_id'];
        $db->execute("UPDATE tickets SET assigned_to=? WHERE id=?", [$_POST['assigned_to']?:null, $tid]);
        $success = 'Ticket assignment updated.';
    } elseif (isset($_POST['update_ticket_status'])) {
        $tid = (int)$_POST['ticket_id'];
        $closedAt = $_POST['new_status'] === 'closed' ? ', closed_at=NOW()' : '';
        $db->execute("UPDATE tickets SET status=?, updated_at=NOW()".$closedAt." WHERE id=?", [$_POST['new_status'], $tid]);
        $success = 'Ticket status updated.';
    }
}

$viewId = (int)($_GET['view'] ?? 0);
if ($viewId) {
    $ticket = $db->fetchOne("SELECT t.*, CONCAT(u.first_name,' ',u.last_name) as customer_name, u.email FROM tickets t JOIN users u ON t.customer_id=u.id WHERE t.id=?", [$viewId]);
    if (!$ticket) redirect(BASE_URL.'/admin/tickets/');
    $replies = $db->fetchAll("SELECT tr.*, CONCAT(u.first_name,' ',u.last_name) as author, u.role_id FROM ticket_replies tr JOIN users u ON tr.user_id=u.id WHERE tr.ticket_id=? ORDER BY tr.created_at ASC", [$viewId]);
    $staffList = $db->fetchAll("SELECT id, first_name, last_name FROM users WHERE role_id IN (1,2) AND is_active=1 ORDER BY first_name");
} else {
    $ticket = null; $replies = [];
    $statusFilter = $_GET['status'] ?? '';
    $where = ['1=1']; $params = []; $types = '';
    if ($statusFilter) { $where[] = 't.status=?'; $params[] = $statusFilter; $types .= 's'; }
    $tickets = $db->fetchAll(
        "SELECT t.*, CONCAT(u.first_name,' ',u.last_name) as customer_name FROM tickets t JOIN users u ON t.customer_id=u.id WHERE ".implode(' AND ',$where)." ORDER BY t.updated_at DESC",
        $params, $types
    );
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Support Tickets – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Support Tickets</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Support Tickets</div></div>
    </div>
  </div>
  <div class="content-body">
    <?php if ($success): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <?php if ($ticket): ?>
    <!-- TICKET THREAD VIEW -->
    <div style="max-width:800px">
      <a href="<?= BASE_URL ?>/admin/tickets/" style="color:var(--text-muted);font-size:0.85rem"><i class="fas fa-arrow-left"></i> Back to Tickets</a>

      <div class="d-flex align-items-center justify-content-between mt-3 mb-3">
        <div>
          <h3 style="margin-bottom:2px"><?= htmlspecialchars($ticket['subject']) ?></h3>
          <p class="text-muted" style="margin:0"><?= htmlspecialchars($ticket['customer_name']) ?> (<?= htmlspecialchars($ticket['email']) ?>) · Ticket #<?= $ticket['ticket_number'] ?></p>
        </div>
        <?= getStatusBadge($ticket['status']) ?>
      </div>

      <div class="card mb-3">
        <div class="card-body d-flex gap-3" style="flex-wrap:wrap;align-items:center">
          <form method="POST" class="d-flex gap-2 align-items-center">
            <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
            <input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>">
            <input type="hidden" name="assign_ticket" value="1">
            <label style="font-size:0.85rem;margin:0">Assigned to:</label>
            <select name="assigned_to" class="form-control" style="width:auto" onchange="this.form.submit()">
              <option value="">Unassigned</option>
              <?php foreach ($staffList as $s): ?>
              <option value="<?= $s['id'] ?>" <?= $ticket['assigned_to']==$s['id']?'selected':'' ?>><?= htmlspecialchars($s['first_name'].' '.$s['last_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </form>
          <form method="POST" class="d-flex gap-2 align-items-center">
            <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
            <input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>">
            <input type="hidden" name="update_ticket_status" value="1">
            <label style="font-size:0.85rem;margin:0">Status:</label>
            <select name="new_status" class="form-control" style="width:auto" onchange="this.form.submit()">
              <?php foreach (['open','in_progress','resolved','closed'] as $s): ?>
              <option value="<?= $s ?>" <?= $ticket['status']===$s?'selected':'' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
              <?php endforeach; ?>
            </select>
          </form>
          <span class="text-muted" style="font-size:0.85rem;margin-left:auto"><?= ucfirst($ticket['category']) ?> · <?= ucfirst($ticket['priority']) ?> priority · Opened <?= timeAgo($ticket['created_at']) ?></span>
        </div>
      </div>

      <div class="card mb-3">
        <div class="card-body">
          <div class="ticket-thread">
            <?php foreach ($replies as $r): ?>
            <div class="ticket-message <?= $r['role_id'] != 8 ? 'admin' : '' ?>">
              <div class="msg-avatar <?= $r['role_id'] == 8 ? 'customer' : 'staff' ?>"><?= strtoupper(substr($r['author'],0,1)) ?></div>
              <div>
                <div style="font-size:0.78rem;font-weight:600;margin-bottom:4px;color:var(--text-muted)"><?= htmlspecialchars($r['author']) ?> · <?= timeAgo($r['created_at']) ?></div>
                <div class="msg-bubble"><p><?= nl2br(htmlspecialchars($r['message'])) ?></p></div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <?php if ($ticket['status'] !== 'closed'): ?>
        <div class="card-footer">
          <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
            <input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>">
            <div class="form-group">
              <textarea name="reply" class="form-control" rows="3" required placeholder="Type your reply to the customer..."></textarea>
            </div>
            <div class="d-flex justify-content-between align-items-center">
              <div class="d-flex gap-2 align-items-center">
                <label style="font-size:0.85rem;margin:0">Mark as:</label>
                <select name="set_status" class="form-control" style="width:auto">
                  <option value="in_progress">In Progress</option>
                  <option value="resolved">Resolved</option>
                  <option value="closed">Closed</option>
                </select>
              </div>
              <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send Reply</button>
            </div>
          </form>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <?php else: ?>
    <!-- TICKETS LIST -->
    <div class="card">
      <div class="card-body">
        <div class="d-flex align-items-center gap-3 mb-3">
          <div style="width:50px;height:50px;border-radius:14px;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center;font-size:1.4rem"><i class="fas fa-headset"></i></div>
          <div><h3 style="margin-bottom:2px">Support Tickets</h3><p class="text-muted" style="margin:0">Respond to customer inquiries, complaints, and technical issues.</p></div>
        </div>
        <div class="dt-filters mb-3">
          <a href="?" class="btn btn-sm <?= !$statusFilter?'btn-primary':'btn-outline-primary' ?>">All</a>
          <?php foreach (['open'=>'Open','in_progress'=>'In Progress','resolved'=>'Resolved','closed'=>'Closed'] as $k=>$v): ?>
          <a href="?status=<?= $k ?>" class="btn btn-sm <?= $statusFilter===$k?'btn-primary':'btn-outline-primary' ?>"><?= $v ?></a>
          <?php endforeach; ?>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Ticket #</th><th>Customer</th><th>Subject</th><th>Category</th><th>Priority</th><th>Status</th><th>Last Update</th><th>Action</th></tr></thead>
            <tbody>
              <?php foreach ($tickets as $t): ?>
              <tr>
                <td><strong style="color:var(--blue)"><?= $t['ticket_number'] ?></strong></td>
                <td><?= htmlspecialchars($t['customer_name']) ?></td>
                <td><?= htmlspecialchars($t['subject']) ?></td>
                <td><?= ucfirst($t['category']) ?></td>
                <td><?= ucfirst($t['priority']) ?></td>
                <td><?= getStatusBadge($t['status']) ?></td>
                <td><?= timeAgo($t['updated_at']) ?></td>
                <td><a href="?view=<?= $t['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-reply"></i> Respond</a></td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($tickets)): ?>
              <tr><td colspan="8" class="text-center text-muted" style="padding:40px">No support tickets yet</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
