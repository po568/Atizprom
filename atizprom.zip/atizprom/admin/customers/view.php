<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin']);

$db = Database::getInstance();
$id = (int)($_GET['id'] ?? 0);
$customer = $db->fetchOne("SELECT * FROM users WHERE id=? AND role_id=8", [$id]);
if (!$customer) redirect(BASE_URL.'/admin/customers/');

$bookings = $db->fetchAll("SELECT b.*, s.name as service_name FROM bookings b JOIN services s ON b.service_id=s.id WHERE b.customer_id=? ORDER BY b.created_at DESC LIMIT 10", [$id]);
$projects = $db->fetchAll("SELECT * FROM projects WHERE customer_id=? ORDER BY created_at DESC LIMIT 10", [$id]);
$quotations = $db->fetchAll("SELECT * FROM quotations WHERE customer_id=? ORDER BY created_at DESC LIMIT 10", [$id]);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($customer['first_name'].' '.$customer['last_name']) ?> – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Customer Profile</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/customers/">Customers</a> <span class="sep">/</span> View</div></div>
    </div>
    <div class="header-actions"><a href="<?= BASE_URL ?>/admin/customers/edit.php?id=<?= $id ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i> Edit</a></div>
  </div>
  <div class="content-body">
    <?php if (isset($_GET['created'])): ?><div class="alert alert-success mb-3">Customer created successfully!</div><?php endif; ?>

    <div class="card mb-3">
      <div class="card-body d-flex align-items-center gap-3" style="flex-wrap:wrap">
        <div style="width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,var(--blue),var(--yellow));color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:1.4rem"><?= strtoupper(substr($customer['first_name'],0,1)) ?></div>
        <div>
          <h3 style="margin-bottom:2px"><?= htmlspecialchars($customer['first_name'].' '.$customer['last_name']) ?></h3>
          <p class="text-muted" style="margin:0"><?= htmlspecialchars($customer['email']) ?> · <?= htmlspecialchars($customer['phone'] ?: '-') ?></p>
        </div>
        <div style="margin-left:auto">
          <?= $customer['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>' ?>
        </div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:20px">
      <div class="stat-card"><div class="stat-value"><?= count($bookings) ?></div><div class="stat-label">Recent Bookings</div></div>
      <div class="stat-card"><div class="stat-value"><?= count($projects) ?></div><div class="stat-label">Projects</div></div>
      <div class="stat-card"><div class="stat-value"><?= count($quotations) ?></div><div class="stat-label">Quotations</div></div>
    </div>

    <div class="card mb-3">
      <div class="card-header"><h4>Recent Bookings</h4></div>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>Booking #</th><th>Service</th><th>Date</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($bookings as $b): ?>
          <tr><td><?= $b['booking_number'] ?></td><td><?= htmlspecialchars($b['service_name']) ?></td><td><?= formatDate($b['created_at']) ?></td><td><?= getStatusBadge($b['status']) ?></td></tr>
          <?php endforeach; ?>
          <?php if (empty($bookings)): ?><tr><td colspan="4" class="text-center text-muted" style="padding:30px">No bookings</td></tr><?php endif; ?>
        </tbody>
      </table></div>
    </div>

    <div class="card">
      <div class="card-header"><h4>Quotation Requests</h4></div>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>Quote #</th><th>Title</th><th>Amount</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($quotations as $q): ?>
          <tr><td><?= $q['quotation_number'] ?></td><td><?= htmlspecialchars($q['title']) ?></td><td><?= $q['total']?formatCurrency($q['total']):'-' ?></td><td><?= getStatusBadge($q['status']) ?></td></tr>
          <?php endforeach; ?>
          <?php if (empty($quotations)): ?><tr><td colspan="4" class="text-center text-muted" style="padding:30px">No quotations</td></tr><?php endif; ?>
        </tbody>
      </table></div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
