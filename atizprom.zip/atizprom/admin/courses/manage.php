<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','course_instructor']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$roleId = $_SESSION['user_role'];
$id = (int)($_GET['id'] ?? 0);

$course = $db->fetchOne("SELECT * FROM courses WHERE id=?", [$id]);
if (!$course) redirect(BASE_URL.'/admin/courses/');
// Instructors can only manage their own assigned courses
if ($roleId == 6 && $course['instructor_id'] != $user['id']) redirect(BASE_URL.'/admin/courses/');

if (isPost()) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $postId = (int)($_POST['course_id'] ?? $id);
        if (isset($_POST['add_lesson'])) {
            $fileAttachment = null;
            if (!empty($_FILES['lesson_file']['tmp_name'])) {
                $r = uploadFile($_FILES['lesson_file'], 'documents');
                if ($r['success']) $fileAttachment = $r['path'];
            }
            $sortOrder = $db->fetchOne("SELECT COUNT(*) c FROM course_lessons WHERE course_id=?", [$postId])['c'];
            $db->insert(
                "INSERT INTO course_lessons (course_id, title, description, content, video_url, file_attachment, duration_minutes, scheduled_date, scheduled_time, sort_order, is_active, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,1,NOW())",
                [$postId, trim($_POST['l_title']), trim($_POST['l_description']??''), trim($_POST['l_content']??''), trim($_POST['l_video_url']??''), $fileAttachment, (int)($_POST['l_duration']??0), $_POST['l_scheduled_date']?:null, $_POST['l_scheduled_time']?:null, $sortOrder]
            );
            // Notify active students of the new scheduled lesson
            if ($_POST['l_scheduled_date']) {
                $students = $db->fetchAll("SELECT student_id FROM course_enrollments WHERE course_id=? AND status='active'", [$postId]);
                foreach ($students as $s) {
                    $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                        [$s['student_id'], 'New Lesson Scheduled', "\"".trim($_POST['l_title'])."\" has been scheduled for ".formatDate($_POST['l_scheduled_date']), 'course', BASE_URL.'/customer/my-courses.php?id='.$postId]);
                }
            }
            redirect(BASE_URL.'/admin/courses/manage.php?id='.$postId.'&lesson_added=1');
        } elseif (isset($_POST['delete_lesson'])) {
            $db->execute("DELETE FROM course_lessons WHERE id=? AND course_id=?", [(int)$_POST['lesson_id'], $postId]);
            redirect(BASE_URL.'/admin/courses/manage.php?id='.$postId.'&lesson_deleted=1');
        } elseif (isset($_POST['update_enrollment_progress'])) {
            $db->execute("UPDATE course_enrollments SET progress=? WHERE id=? AND course_id=?", [(int)$_POST['progress'], (int)$_POST['enrollment_id'], $postId]);
            redirect(BASE_URL.'/admin/courses/manage.php?id='.$postId.'&progress_updated=1');
        } elseif (isset($_POST['upload_material'])) {
            if (!empty($_FILES['material_file']['tmp_name'])) {
                $r = uploadFile($_FILES['material_file'], 'documents');
                if ($r['success']) {
                    $ext = strtoupper(pathinfo($_FILES['material_file']['name'], PATHINFO_EXTENSION));
                    $db->insert(
                        "INSERT INTO course_materials (course_id, lesson_id, title, description, file_path, file_type, uploaded_by, created_at) VALUES (?,?,?,?,?,?,?,NOW())",
                        [$postId, $_POST['m_lesson_id']?:null, trim($_POST['m_title']), trim($_POST['m_description']??''), $r['path'], $ext, $user['id']]
                    );
                    // Notify active students that new materials are available
                    $students = $db->fetchAll("SELECT student_id FROM course_enrollments WHERE course_id=? AND status='active'", [$postId]);
                    foreach ($students as $s) {
                        $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                            [$s['student_id'], 'New Learning Material', "\"".trim($_POST['m_title'])."\" has been uploaded for your course.", 'course', BASE_URL.'/customer/my-courses.php?id='.$postId]);
                    }
                    redirect(BASE_URL.'/admin/courses/manage.php?id='.$postId.'&material_added=1');
                }
            }
            redirect(BASE_URL.'/admin/courses/manage.php?id='.$postId.'&material_error=1');
        } elseif (isset($_POST['delete_material'])) {
            $db->execute("DELETE FROM course_materials WHERE id=? AND course_id=?", [(int)$_POST['material_id'], $postId]);
            redirect(BASE_URL.'/admin/courses/manage.php?id='.$postId.'&material_deleted=1');
        }
    }
}

$lessons = $db->fetchAll("SELECT * FROM course_lessons WHERE course_id=? ORDER BY scheduled_date IS NULL, scheduled_date, sort_order", [$id]);
$enrollments = $db->fetchAll("SELECT ce.*, CONCAT(u.first_name,' ',u.last_name) as student_name, u.email FROM course_enrollments ce JOIN users u ON ce.student_id=u.id WHERE ce.course_id=? ORDER BY ce.enrolled_at DESC", [$id]);
$materials = $db->fetchAll("SELECT * FROM course_materials WHERE course_id=? ORDER BY created_at DESC", [$id]);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($course['title']) ?> – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title"><?= htmlspecialchars($course['title']) ?></div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/courses/">Courses</a> <span class="sep">/</span> Manage</div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:900px">
    <?php if (isset($_GET['lesson_added'])): ?><div class="alert alert-success mb-3">Lesson scheduled successfully!</div><?php endif; ?>
    <?php if (isset($_GET['lesson_deleted'])): ?><div class="alert alert-success mb-3">Lesson removed.</div><?php endif; ?>
    <?php if (isset($_GET['progress_updated'])): ?><div class="alert alert-success mb-3">Student progress updated.</div><?php endif; ?>
    <?php if (isset($_GET['material_added'])): ?><div class="alert alert-success mb-3">Learning material uploaded — enrolled students have been notified!</div><?php endif; ?>
    <?php if (isset($_GET['material_deleted'])): ?><div class="alert alert-success mb-3">Material removed.</div><?php endif; ?>
    <?php if (isset($_GET['material_error'])): ?><div class="alert alert-danger mb-3">Please choose a file to upload.</div><?php endif; ?>

    <!-- Tabs -->
    <div style="display:flex;gap:0;border-bottom:2px solid var(--border);margin-bottom:24px">
      <button class="ctab active" data-tab="lessons" onclick="switchCTab('lessons',this)" style="padding:10px 20px;border:none;background:none;cursor:pointer;font-weight:600;border-bottom:3px solid var(--blue);color:var(--blue)"><i class="fas fa-calendar-alt"></i> Lessons & Schedule</button>
      <button class="ctab" data-tab="materials" onclick="switchCTab('materials',this)" style="padding:10px 20px;border:none;background:none;cursor:pointer;font-weight:600;color:var(--text-muted)"><i class="fas fa-folder-open"></i> Learning Materials (<?= count($materials) ?>)</button>
      <button class="ctab" data-tab="students" onclick="switchCTab('students',this)" style="padding:10px 20px;border:none;background:none;cursor:pointer;font-weight:600;color:var(--text-muted)"><i class="fas fa-users"></i> Enrolled Students (<?= count($enrollments) ?>)</button>
    </div>

    <div id="ctab-lessons">
      <div class="card mb-3">
        <div class="card-header"><h4>Schedule a New Lesson</h4></div>
        <form method="POST" enctype="multipart/form-data">
          <div class="card-body">
            <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
            <input type="hidden" name="add_lesson" value="1">
            <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
            <div class="form-group"><label>Lesson Title *</label><input type="text" name="l_title" class="form-control" required></div>
            <div class="form-group"><label>Description</label><textarea name="l_description" class="form-control" rows="2"></textarea></div>
            <div class="form-row">
              <div class="form-group"><label>Scheduled Date</label><input type="date" name="l_scheduled_date" class="form-control"></div>
              <div class="form-group"><label>Scheduled Time</label><input type="time" name="l_scheduled_time" class="form-control"></div>
              <div class="form-group"><label>Duration (minutes)</label><input type="number" name="l_duration" class="form-control" min="0" placeholder="60"></div>
            </div>
            <div class="form-group"><label>Video URL (optional)</label><input type="url" name="l_video_url" class="form-control" placeholder="https://..."></div>
            <div class="form-group"><label>Lesson Material (optional)</label><input type="file" name="lesson_file" class="form-control"></div>
            <div class="form-group"><label>Notes / Content</label><textarea name="l_content" class="form-control" rows="2" placeholder="Additional notes for this lesson"></textarea></div>
          </div>
          <div class="card-footer text-right"><button class="btn btn-primary"><i class="fas fa-calendar-plus"></i> Schedule Lesson</button></div>
        </form>
      </div>

      <div class="card">
        <div class="card-header"><h4>Scheduled Lessons</h4></div>
        <div class="card-body" style="padding:0">
          <?php if (empty($lessons)): ?>
          <p class="text-muted text-center" style="padding:30px">No lessons scheduled yet</p>
          <?php else: ?>
          <?php foreach ($lessons as $i => $l): ?>
          <div style="padding:14px 20px;border-bottom:1px solid var(--border);display:flex;gap:12px;align-items:flex-start">
            <div style="width:30px;height:30px;border-radius:50%;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.85rem;flex-shrink:0"><?= $i+1 ?></div>
            <div style="flex:1">
              <strong><?= htmlspecialchars($l['title']) ?></strong>
              <div style="font-size:0.82rem;color:var(--text-muted)">
                <?= $l['scheduled_date'] ? formatDate($l['scheduled_date']) : 'Not yet scheduled' ?><?= $l['scheduled_time'] ? ' at '.date('H:i', strtotime($l['scheduled_time'])) : '' ?>
                <?= $l['duration_minutes'] ? ' · '.$l['duration_minutes'].' min' : '' ?>
              </div>
            </div>
            <form method="POST" onsubmit="return confirm('Remove this lesson?')">
              <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
              <input type="hidden" name="delete_lesson" value="1">
              <input type="hidden" name="lesson_id" value="<?= $l['id'] ?>">
              <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
              <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
            </form>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <div id="ctab-materials" style="display:none">
      <div class="card mb-3">
        <div class="card-header"><h4>Upload Learning Material</h4></div>
        <form method="POST" enctype="multipart/form-data">
          <div class="card-body">
            <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
            <input type="hidden" name="upload_material" value="1">
            <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
            <div class="form-group"><label>Material Title *</label><input type="text" name="m_title" class="form-control" required placeholder="e.g. Week 1 Slides, Course Syllabus"></div>
            <div class="form-group"><label>Description</label><textarea name="m_description" class="form-control" rows="2"></textarea></div>
            <div class="form-group">
              <label>Link to a specific lesson (optional)</label>
              <select name="m_lesson_id" class="form-control">
                <option value="">General material (not tied to a lesson)</option>
                <?php foreach ($lessons as $l): ?>
                <option value="<?= $l['id'] ?>"><?= htmlspecialchars($l['title']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group"><label>File *</label><input type="file" name="material_file" class="form-control" required></div>
          </div>
          <div class="card-footer text-right"><button class="btn btn-primary"><i class="fas fa-upload"></i> Upload Material</button></div>
        </form>
      </div>

      <div class="card">
        <div class="card-header"><h4>Uploaded Materials</h4></div>
        <div class="card-body" style="padding:0">
          <?php if (empty($materials)): ?>
          <p class="text-muted text-center" style="padding:30px">No materials uploaded yet</p>
          <?php else: ?>
          <?php foreach ($materials as $m): ?>
          <div style="padding:14px 20px;border-bottom:1px solid var(--border);display:flex;gap:12px;align-items:center">
            <div style="width:38px;height:38px;border-radius:10px;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center;flex-shrink:0"><i class="fas fa-file"></i></div>
            <div style="flex:1">
              <strong><?= htmlspecialchars($m['title']) ?></strong>
              <div style="font-size:0.82rem;color:var(--text-muted)"><?= htmlspecialchars($m['file_type']) ?> · Uploaded <?= timeAgo($m['created_at']) ?></div>
            </div>
            <a href="<?= UPLOAD_URL . $m['file_path'] ?>" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-download"></i></a>
            <form method="POST" onsubmit="return confirm('Remove this material?')">
              <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
              <input type="hidden" name="delete_material" value="1">
              <input type="hidden" name="material_id" value="<?= $m['id'] ?>">
              <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
              <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
            </form>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <div id="ctab-students" style="display:none">
      <div class="card">
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Student</th><th>Status</th><th>Progress</th><th>Payment</th><th>Action</th></tr></thead>
            <tbody>
              <?php foreach ($enrollments as $e): ?>
              <tr>
                <td><?= htmlspecialchars($e['student_name']) ?><br><small class="text-muted"><?= htmlspecialchars($e['email']) ?></small></td>
                <td><?= getStatusBadge($e['status']) ?></td>
                <td><?= $e['progress'] ?>%</td>
                <td><?= getStatusBadge($e['payment_status']) ?></td>
                <td>
                  <?php if ($e['status']==='active'): ?>
                  <form method="POST" class="d-flex gap-1">
                    <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
                    <input type="hidden" name="update_enrollment_progress" value="1">
                    <input type="hidden" name="enrollment_id" value="<?= $e['id'] ?>">
                    <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
                    <input type="number" name="progress" class="form-control" style="width:70px" value="<?= $e['progress'] ?>" min="0" max="100">
                    <button class="btn btn-sm btn-outline-primary">Update</button>
                  </form>
                  <?php else: ?>
                  <small class="text-muted">Awaiting approval</small>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($enrollments)): ?><tr><td colspan="5" class="text-center text-muted" style="padding:30px">No students enrolled yet</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
<script>
function switchCTab(tab, btn) {
  document.querySelectorAll('[id^="ctab-"]').forEach(t => t.style.display='none');
  document.getElementById('ctab-'+tab).style.display='block';
  document.querySelectorAll('.ctab').forEach(b => { b.style.color='var(--text-muted)'; b.style.borderBottom='3px solid transparent'; });
  btn.style.color='var(--blue)'; btn.style.borderBottom='3px solid var(--blue)';
}
</script>
</body>
</html>
