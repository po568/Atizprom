# ATIZ PROM Company Management System
### "Atiz Prom – Home of All Tech Solutions"
**Version 1.0.0** | Kyerwa, Kagera, Tanzania

A complete, production-ready, web-based company management system built with vanilla **PHP 8+, MySQL, HTML5, CSS3, and JavaScript** — no frameworks required. Fully compatible with XAMPP.

---

## 📦 What's Included

- **Public Website** — Hero, services, portfolio, courses, products, testimonials, contact form
- **Customer Portal** — Registration, bookings, quotations, projects, courses, tickets, live chat, invoices, contracts
- **Admin Portal** — Multi-role dashboard with analytics, CRM, finance, project tracking, course & product management
- **Role-Based Access Control** — 8 roles: Super Admin, Admin, Finance Officer, Production Manager, Graphic Designer, Course Instructor, Inventory Officer, Customer
- **Complete MySQL Database** — 35+ tables with full relationships, indexes, and constraints
- **Installation Wizard** — Guided browser-based setup
- **Security** — Password hashing (bcrypt), prepared statements, CSRF protection, session security, login attempt limiting, audit logs

---

## 🚀 Installation Instructions (XAMPP)

### Step 1: Prerequisites
- Install [XAMPP](https://www.apachefriends.org/) (PHP 8.0+ and MySQL/MariaDB)
- Start **Apache** and **MySQL** from the XAMPP Control Panel

### Step 2: Extract the Package
1. Extract `ATIZ_PROM_SYSTEM_V1.zip`
2. Copy the extracted `atizprom` folder into:
   ```
   C:\xampp\htdocs\atizprom\   (Windows)
   /Applications/XAMPP/htdocs/atizprom/   (Mac)
   /opt/lampp/htdocs/atizprom/   (Linux)
   ```

### Step 3: Run the Installer
1. Open your browser and go to: `http://localhost/atizprom/installer/`
2. Follow the 4-step wizard:
   - **Step 1:** Welcome screen
   - **Step 2:** System requirements check (PHP version, extensions, folder permissions)
   - **Step 3:** Enter your database credentials (default MySQL: user `root`, no password)
   - **Step 4:** Installation complete — view your default login credentials

### Step 4: Manual Installation (Alternative)
If you prefer manual setup:
1. Create a MySQL database named `atizprom_db` via phpMyAdmin
2. Import `database/atizprom.sql`
3. Copy `config/config.example.php` to `config/config.php` and edit your DB credentials
4. Ensure `uploads/` subdirectories are writable (`chmod 755`)
5. Visit `http://localhost/atizprom/`

### Step 5: Delete the Installer
**Important:** After installation, delete or rename the `/installer/` folder for security.

---

## 🔐 Default Login Credentials

| Role | Email | Password |
|---|---|---|
| Super Admin | superadmin@atizprom.com | password |
| Admin | admin@atizprom.com | password |
| Finance Officer | finance@atizprom.com | password |
| Production Manager | production@atizprom.com | password |
| Graphic Designer | designer@atizprom.com | password |
| Course Instructor | instructor@atizprom.com | password |
| Inventory Officer | inventory@atizprom.com | password |
| Demo Customer | customer@demo.com | password |

> ⚠️ **Change these passwords immediately in production.**
> All staff accounts log in at `/admin/login.php`. The system routes each role to a tailored dashboard and navigation menu automatically based on their role.

---

## 🗂️ Folder Structure

```
atizprom/
├── admin/              → Admin portal (dashboard, bookings, customers, etc.)
├── customer/            → Customer portal (bookings, courses, profile, etc.)
├── assets/             → CSS, JS, images
├── uploads/            → User-uploaded files (profiles, portfolio, projects...)
├── api/                → AJAX/API endpoints
├── config/             → Configuration files (DB credentials)
├── database/           → SQL schema & seed data
├── classes/            → PHP core classes (Database, Auth)
├── includes/           → Shared bootstrap & helper functions
├── installer/          → Browser-based installation wizard
├── docs/               → Documentation
└── index.php           → Public homepage
```

---

## ✅ What's Fully Functional (V1.2)

- Public marketing site with services, portfolio, courses, products, testimonials, and contact form — contact info, phone, and social links are editable from Settings and reflect live on the site
- Full customer registration, login, password reset, and profile management
- Service booking flow with file attachments and status tracking
- **Digital contracts**: auto-generated as a draft the moment a booking is confirmed or a project is created; admin edits and sends it; both customer and admin digitally sign it; status flows draft → sent → signed
- **Quotation workflow**: admin prices the request, customer can only Accept or Decline (never self-approve), and a final admin approval locks the quotation in — with a quick "Create Invoice" shortcut once approved
- **Course enrollment two-gate approval**: customer enrolls → admin accepts → finance approves (with payment status) → course materials and instructor-scheduled lessons unlock automatically
- **Instructor assignment**: admins assign or reassign any course to a Course Instructor from the courses list; the instructor is notified and the course appears in their portal immediately
- **Instructor course management**: instructors manage their assigned courses, schedule lessons with date/time/duration, and separately upload general or lesson-specific learning materials — students see both a Timetable tab and a Learning Materials tab once approved
- **Finance invoicing**: finance officers generate invoices directly from approved bookings, approved quotations, or active enrollments (auto-filling customer and amount), record payments against any method (Cash, M-Pesa, Airtel Money, Tigo Pesa, HaloPesa, Bank Transfer), and the system automatically tracks balance, status, and notifies the customer
- Project progress tracking with milestones, linked contract, and file deliverables
- Portfolio CRUD: admins/production/design staff can add, edit, and remove showcased events and projects with images
- **Service catalog management**: admins can add, edit, and remove services shown on the public site, with pricing, features, and images
- **Branch management**: admins can add and edit company branches with contact details and manager assignment
- Product catalog CRUD: inventory officers can add, edit, delete, and quick-update stock status (quote-only, no checkout, per spec)
- Support ticket listing and threaded replies
- **Staff account management**: admins can create new staff accounts for any role (instructor, designer, finance, inventory, production) and activate/deactivate them
- **System settings page** (Super Admin only): site info, financial settings, SMTP, and social media links — changes reflect live on the public site and footer
- Role-tailored admin dashboards and a fully role-aware sidebar (with internal scroll) for all 8 roles
- Full audit logging, login attempt lockout, CSRF protection on every form

## 🚧 Known Limitations / Phase 2 Roadmap

The following admin areas have a working landing page (with live data) but no full Create/Edit forms yet: detailed Reports breakdowns beyond the dashboard charts. The underlying database tables and Auth/RBAC layer are already in place, so extending these follows the same pattern as the completed modules.

Email/SMTP sending is configured via Settings but not yet wired to an actual mail-sending call (no PHPMailer included) — password reset tokens, invoice notifications, and other system messages are generated and stored correctly as in-app notifications, but no email is dispatched. Add your preferred mail library or use PHP's `mail()` function where needed.

---

## 🛠️ Technology Stack

- **Frontend:** HTML5, CSS3, Vanilla JavaScript, Chart.js (via CDN)
- **Backend:** PHP 8+ (procedural + OOP classes, mysqli with prepared statements)
- **Database:** MySQL / MariaDB
- **Server:** Apache (XAMPP)

No external frameworks (Laravel, React, Vue, Angular, Node.js) are used, per project requirements.

---

## 🔒 Security Features

- Bcrypt password hashing (cost factor 12)
- Prepared statements throughout (SQL injection prevention)
- CSRF tokens on all forms
- XSS protection via `htmlspecialchars()` sanitization
- Session security (httponly cookies, session regeneration on login)
- Login attempt limiting & account lockout (5 attempts / 30 min lockout)
- Audit logs for all critical actions
- Login logs with IP tracking
- Sensitive directories protected via `.htaccess`

---

## 📧 Email / SMTP Configuration

Edit `config/config.php`:
```php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'atizpromltd@gmail.com');
define('SMTP_PASS', 'your-app-password');
```
Use a Gmail App Password (not your regular password) if using Gmail SMTP.

---

## 📞 Support

**Company:** Atiz Prom
**Location:** Kyerwa, Kagera, Tanzania
**Email:** atizpromltd@gmail.com
**Social:** Facebook / Instagram / TikTok / YouTube — *Atiz Prom Arts*

---

© 2026 Atiz Prom. All Rights Reserved.
