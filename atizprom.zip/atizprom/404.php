<?php
define('BASE_PATH', __DIR__);
require_once __DIR__ . '/includes/bootstrap.php';
http_response_code(404);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Page Not Found – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>body{display:flex;align-items:center;justify-content:center;min-height:100vh;background:var(--dark-2);text-align:center}</style>
</head>
<body>
<div>
  <h1 style="color:var(--yellow);font-size:6rem;margin-bottom:0">404</h1>
  <h2 style="color:#fff;margin-bottom:16px">Page Not Found</h2>
  <p style="color:rgba(255,255,255,0.6);margin-bottom:24px">Sorry, the page you're looking for doesn't exist.</p>
  <a href="<?= BASE_URL ?>" class="btn btn-yellow"><i class="fas fa-home"></i> Back to Home</a>
</div>
</body>
</html>
