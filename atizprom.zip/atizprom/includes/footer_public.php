<footer class="footer">
  <div class="footer-top">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <div class="footer-logo">
            <div class="logo-icon"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div>
            <div class="logo-text"><strong>ATIZ PROM</strong><small>Home of All Tech Solutions</small></div>
          </div>
          <p>Your premier technology and creative media company in Kyerwa, Kagera, Tanzania.</p>
          <div class="footer-social">
            <a href="<?= getSetting('facebook_url', 'https://facebook.com/AtizPromArts') ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
            <a href="<?= getSetting('instagram_url', 'https://instagram.com/atiz_prom') ?>" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="<?= getSetting('tiktok_url', 'https://tiktok.com/@atizpromarts') ?>" target="_blank"><i class="fab fa-tiktok"></i></a>
            <a href="<?= getSetting('youtube_url', 'https://youtube.com/@AtizPromArts') ?>" target="_blank"><i class="fab fa-youtube"></i></a>
          </div>
        </div>
        <div class="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><a href="<?= BASE_URL ?>/">Home</a></li>
            <li><a href="<?= BASE_URL ?>/customer/services.php">Services</a></li>
            <li><a href="<?= BASE_URL ?>/customer/portfolio.php">Portfolio</a></li>
            <li><a href="<?= BASE_URL ?>/customer/courses.php">Courses</a></li>
          </ul>
        </div>
        <div class="footer-contact">
          <h4>Contact Info</h4>
          <p><i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars(getSetting('site_address', 'Kyerwa, Kagera, Tanzania')) ?></p>
          <p><i class="fas fa-envelope"></i> <?= htmlspecialchars(getSetting('site_email', 'atizpromltd@gmail.com')) ?></p>
          <p><i class="fas fa-phone"></i> <?= htmlspecialchars(getSetting('site_phone', '+255626296753')) ?></p>
          <div class="footer-portal-links">
            <a href="<?= BASE_URL ?>/customer/" class="btn btn-sm btn-outline-light">Customer Portal</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="container"><p>&copy; <?= date('Y') ?> Atiz Prom. All Rights Reserved.</p></div>
  </div>
</footer>
