<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','course_instructor']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$roleId = $_SESSION['user_role'];
$isInstructorOnly = $roleId == 6;
$canAssignInstructor = in_array($roleId, [1,2]);

// Admin assigns/reassigns a course to an instructor
if (isPost() && isset($_POST['assign_instructor']) && $canAssignInstructor) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $courseId = (int)$_POST['course_id'];
        $instructorId = $_POST['instructor_id'] ?: null;
        $course = $db->fetchOne("SELECT title, instructor_id FROM courses WHERE id=?", [$courseId]);
        $db->execute("UPDATE courses SET instructor_id=? WHERE id=?", [$instructorId, $courseId]);
        $auth->logAudit($user['id'], 'COURSE_INSTRUCTOR_ASSIGNED', 'courses', $courseId, ['instructor_id'=>$course['instructor_id']], ['instructor_id'=>$instructorId]);
        if ($instructorId) {
            $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                [$instructorId, 'Course Assigned to You', "You've been assigned to teach \"{$course['title']}\". You can now schedule lessons and upload materials.", 'course', BASE_URL.'/admin/courses/manage.php?id='.$courseId]);
        }
        redirect(BASE_URL.'/admin/courses/?assigned=1');
    }
}

// Instructors only see their own assigned courses; admins see all
$where = ['1=1']; $params = []; $types = '';
if ($isInstructorOnly) { $where[] = 'c.instructor_id=?'; $params[] = $user['id']; $types .= 'i'; }
$courses = $db->fetchAll("SELECT c.*, CONCAT(u.first_name,' ',u.last_name) as instructor_name, (SELECT COUNT(*) FROM course_enrollments WHERE course_id=c.id) as total_enrollments FROM courses c LEFT JOIN users u ON c.instructor_id=u.id WHERE ".implode(' AND ',$where)." ORDER BY c.created_at DESC", $params, $types);
$instructors = $canAssignInstructor ? $db->fetchAll("SELECT id, first_name, last_name FROM users WHERE role_id=6 AND is_active=1 ORDER BY first_name") : [];
$catLabels = ['computer_basics'=>'Computer Basics','microsoft_office'=>'Microsoft Office','graphic_design'=>'Graphic Design','web_development'=>'Web Development','video_editing'=>'Video Editing','networking'=>'Networking','programming'=>'Programming','digital_marketing'=>'Digital Marketing'];
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Courses – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Courses</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Courses</div></div>
    </div>
    <div class="header-actions">
      <?php if (!$isInstructorOnly): ?>
      <a href="<?= BASE_URL ?>/admin/courses/create.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> New Course</a>
      <?php endif; ?>
      <a href="<?= BASE_URL ?>/admin/enrollments/" class="btn btn-outline-primary btn-sm"><i class="fas fa-user-graduate"></i> Enrollment Requests</a>
    </div>
  </div>
  <div class="content-body">
    <?php if (isset($_GET['created'])): ?><div class="alert alert-success mb-3">Course created successfully!</div><?php endif; ?>
    <?php if (isset($_GET['assigned'])): ?><div class="alert alert-success mb-3">Instructor assignment updated!</div><?php endif; ?>
    <?php if (empty($courses)): ?>
    <div class="card"><div class="card-body text-center" style="padding:60px">
      <i class="fas fa-graduation-cap" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i>
      <h4>No courses <?= $isInstructorOnly?'assigned to you':'yet' ?></h4>
      <?php if (!$isInstructorOnly): ?><a href="<?= BASE_URL ?>/admin/courses/create.php" class="btn btn-primary mt-2"><i class="fas fa-plus"></i> Create First Course</a><?php endif; ?>
    </div></div>
    <?php else: ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:18px">
      <?php foreach ($courses as $c): ?>
      <div class="card">
        <div class="card-body">
          <span class="badge badge-primary"><?= $catLabels[$c['category']] ?? $c['category'] ?></span>
          <h4 style="margin:8px 0 4px"><?= htmlspecialchars($c['title']) ?></h4>
          <p class="text-muted" style="font-size:0.85rem"><?= htmlspecialchars(substr($c['description']??'',0,90)) ?>...</p>
          <div class="d-flex justify-content-between" style="font-size:0.85rem">
            <span><i class="fas fa-user-tie"></i> <?= htmlspecialchars($c['instructor_name'] ?: 'Unassigned') ?></span>
            <span><i class="fas fa-users"></i> <?= $c['total_enrollments'] ?></span>
          </div>
          <div class="d-flex justify-content-between mt-2">
            <strong style="color:var(--blue)"><?= formatCurrency($c['price']) ?></strong>
            <?= $c['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-secondary">Inactive</span>' ?>
          </div>
          <?php if ($canAssignInstructor): ?>
          <button onclick="openAssignModal(<?= $c['id'] ?>, '<?= addslashes($c['title']) ?>', <?= $c['instructor_id'] ?: 'null' ?>)" class="btn btn-sm btn-outline-primary btn-block mt-2"><i class="fas fa-user-tie"></i> <?= $c['instructor_name'] ? 'Reassign Instructor' : 'Assign Instructor' ?></button>
          <?php endif; ?>
          <a href="<?= BASE_URL ?>/admin/courses/manage.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-primary btn-block mt-2"><i class="fas fa-cog"></i> Manage Lessons & Students</a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
</div>

<?php if ($canAssignInstructor): ?>
<div class="modal-overlay" id="assignModal">
  <div class="modal">
    <div class="modal-header"><h4>Assign Instructor</h4><button class="modal-close" onclick="AtizProm.closeModal('assignModal')"><i class="fas fa-times"></i></button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
        <input type="hidden" name="assign_instructor" value="1">
        <input type="hidden" name="course_id" id="am_course_id">
        <p>Course: <strong id="am_course_title"></strong></p>
        <div class="form-group">
          <label>Instructor</label>
          <select name="instructor_id" id="am_instructor_id" class="form-control">
            <option value="">Unassigned</option>
            <?php foreach ($instructors as $i): ?>
            <option value="<?= $i['id'] ?>"><?= htmlspecialchars($i['first_name'].' '.$i['last_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="AtizProm.closeModal('assignModal')" class="btn" style="border:1px solid var(--border)">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Assignment</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
<?php if ($canAssignInstructor): ?>
<script>
function openAssignModal(courseId, title, instructorId) {
  document.getElementById('am_course_id').value = courseId;
  document.getElementById('am_course_title').textContent = title;
  document.getElementById('am_instructor_id').value = instructorId || '';
  AtizProm.openModal('assignModal');
}
</script>
<?php endif; ?>
</body>
</html>
