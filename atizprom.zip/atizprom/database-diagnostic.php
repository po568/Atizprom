<?php
// =====================================================
// ATIZ PROM - Contract Signing Diagnostic
// Visit this directly in your browser while logged in as
// an admin (or just navigate to it) to see exactly what
// state every contract is in. Delete this file once done.
// =====================================================
define('BASE_PATH', __DIR__);
require_once __DIR__ . '/includes/bootstrap.php';

echo '<!DOCTYPE html><html><head><title>Contract Diagnostic</title>';
echo '<style>body{font-family:monospace;padding:20px;background:#1a1a1a;color:#0f0}
table{border-collapse:collapse;width:100%;margin:14px 0}
th,td{border:1px solid #444;padding:6px 10px;text-align:left;font-size:13px}
th{background:#222}
.warn{color:#fa0}.bad{color:#f55}.good{color:#0f0}
h2{color:#5af}</style></head><body>';
echo '<h1>Contract Signing Diagnostic</h1>';

$db = Database::getInstance();

echo '<h2>1. Does the contracts table have any rows at all?</h2>';
$all = $db->fetchAll("SELECT c.*, CONCAT(u.first_name,' ',u.last_name) as customer_name FROM contracts c JOIN users u ON c.customer_id=u.id ORDER BY c.created_at DESC");
echo '<p>Total contracts in database: <strong>' . count($all) . '</strong></p>';

if (empty($all)) {
    echo '<p class="bad">No contracts exist at all. This means ensureContractExists() has never successfully run.</p>';
    echo '<p>Check: do you have any bookings with status=confirmed, or any projects created? A contract is only created at that moment.</p>';
} else {
    echo '<table><tr><th>ID</th><th>Number</th><th>Customer</th><th>Status</th><th>Has Customer Sig?</th><th>Has Admin Sig?</th><th>Created</th></tr>';
    foreach ($all as $c) {
        $statusClass = $c['status'] === 'sent' ? 'good' : ($c['status'] === 'draft' ? 'warn' : '');
        echo '<tr>';
        echo '<td>' . $c['id'] . '</td>';
        echo '<td>' . htmlspecialchars($c['contract_number']) . '</td>';
        echo '<td>' . htmlspecialchars($c['customer_name']) . '</td>';
        echo '<td class="' . $statusClass . '"><strong>' . htmlspecialchars($c['status']) . '</strong></td>';
        echo '<td>' . ($c['customer_signature'] ? 'YES' : 'no') . '</td>';
        echo '<td>' . ($c['admin_signature'] ? 'YES' : 'no') . '</td>';
        echo '<td>' . $c['created_at'] . '</td>';
        echo '</tr>';
    }
    echo '</table>';

    $draftCount = count(array_filter($all, function($c) { return $c['status'] === 'draft'; }));
    $sentCount = count(array_filter($all, function($c) { return $c['status'] === 'sent'; }));
    $signedCount = count(array_filter($all, function($c) { return $c['status'] === 'signed'; }));

    echo "<p>Draft (not yet sent): <strong class='warn'>$draftCount</strong> — these will show \"Contract Being Prepared\" to the customer, with NO sign button. This is expected until an admin clicks Send.</p>";
    echo "<p>Sent (customer CAN sign right now): <strong class='good'>$sentCount</strong></p>";
    echo "<p>Signed (fully complete): <strong>$signedCount</strong></p>";

    if ($draftCount > 0 && $sentCount === 0) {
        echo '<p class="bad"><strong>LIKELY CAUSE FOUND:</strong> All your contracts are still in "draft" status. The customer cannot sign a draft contract by design — an admin must open it at /admin/contracts/view.php?id=X and click "Send Contract to Customer for Signature" first. Until that happens, the customer will always see "Contract Being Prepared" with no sign button, which looks identical to "cannot sign."</p>';
    }
}

echo '<h2>2. Database column check (catches a mismatched/old schema)</h2>';
$cols = $db->fetchAll("SHOW COLUMNS FROM contracts");
$colNames = array_column($cols, 'Field');
$required = ['id','contract_number','customer_id','booking_id','project_id','title','content','value','status','customer_signature','customer_signed_at','admin_signature','admin_signed_at'];
foreach ($required as $r) {
    $has = in_array($r, $colNames);
    echo '<p class="' . ($has ? 'good' : 'bad') . '">' . ($has ? '✓' : '✗ MISSING:') . " $r</p>";
}

echo '<h2>3. Quick action: force a draft contract to "sent" status for testing</h2>';
if (isset($_GET['force_send']) && is_numeric($_GET['force_send'])) {
    $fid = (int)$_GET['force_send'];
    $db->execute("UPDATE contracts SET status='sent' WHERE id=? AND status='draft'", [$fid]);
    echo '<p class="good">Attempted to force contract #' . $fid . ' to sent status. Refresh this page to see the updated table above, then have the customer log in and visit /customer/contracts.php?id=' . $fid . '</p>';
} else {
    $drafts = array_filter($all, function($c) { return $c['status'] === 'draft'; });
    foreach ($drafts as $d) {
        echo '<p><a style="color:#5af" href="?force_send=' . $d['id'] . '">Force contract #' . $d['id'] . ' (' . htmlspecialchars($d['contract_number']) . ') to sent status →</a></p>';
    }
}

echo '<p style="margin-top:30px;color:#888">Delete this file (database-diagnostic.php) once you are done debugging.</p>';
echo '</body></html>';
