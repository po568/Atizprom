<?php
define('BASE_PATH', __DIR__);
require_once __DIR__ . '/includes/bootstrap.php';
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Privacy Policy – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<nav class="navbar"><div class="container">
  <a href="<?= BASE_URL ?>" class="navbar-brand"><div class="logo-icon"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div><div class="logo-text"><strong>ATIZ PROM</strong></div></a>
  <ul class="nav-menu"><li><a href="<?= BASE_URL ?>">Home</a></li></ul>
</div></nav>
<div style="background:#fff"><main><div class="container" style="padding:50px 20px;max-width:800px">
<h1>Privacy Policy</h1>
<p class="text-muted">Last updated: 2026</p>

<h3 class="mt-4">1. Information We Collect</h3>
<p>We collect information you provide directly, such as your name, email, phone number, address, and details submitted in bookings, quotation requests, and support tickets.</p>

<h3 class="mt-4">2. How We Use Your Information</h3>
<p>Your information is used to process bookings and quotations, manage your account, communicate updates about your services or projects, and improve our offerings.</p>

<h3 class="mt-4">3. Data Storage & Security</h3>
<p>Passwords are stored using industry-standard bcrypt hashing. We employ session security, CSRF protection, and audit logging to protect your account and data.</p>

<h3 class="mt-4">4. Sharing of Information</h3>
<p>We do not sell or rent your personal information to third parties. Information is only shared internally among Atiz Prom staff as needed to fulfill your service requests.</p>

<h3 class="mt-4">5. Cookies & Sessions</h3>
<p>We use session cookies solely to keep you logged in and maintain your portal preferences. No third-party advertising cookies are used.</p>

<h3 class="mt-4">6. Your Rights</h3>
<p>You may update or correct your personal information at any time through your profile settings, or request account deletion by contacting us directly.</p>

<h3 class="mt-4">7. Contact</h3>
<p>For privacy-related questions, contact us at atizpromltd@gmail.com.</p>
</div></main></div>
<?php include __DIR__ . '/includes/footer_public.php'; ?>
</body>
</html>
