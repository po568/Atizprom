<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','production_manager','graphic_designer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$id = (int)($_GET['id'] ?? 0);

if (isPost()) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $postId = (int)($_POST['project_id'] ?? $id);
        if (isset($_POST['update_project'])) {
            $old = $db->fetchOne("SELECT * FROM projects WHERE id=?", [$postId]);
            $db->execute("UPDATE projects SET status=?, progress=?, notes=? WHERE id=?", [$_POST['status'], (int)$_POST['progress'], trim($_POST['notes']??''), $postId]);
            $auth->logAudit($user['id'], 'PROJECT_UPDATED', 'projects', $postId, ['status'=>$old['status']], ['status'=>$_POST['status']]);
            $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                [$old['customer_id'], 'Project Updated', "Your project #{$old['project_number']} is now ".ucfirst(str_replace('_',' ',$_POST['status'])).' ('.(int)$_POST['progress'].'% complete)', 'project', BASE_URL.'/customer/projects/?id='.$postId]);
            redirect(BASE_URL.'/admin/projects/view.php?id='.$postId.'&updated=1');
        } elseif (isset($_POST['add_milestone'])) {
            $db->insert("INSERT INTO project_milestones (project_id, title, description, due_date, status, sort_order, created_at) VALUES (?,?,?,?,?,?,NOW())",
                [$postId, trim($_POST['m_title']), trim($_POST['m_description']??''), $_POST['m_due_date']?:null, 'pending', (int)$db->fetchOne("SELECT COUNT(*) c FROM project_milestones WHERE project_id=?",[$postId])['c']]);
            redirect(BASE_URL.'/admin/projects/view.php?id='.$postId.'&milestone_added=1');
        } elseif (isset($_POST['update_milestone_status'])) {
            $db->execute("UPDATE project_milestones SET status=? WHERE id=? AND project_id=?", [$_POST['milestone_status'], (int)$_POST['milestone_id'], $postId]);
            redirect(BASE_URL.'/admin/projects/view.php?id='.$postId.'&milestone_updated=1');
        }
    }
}

$project = $db->fetchOne("SELECT p.*, CONCAT(u.first_name,' ',u.last_name) as customer_name, u.email FROM projects p JOIN users u ON p.customer_id=u.id WHERE p.id=?", [$id]);
if (!$project) redirect(BASE_URL.'/admin/projects/');
$milestones = $db->fetchAll("SELECT * FROM project_milestones WHERE project_id=? ORDER BY sort_order, due_date", [$id]);
$contract = $db->fetchOne("SELECT * FROM contracts WHERE project_id=?", [$id]);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Project <?= $project['project_number'] ?> – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title"><?= htmlspecialchars($project['title']) ?></div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/projects/">Projects</a> <span class="sep">/</span> <?= $project['project_number'] ?></div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:900px">
    <?php if (isset($_GET['updated'])): ?><div class="alert alert-success mb-3">Project updated successfully!</div><?php endif; ?>
    <?php if (isset($_GET['milestone_added'])): ?><div class="alert alert-success mb-3">Milestone added!</div><?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
      <div>
        <p class="text-muted" style="margin:0">Customer: <strong><?= htmlspecialchars($project['customer_name']) ?></strong> (<?= htmlspecialchars($project['email']) ?>)</p>
      </div>
      <?= getStatusBadge($project['status']) ?>
    </div>

    <?php if ($contract): ?>
    <div class="card mb-3" style="border-left:4px solid var(--blue)">
      <div class="card-body d-flex align-items-center justify-content-between">
        <div>
          <strong><i class="fas fa-file-signature text-primary"></i> Digital Contract <?= $contract['contract_number'] ?></strong>
          <div class="text-muted" style="font-size:0.85rem">Status: <?= getStatusBadge($contract['status']) ?></div>
        </div>
        <a href="<?= BASE_URL ?>/admin/contracts/view.php?id=<?= $contract['id'] ?>" class="btn btn-sm btn-primary">Manage Contract</a>
      </div>
    </div>
    <?php else: ?>
    <div class="alert alert-danger mb-3">No contract found for this project — this shouldn't normally happen since contracts are auto-generated on project creation.</div>
    <?php endif; ?>

    <div class="card mb-3">
      <div class="card-header"><h4>Project Status</h4></div>
      <form method="POST">
        <div class="card-body">
          <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
          <input type="hidden" name="update_project" value="1">
          <input type="hidden" name="project_id" value="<?= $project['id'] ?>">
          <div class="form-row">
            <div class="form-group">
              <label>Status</label>
              <select name="status" class="form-control">
                <?php foreach (['pending','approved','in_progress','review','completed','delivered','cancelled'] as $s): ?>
                <option value="<?= $s ?>" <?= $project['status']===$s?'selected':'' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Progress (%)</label>
              <input type="number" name="progress" class="form-control" min="0" max="100" value="<?= $project['progress'] ?>">
            </div>
          </div>
          <div class="form-group">
            <label>Internal Notes</label>
            <textarea name="notes" class="form-control" rows="2"><?= htmlspecialchars($project['notes'] ?? '') ?></textarea>
          </div>
        </div>
        <div class="card-footer text-right"><button class="btn btn-primary"><i class="fas fa-save"></i> Update Project</button></div>
      </form>
    </div>

    <div class="card mb-3">
      <div class="card-header"><h4>Milestones</h4></div>
      <div class="card-body">
        <?php if (empty($milestones)): ?>
        <p class="text-muted text-center" style="padding:10px">No milestones yet</p>
        <?php else: ?>
        <div class="timeline">
          <?php foreach ($milestones as $m): ?>
          <div class="timeline-item">
            <div class="timeline-dot <?= $m['status'] ?>"></div>
            <div class="timeline-content">
              <h5><?= htmlspecialchars($m['title']) ?></h5>
              <p><?= htmlspecialchars($m['description'] ?? '') ?></p>
              <div class="timeline-time"><?= $m['due_date']?formatDate($m['due_date']):'No due date' ?></div>
              <form method="POST" class="d-flex gap-2 mt-2" style="align-items:center">
                <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
                <input type="hidden" name="update_milestone_status" value="1">
                <input type="hidden" name="milestone_id" value="<?= $m['id'] ?>">
                <input type="hidden" name="project_id" value="<?= $project['id'] ?>">
                <select name="milestone_status" class="form-control" style="width:auto;font-size:0.82rem;padding:4px 8px" onchange="this.form.submit()">
                  <option value="pending" <?= $m['status']==='pending'?'selected':'' ?>>Pending</option>
                  <option value="in_progress" <?= $m['status']==='in_progress'?'selected':'' ?>>In Progress</option>
                  <option value="completed" <?= $m['status']==='completed'?'selected':'' ?>>Completed</option>
                </select>
              </form>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <form method="POST" class="mt-3" style="border-top:1px solid var(--border);padding-top:16px">
          <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
          <input type="hidden" name="add_milestone" value="1">
          <input type="hidden" name="project_id" value="<?= $project['id'] ?>">
          <div class="form-row">
            <div class="form-group"><label>New Milestone Title</label><input type="text" name="m_title" class="form-control" required placeholder="e.g. First draft delivery"></div>
            <div class="form-group"><label>Due Date</label><input type="date" name="m_due_date" class="form-control"></div>
          </div>
          <div class="form-group"><label>Description</label><input type="text" name="m_description" class="form-control" placeholder="Optional details"></div>
          <button type="submit" class="btn btn-sm btn-outline-primary"><i class="fas fa-plus"></i> Add Milestone</button>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
