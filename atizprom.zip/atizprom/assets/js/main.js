// =====================================================
// ATIZ PROM - Main JavaScript
// =====================================================

const AtizProm = {
  baseUrl: '',

  init() {
    this.initNavbar();
    this.initBackToTop();
    this.initToasts();
    this.initModals();
    this.initForms();
    this.detectBaseUrl();
  },

  detectBaseUrl() {
    const scripts = document.querySelectorAll('script[src]');
    scripts.forEach(s => {
      const m = s.src.match(/(.+)\/assets\//);
      if (m) this.baseUrl = m[1];
    });
  },

  // ===== NAVBAR =====
  initNavbar() {
    const toggle = document.getElementById('navToggle');
    const menu = document.getElementById('navMenu');
    const navbar = document.getElementById('navbar');

    if (toggle && menu) {
      toggle.addEventListener('click', () => {
        menu.classList.toggle('open');
        toggle.innerHTML = menu.classList.contains('open')
          ? '<i class="fas fa-times"></i>'
          : '<i class="fas fa-bars"></i>';
      });
      document.addEventListener('click', (e) => {
        if (!toggle.contains(e.target) && !menu.contains(e.target)) {
          menu.classList.remove('open');
          toggle.innerHTML = '<i class="fas fa-bars"></i>';
        }
      });
    }

    if (navbar) {
      window.addEventListener('scroll', () => {
        navbar.classList.toggle('scrolled', window.scrollY > 50);
      });
    }

    // Active nav links
    document.querySelectorAll('.nav-menu a[href^="#"]').forEach(a => {
      a.addEventListener('click', (e) => {
        const target = document.querySelector(a.getAttribute('href'));
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: 'smooth' });
          if (menu) menu.classList.remove('open');
        }
      });
    });
  },

  // ===== BACK TO TOP =====
  initBackToTop() {
    const btn = document.getElementById('backToTop');
    if (!btn) return;
    window.addEventListener('scroll', () => {
      btn.classList.toggle('visible', window.scrollY > 400);
    });
    btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  },

  // ===== TOASTS =====
  initToasts() {
    if (!document.getElementById('toastContainer')) {
      const c = document.createElement('div');
      c.id = 'toastContainer';
      c.className = 'toast-container';
      document.body.appendChild(c);
    }
  },

  showToast(message, type = 'info', duration = 4000) {
    const icons = { success: 'fa-check-circle', error: 'fa-times-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<i class="fas ${icons[type] || icons.info}"></i><span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); }, duration);
  },

  // ===== MODALS =====
  initModals() {
    document.querySelectorAll('[data-modal]').forEach(btn => {
      btn.addEventListener('click', () => this.openModal(btn.dataset.modal));
    });
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) this.closeModal(overlay.id);
      });
    });
    document.querySelectorAll('.modal-close').forEach(btn => {
      btn.addEventListener('click', () => {
        const modal = btn.closest('.modal-overlay');
        if (modal) this.closeModal(modal.id);
      });
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(m => this.closeModal(m.id));
      }
    });
  },

  openModal(id) {
    const modal = document.getElementById(id);
    if (modal) { modal.classList.add('active'); document.body.style.overflow = 'hidden'; }
  },

  closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) { modal.classList.remove('active'); document.body.style.overflow = ''; }
  },

  // ===== AJAX FORMS =====
  initForms() {
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
      contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.submitContact(contactForm);
      });
    }
  },

  async submitContact(form) {
    const btn = form.querySelector('[type="submit"]');
    const alert = document.getElementById('contactAlert');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';

    try {
      const res = await fetch(this.baseUrl + '/api/contact.php', {
        method: 'POST',
        body: new FormData(form)
      });
      const data = await res.json();
      alert.className = `alert alert-${data.success ? 'success' : 'danger'}`;
      alert.textContent = data.message;
      alert.style.display = 'block';
      if (data.success) form.reset();
    } catch (err) {
      alert.className = 'alert alert-danger';
      alert.textContent = 'Failed to send message. Please try again.';
      alert.style.display = 'block';
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
    }
  },

  // ===== AJAX HELPER =====
  async ajax(url, method = 'GET', data = null) {
    const options = { method, headers: {} };
    if (data) {
      if (data instanceof FormData) { options.body = data; }
      else { options.headers['Content-Type'] = 'application/json'; options.body = JSON.stringify(data); }
    }
    const res = await fetch(url, options);
    return res.json();
  },

  // ===== CONFIRM =====
  confirm(message, onConfirm) {
    if (window.confirm(message)) onConfirm();
  },

  // ===== FORMAT =====
  formatCurrency(amount) {
    return 'TZS ' + Number(amount).toLocaleString('en-TZ', { minimumFractionDigits: 0 });
  },

  formatDate(dateStr) {
    return new Date(dateStr).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' });
  },

  // ===== DROPDOWNS =====
  toggleDropdown(id) {
    const dd = document.getElementById(id);
    if (dd) dd.classList.toggle('open');
  }
};

// ===== GLOBAL INIT =====
document.addEventListener('DOMContentLoaded', () => AtizProm.init());

// Close dropdowns on outside click
document.addEventListener('click', (e) => {
  if (!e.target.closest('.dropdown')) {
    document.querySelectorAll('.dropdown-menu.open').forEach(d => d.classList.remove('open'));
  }
});
