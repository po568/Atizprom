<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';

header('Content-Type: application/json');

if (!isPost()) jsonResponse(['success'=>false,'message'=>'Invalid request method.'], 405);

$auth = new Auth();
if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
    jsonResponse(['success'=>false,'message'=>'Invalid security token. Please refresh the page.']);
}

$name    = sanitize($_POST['name'] ?? '');
$email   = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
$subject = sanitize($_POST['subject'] ?? '');
$message = sanitize($_POST['message'] ?? '');

if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || !$subject || !$message) {
    jsonResponse(['success'=>false,'message'=>'Please fill in all required fields correctly.']);
}

$db = Database::getInstance();

// Create a support ticket from the contact form (unauthenticated inquiry)
// First check/create a guest-tracking mechanism via tickets table is tied to customer_id (NOT NULL).
// We store it as a notification to admins instead, plus log it.
$db->execute(
    "INSERT INTO audit_logs (action, table_name, new_values, ip_address, user_agent) VALUES (?,?,?,?,?)",
    ['CONTACT_FORM_SUBMISSION', 'contact', json_encode(['name'=>$name,'email'=>$email,'subject'=>$subject,'message'=>$message]), $_SERVER['REMOTE_ADDR'] ?? '', $_SERVER['HTTP_USER_AGENT'] ?? '']
);

// Notify admins
$admins = $db->fetchAll("SELECT id FROM users WHERE role_id IN (1,2)");
foreach ($admins as $a) {
    $db->execute("INSERT INTO notifications (user_id, title, message, type) VALUES (?,?,?,?)",
        [$a['id'], "New Contact Form Message", "From {$name} ({$email}): {$subject}", 'inquiry']);
}

jsonResponse(['success'=>true,'message'=>'Thank you! Your message has been sent. We will get back to you within 24 hours.']);
