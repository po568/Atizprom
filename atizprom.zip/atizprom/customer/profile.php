<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();
$success = ''; $error = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } elseif (isset($_POST['update_profile'])) {
        // Profile picture upload
        $picPath = $user['profile_picture'];
        if (!empty($_FILES['profile_picture']['tmp_name'])) {
            $r = uploadFile($_FILES['profile_picture'], 'profiles');
            if ($r['success']) $picPath = $r['path'];
            else $error = $r['message'];
        }
        if (!$error) {
            $db->execute("UPDATE users SET first_name=?,last_name=?,phone=?,address=?,city=?,profile_picture=? WHERE id=?",
                [trim($_POST['first_name']),trim($_POST['last_name']),trim($_POST['phone']??''),trim($_POST['address']??''),trim($_POST['city']??''),$picPath,$user['id']]);
            $_SESSION['user_name'] = trim($_POST['first_name']).' '.trim($_POST['last_name']);
            $auth->logAudit($user['id'],'PROFILE_UPDATE','users',$user['id']);
            $success = 'Profile updated successfully!';
            $user = $auth->getCurrentUser(); // Refresh
        }
    } elseif (isset($_POST['change_password'])) {
        if (!password_verify($_POST['current_password'], $user['password'])) {
            $error = 'Current password is incorrect.';
        } elseif ($_POST['new_password'] !== $_POST['confirm_password']) {
            $error = 'New passwords do not match.';
        } elseif (strlen($_POST['new_password']) < 8) {
            $error = 'Password must be at least 8 characters.';
        } else {
            $hashed = password_hash($_POST['new_password'], PASSWORD_BCRYPT, ['cost'=>12]);
            $db->execute("UPDATE users SET password=? WHERE id=?", [$hashed, $user['id']]);
            $auth->logAudit($user['id'],'PASSWORD_CHANGE','users',$user['id']);
            $success = 'Password changed successfully!';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Profile – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include __DIR__ . '/includes/header.php'; ?>
<div class="customer-layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content" style="max-width:860px">
      <div class="customer-page-header">
        <div class="cph-left">
          <div class="cph-icon"><i class="fas fa-user-circle"></i></div>
          <div><h2>My Profile</h2><div class="cph-subtitle">Manage your account information and settings</div></div>
        </div>
      </div>

      <?php if ($success): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
      <?php if ($error): ?><div class="alert alert-danger mb-3"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div><?php endif; ?>

      <!-- Profile Header Card -->
      <div class="card mb-4">
        <div class="card-body" style="display:flex;align-items:center;gap:24px;flex-wrap:wrap">
          <div class="profile-pic-wrap">
            <?php if ($user['profile_picture']): ?>
              <img src="<?= UPLOAD_URL . $user['profile_picture'] ?>" class="profile-pic" alt="Profile">
            <?php else: ?>
              <div class="profile-pic" style="background:linear-gradient(135deg,var(--blue),var(--yellow));display:flex;align-items:center;justify-content:center;font-size:2.5rem;font-weight:900;color:#fff">
                <?= strtoupper(substr($user['first_name'],0,1)) ?>
              </div>
            <?php endif; ?>
            <label class="profile-pic-upload" for="picInput" title="Change photo">
              <i class="fas fa-camera"></i>
            </label>
          </div>
          <div>
            <h3 style="margin-bottom:4px"><?= htmlspecialchars($user['first_name'].' '.$user['last_name']) ?></h3>
            <p class="text-muted" style="margin:0"><?= htmlspecialchars($user['email']) ?></p>
            <?php if ($user['phone']): ?><p class="text-muted" style="margin:4px 0 0"><i class="fas fa-phone"></i> <?= htmlspecialchars($user['phone']) ?></p><?php endif; ?>
            <div style="margin-top:10px">
              <span class="badge badge-primary">Customer</span>
              <?php if ($user['email_verified']): ?><span class="badge badge-success ml-2">Verified</span><?php endif; ?>
            </div>
          </div>
          <div style="margin-left:auto">
            <p class="text-muted" style="font-size:0.82rem;margin:0">Member since</p>
            <strong><?= formatDate($user['created_at']) ?></strong>
          </div>
        </div>
      </div>

      <!-- Tabs -->
      <div style="display:flex;gap:0;border-bottom:2px solid var(--border);margin-bottom:24px" id="profileTabs">
        <button class="profile-tab active" data-tab="info" onclick="switchTab('info',this)" style="padding:10px 20px;border:none;background:none;cursor:pointer;font-weight:600;border-bottom:3px solid var(--blue);color:var(--blue);margin-bottom:-2px">
          <i class="fas fa-user"></i> Personal Info
        </button>
        <button class="profile-tab" data-tab="security" onclick="switchTab('security',this)" style="padding:10px 20px;border:none;background:none;cursor:pointer;font-weight:600;color:var(--text-muted)">
          <i class="fas fa-lock"></i> Security
        </button>
        <button class="profile-tab" data-tab="activity" onclick="switchTab('activity',this)" style="padding:10px 20px;border:none;background:none;cursor:pointer;font-weight:600;color:var(--text-muted)">
          <i class="fas fa-history"></i> Activity
        </button>
      </div>

      <!-- Info Tab -->
      <div id="tab-info">
        <form method="POST" enctype="multipart/form-data">
          <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
          <input type="hidden" name="update_profile" value="1">
          <input type="file" id="picInput" name="profile_picture" accept="image/*" style="display:none" onchange="previewPic(this)">
          <div class="card">
            <div class="card-header"><h4>Personal Information</h4></div>
            <div class="card-body">
              <div class="form-row">
                <div class="form-group">
                  <label>First Name *</label>
                  <input type="text" name="first_name" class="form-control" required value="<?= htmlspecialchars($user['first_name']) ?>">
                </div>
                <div class="form-group">
                  <label>Last Name *</label>
                  <input type="text" name="last_name" class="form-control" required value="<?= htmlspecialchars($user['last_name']) ?>">
                </div>
              </div>
              <div class="form-group">
                <label>Email Address</label>
                <input type="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" disabled style="background:var(--gray-light)">
                <div class="form-text">Email cannot be changed. Contact support if needed.</div>
              </div>
              <div class="form-group">
                <label>Phone Number</label>
                <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" placeholder="+255 700 000 000">
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label>Address</label>
                  <input type="text" name="address" class="form-control" value="<?= htmlspecialchars($user['address'] ?? '') ?>" placeholder="Street address">
                </div>
                <div class="form-group">
                  <label>City</label>
                  <input type="text" name="city" class="form-control" value="<?= htmlspecialchars($user['city'] ?? '') ?>" placeholder="City">
                </div>
              </div>
            </div>
            <div class="card-footer d-flex justify-content-end">
              <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
            </div>
          </div>
        </form>
      </div>

      <!-- Security Tab -->
      <div id="tab-security" style="display:none">
        <form method="POST">
          <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
          <input type="hidden" name="change_password" value="1">
          <div class="card">
            <div class="card-header"><h4>Change Password</h4></div>
            <div class="card-body">
              <div class="form-group">
                <label>Current Password *</label>
                <input type="password" name="current_password" class="form-control" required placeholder="Your current password">
              </div>
              <div class="form-group">
                <label>New Password *</label>
                <input type="password" name="new_password" class="form-control" required placeholder="Min 8 characters" id="newPwd">
              </div>
              <div class="form-group">
                <label>Confirm New Password *</label>
                <input type="password" name="confirm_password" class="form-control" required placeholder="Repeat new password" id="confPwd">
              </div>
              <div id="pwdMatch" style="font-size:0.82rem;margin-top:-10px"></div>
            </div>
            <div class="card-footer d-flex justify-content-end">
              <button type="submit" class="btn btn-primary"><i class="fas fa-lock"></i> Update Password</button>
            </div>
          </div>
        </form>
        <div class="card mt-3">
          <div class="card-header"><h4>Login Sessions</h4></div>
          <div class="card-body">
            <?php $logs = $db->fetchAll("SELECT * FROM login_logs WHERE email=? AND status='success' ORDER BY created_at DESC LIMIT 5", [$user['email']]); ?>
            <?php foreach ($logs as $l): ?>
            <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border)">
              <i class="fas fa-sign-in-alt" style="color:var(--blue);width:20px"></i>
              <div>
                <div style="font-size:0.88rem;font-weight:600">Successful Login</div>
                <small class="text-muted"><?= $l['ip_address'] ?> · <?= timeAgo($l['created_at']) ?></small>
              </div>
              <span class="badge badge-success" style="margin-left:auto">Success</span>
            </div>
            <?php endforeach; ?>
            <?php if (empty($logs)): ?><p class="text-muted">No login history found.</p><?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Activity Tab -->
      <div id="tab-activity" style="display:none">
        <div class="card">
          <div class="card-header"><h4>Recent Activity</h4></div>
          <div class="card-body" style="padding:0">
            <?php $acts = $db->fetchAll("SELECT * FROM audit_logs WHERE user_id=? ORDER BY created_at DESC LIMIT 20", [$user['id']]); ?>
            <?php if (empty($acts)): ?>
            <p class="text-center text-muted" style="padding:30px">No activity recorded yet.</p>
            <?php else: ?>
            <?php foreach ($acts as $a): ?>
            <div style="padding:12px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px">
              <div style="width:36px;height:36px;border-radius:10px;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center;flex-shrink:0"><i class="fas fa-history" style="font-size:0.85rem"></i></div>
              <div>
                <div style="font-size:0.88rem;font-weight:600"><?= htmlspecialchars(str_replace('_',' ',ucwords(strtolower($a['action']),'_'))) ?></div>
                <small class="text-muted"><?= timeAgo($a['created_at']) ?> · IP: <?= $a['ip_address'] ?></small>
              </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>

    </div>
  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script>
function switchTab(tab, btn) {
  document.querySelectorAll('[id^="tab-"]').forEach(t => t.style.display='none');
  document.getElementById('tab-'+tab).style.display='block';
  document.querySelectorAll('.profile-tab').forEach(b => {
    b.style.color='var(--text-muted)';
    b.style.borderBottom='3px solid transparent';
  });
  btn.style.color='var(--blue)';
  btn.style.borderBottom='3px solid var(--blue)';
}
function previewPic(input) {
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = e => {
      document.querySelector('.profile-pic').src = e.target.result;
      document.querySelector('.profile-pic').style.display = 'block';
    };
    reader.readAsDataURL(input.files[0]);
  }
}
document.getElementById('confPwd')?.addEventListener('input', function() {
  const match = document.getElementById('newPwd').value === this.value;
  const div = document.getElementById('pwdMatch');
  div.textContent = this.value ? (match ? '✓ Passwords match' : '✗ Passwords do not match') : '';
  div.style.color = match ? '#155724' : '#721C24';
});
</script>
</body>
</html>
