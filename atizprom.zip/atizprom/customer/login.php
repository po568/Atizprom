<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();

if ($auth->isLoggedIn()) {
    $u = $auth->getCurrentUser();
    redirect($u['role_slug'] === 'customer' ? BASE_URL.'/customer/' : BASE_URL.'/admin/');
}

$error = '';
if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $result = $auth->login($_POST['email'] ?? '', $_POST['password'] ?? '');
        if ($result['success']) redirect($result['redirect']);
        else $error = $result['message'];
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
body { background: linear-gradient(135deg, var(--dark-2) 0%, var(--dark-3) 100%); display:flex; flex-direction:column; min-height:100vh; }
.auth-page { flex:1; display:flex; align-items:center; justify-content:center; padding:30px 20px; }
.auth-card { width:100%; max-width:460px; }
.auth-box { background:var(--white); border-radius:20px; overflow:hidden; box-shadow:0 20px 60px rgba(0,0,0,0.4); }
.auth-header { background:linear-gradient(135deg,var(--blue),var(--blue-dark)); padding:32px; text-align:center; }
.auth-header h2 { color:#fff; margin-bottom:6px; }
.auth-header p { color:rgba(255,255,255,0.7); margin:0; font-size:0.88rem; }
.auth-body { padding:32px; }
.auth-footer { text-align:center; margin-top:20px; font-size:0.88rem; color:rgba(255,255,255,0.7); }
.auth-footer a { color:var(--yellow); }
.social-links-footer { display:flex; justify-content:center; gap:16px; margin-top:16px; }
.social-links-footer a { color:rgba(255,255,255,0.5); font-size:1.1rem; }
.social-links-footer a:hover { color:var(--yellow); }
</style>
</head>
<body>
<div class="auth-page">
  <div class="auth-card">
    <div class="auth-box">
      <div class="auth-header">
        <a href="<?= BASE_URL ?>" style="display:inline-flex;align-items:center;gap:12px;text-decoration:none;margin-bottom:16px">
          <div class="logo-icon" style="background:rgba(255,255,255,0.2)"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div>
          <div class="logo-text" style="text-align:left">
            <strong style="color:#fff;font-size:1rem">ATIZ PROM</strong>
            <small style="color:rgba(255,255,255,0.6);font-size:0.65rem">Home of All Tech Solutions</small>
          </div>
        </a>
        <h2>Customer Portal</h2>
        <p>Sign in to access your account</p>
      </div>
      <div class="auth-body">
        <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if (isset($_GET['registered'])): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> Account created! You can now log in.</div>
        <?php endif; ?>

        <form method="POST">
          <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
          <div class="form-group">
            <label>Email Address *</label>
            <input type="email" name="email" class="form-control" required autocomplete="email"
              placeholder="your@email.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label>Password *</label>
            <div style="position:relative">
              <input type="password" name="password" class="form-control" id="pwd" required placeholder="••••••••" style="padding-right:44px">
              <button type="button" onclick="document.getElementById('pwd').type=document.getElementById('pwd').type==='password'?'text':'password'" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-muted);cursor:pointer">
                <i class="fas fa-eye"></i>
              </button>
            </div>
          </div>
          <div class="d-flex justify-content-between align-items-center mb-3" style="font-size:0.85rem">
            <label style="display:flex;align-items:center;gap:6px;cursor:pointer"><input type="checkbox" name="remember"> Remember me</label>
            <a href="<?= BASE_URL ?>/customer/forgot-password.php">Forgot password?</a>
          </div>
          <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fas fa-sign-in-alt"></i> Sign In</button>
        </form>

        <div style="text-align:center;margin-top:20px;padding-top:20px;border-top:1px solid var(--border)">
          <p style="font-size:0.88rem;color:var(--text-muted)">Don't have an account?</p>
          <a href="<?= BASE_URL ?>/customer/register.php" class="btn btn-outline-primary btn-block">Create Free Account</a>
        </div>

        <div style="text-align:center;margin-top:14px">
          <a href="<?= BASE_URL ?>" style="font-size:0.82rem;color:var(--text-muted)"><i class="fas fa-arrow-left"></i> Back to Website</a>
          &nbsp;·&nbsp;
          <a href="<?= BASE_URL ?>/admin/login.php" style="font-size:0.82rem;color:var(--text-muted)">Admin Login</a>
        </div>
      </div>
    </div>
    <div class="auth-footer">
      <p>&copy; <?= date('Y') ?> Atiz Prom · Kyerwa, Kagera, Tanzania</p>
      <div class="social-links-footer">
        <a href="https://facebook.com/AtizPromArts" target="_blank"><i class="fab fa-facebook-f"></i></a>
        <a href="https://instagram.com/atiz_prom" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://tiktok.com/@atizpromarts" target="_blank"><i class="fab fa-tiktok"></i></a>
        <a href="https://youtube.com/@AtizPromArts" target="_blank"><i class="fab fa-youtube"></i></a>
      </div>
    </div>
  </div>
</div>
</body>
</html>
