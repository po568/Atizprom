<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();

// Redirect non-customers to login
if (!$auth->isLoggedIn()) redirect(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();
$uid = $user['id'];

// Dashboard stats
$myBookings    = $db->fetchOne("SELECT COUNT(*) c FROM bookings WHERE customer_id=?", [$uid])['c'] ?? 0;
$myProjects    = $db->fetchOne("SELECT COUNT(*) c FROM projects WHERE customer_id=?", [$uid])['c'] ?? 0;
$myQuotations  = $db->fetchOne("SELECT COUNT(*) c FROM quotations WHERE customer_id=?", [$uid])['c'] ?? 0;
$myTickets     = $db->fetchOne("SELECT COUNT(*) c FROM tickets WHERE customer_id=? AND status NOT IN ('closed')", [$uid])['c'] ?? 0;
$myEnrollments = $db->fetchOne("SELECT COUNT(*) c FROM course_enrollments WHERE student_id=? AND status='active'", [$uid])['c'] ?? 0;

// Recent bookings
$recentBookings = $db->fetchAll("SELECT b.*, s.name as service_name FROM bookings b JOIN services s ON b.service_id=s.id WHERE b.customer_id=? ORDER BY b.created_at DESC LIMIT 5", [$uid]);

// Active projects
$activeProjects = $db->fetchAll("SELECT * FROM projects WHERE customer_id=? AND status NOT IN ('delivered','cancelled') ORDER BY updated_at DESC LIMIT 4", [$uid]);

// Notifications
$notifs = $db->fetchAll("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 5", [$uid]);
$unreadNotifs = $db->fetchOne("SELECT COUNT(*) c FROM notifications WHERE user_id=? AND is_read=0", [$uid])['c'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Dashboard – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include __DIR__ . '/includes/header.php'; ?>

<div class="customer-layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>

  <main class="customer-main">
    <div class="customer-content">

      <!-- Welcome -->
      <div class="welcome-banner">
        <div class="welcome-text">
          <h2>Welcome back, <?= htmlspecialchars($user['first_name']) ?>! 👋</h2>
          <p>Here's an overview of your activity with Atiz Prom.</p>
        </div>
        <div class="welcome-actions">
          <a href="<?= BASE_URL ?>/customer/booking.php" class="btn btn-yellow"><i class="fas fa-calendar-plus"></i> Book a Service</a>
          <a href="<?= BASE_URL ?>/customer/quotation.php" class="btn btn-outline-light"><i class="fas fa-file-invoice"></i> Request Quote</a>
        </div>
      </div>

      <!-- Stats -->
      <div class="stats-grid" style="grid-template-columns:repeat(5,1fr)">
        <div class="stat-card">
          <div class="stat-icon blue"><i class="fas fa-calendar-check"></i></div>
          <div class="stat-info"><strong><?= $myBookings ?></strong><span>My Bookings</span></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon yellow"><i class="fas fa-project-diagram"></i></div>
          <div class="stat-info"><strong><?= $myProjects ?></strong><span>My Projects</span></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon green"><i class="fas fa-graduation-cap"></i></div>
          <div class="stat-info"><strong><?= $myEnrollments ?></strong><span>Enrolled Courses</span></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon purple"><i class="fas fa-file-invoice"></i></div>
          <div class="stat-info"><strong><?= $myQuotations ?></strong><span>Quotations</span></div>
        </div>
        <div class="stat-card">
          <div class="stat-icon red"><i class="fas fa-headset"></i></div>
          <div class="stat-info"><strong><?= $myTickets ?></strong><span>Open Tickets</span></div>
        </div>
      </div>

      <!-- Recent Bookings + Active Projects -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-top:24px">

        <!-- Recent Bookings -->
        <div class="card">
          <div class="card-header">
            <h4><i class="fas fa-calendar text-primary"></i> Recent Bookings</h4>
            <a href="<?= BASE_URL ?>/customer/bookings/" class="btn btn-sm btn-outline-primary">View All</a>
          </div>
          <div class="card-body" style="padding:0">
            <?php if (empty($recentBookings)): ?>
            <div class="text-center text-muted" style="padding:40px">
              <i class="fas fa-calendar-plus" style="font-size:2rem;display:block;margin-bottom:12px;opacity:0.3"></i>
              No bookings yet. <a href="<?= BASE_URL ?>/customer/booking.php">Book a service</a>
            </div>
            <?php else: ?>
            <?php foreach ($recentBookings as $b): ?>
            <div style="padding:14px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between">
              <div>
                <div style="font-weight:600;font-size:0.9rem"><?= htmlspecialchars($b['service_name']) ?></div>
                <small class="text-muted"><?= $b['booking_number'] ?> · <?= timeAgo($b['created_at']) ?></small>
              </div>
              <?= getStatusBadge($b['status']) ?>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>

        <!-- Active Projects -->
        <div class="card">
          <div class="card-header">
            <h4><i class="fas fa-tasks text-primary"></i> Active Projects</h4>
            <a href="<?= BASE_URL ?>/customer/projects/" class="btn btn-sm btn-outline-primary">View All</a>
          </div>
          <div class="card-body" style="padding:0">
            <?php if (empty($activeProjects)): ?>
            <div class="text-center text-muted" style="padding:40px">
              <i class="fas fa-project-diagram" style="font-size:2rem;display:block;margin-bottom:12px;opacity:0.3"></i>
              No active projects
            </div>
            <?php else: ?>
            <?php foreach ($activeProjects as $p): ?>
            <div style="padding:14px 18px;border-bottom:1px solid var(--border)">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
                <div>
                  <div style="font-weight:600;font-size:0.9rem"><?= htmlspecialchars($p['title']) ?></div>
                  <small class="text-muted"><?= $p['project_number'] ?></small>
                </div>
                <?= getStatusBadge($p['status']) ?>
              </div>
              <div class="progress"><div class="progress-bar" style="width:<?= $p['progress'] ?>%"></div></div>
              <small class="text-muted"><?= $p['progress'] ?>% complete</small>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Notifications -->
      <?php if (!empty($notifs)): ?>
      <div class="card mt-4">
        <div class="card-header">
          <h4><i class="fas fa-bell text-primary"></i> Recent Notifications
            <?php if ($unreadNotifs): ?><span class="badge badge-yellow ml-2"><?= $unreadNotifs ?> new</span><?php endif; ?>
          </h4>
          <a href="<?= BASE_URL ?>/customer/notifications.php" class="btn btn-sm btn-outline-primary">View All</a>
        </div>
        <div class="card-body" style="padding:0">
          <?php foreach ($notifs as $n): ?>
          <div style="padding:14px 18px;border-bottom:1px solid var(--border);display:flex;gap:14px;align-items:flex-start;<?= !$n['is_read']?'background:var(--yellow-light)':'' ?>">
            <div style="width:36px;height:36px;border-radius:10px;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center;flex-shrink:0">
              <i class="fas fa-bell" style="font-size:0.9rem"></i>
            </div>
            <div>
              <div style="font-weight:600;font-size:0.9rem"><?= htmlspecialchars($n['title']) ?></div>
              <div style="font-size:0.85rem;color:var(--text-muted)"><?= htmlspecialchars($n['message']) ?></div>
              <small class="text-muted"><?= timeAgo($n['created_at']) ?></small>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

    </div>
  </main>
</div>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<?php
// Mark notifications as read
$db->execute("UPDATE notifications SET is_read=1 WHERE user_id=? AND is_read=0", [$uid], 'i');
?>
</body>
</html>
