<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$id = (int)($_GET['id'] ?? 0);
$customer = $db->fetchOne("SELECT * FROM users WHERE id=? AND role_id=8", [$id]);
if (!$customer) redirect(BASE_URL.'/admin/customers/');

$success = ''; $error = '';
if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $postId = (int)($_POST['customer_id'] ?? $id);
        $db->execute("UPDATE users SET first_name=?,last_name=?,phone=?,address=?,city=?,is_active=? WHERE id=?",
            [trim($_POST['first_name']), trim($_POST['last_name']), trim($_POST['phone']??''), trim($_POST['address']??''), trim($_POST['city']??''), isset($_POST['is_active'])?1:0, $postId]);
        $auth->logAudit($user['id'], 'CUSTOMER_UPDATED', 'users', $postId);
        $success = 'Customer updated successfully!';
        $customer = $db->fetchOne("SELECT * FROM users WHERE id=?", [$postId]);
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Customer – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Edit Customer</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/customers/">Customers</a> <span class="sep">/</span> Edit</div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:700px">
    <?php if ($success): ?><div class="alert alert-success mb-3"><?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <input type="hidden" name="customer_id" value="<?= $customer['id'] ?>">
      <div class="card">
        <div class="card-header"><h4>Customer Information</h4></div>
        <div class="card-body">
          <div class="form-row">
            <div class="form-group"><label>First Name *</label><input type="text" name="first_name" class="form-control" required value="<?= htmlspecialchars($customer['first_name']) ?>"></div>
            <div class="form-group"><label>Last Name *</label><input type="text" name="last_name" class="form-control" required value="<?= htmlspecialchars($customer['last_name']) ?>"></div>
          </div>
          <div class="form-group"><label>Email</label><input type="email" class="form-control" value="<?= htmlspecialchars($customer['email']) ?>" disabled style="background:var(--gray-light)"></div>
          <div class="form-group"><label>Phone</label><input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($customer['phone']??'') ?>"></div>
          <div class="form-row">
            <div class="form-group"><label>Address</label><input type="text" name="address" class="form-control" value="<?= htmlspecialchars($customer['address']??'') ?>"></div>
            <div class="form-group"><label>City</label><input type="text" name="city" class="form-control" value="<?= htmlspecialchars($customer['city']??'') ?>"></div>
          </div>
          <div class="form-group">
            <label><input type="checkbox" name="is_active" value="1" <?= $customer['is_active']?'checked':'' ?>> Account Active</label>
          </div>
        </div>
        <div class="card-footer d-flex justify-content-end gap-2">
          <a href="<?= BASE_URL ?>/admin/customers/view.php?id=<?= $id ?>" class="btn" style="border:1px solid var(--border)">Cancel</a>
          <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
        </div>
      </div>
    </form>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
