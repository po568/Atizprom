<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();

if ($auth->isLoggedIn()) redirect(BASE_URL . '/customer/');

$error = ''; $success = '';
if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } elseif ($_POST['password'] !== $_POST['password_confirm']) {
        $error = 'Passwords do not match.';
    } else {
        $result = $auth->register($_POST);
        if ($result['success']) redirect(BASE_URL . '/customer/login.php?registered=1');
        else $error = $result['message'];
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Account – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
body { background:linear-gradient(135deg,var(--dark-2) 0%,var(--dark-3) 100%); min-height:100vh; display:flex; align-items:center; justify-content:center; padding:30px 20px; }
.auth-box { background:var(--white); border-radius:20px; overflow:hidden; box-shadow:0 20px 60px rgba(0,0,0,0.4); max-width:560px; width:100%; }
.auth-header { background:linear-gradient(135deg,var(--blue),var(--blue-dark)); padding:28px; text-align:center; }
.auth-header h2 { color:#fff; margin-bottom:4px; }
.auth-header p { color:rgba(255,255,255,0.7); margin:0; font-size:0.88rem; }
.auth-body { padding:32px; }
</style>
</head>
<body>
<div class="auth-box">
  <div class="auth-header">
    <a href="<?= BASE_URL ?>" style="display:inline-flex;align-items:center;gap:12px;text-decoration:none;margin-bottom:14px">
      <div class="logo-icon" style="background:rgba(255,255,255,0.2)"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div>
      <div class="logo-text" style="text-align:left">
        <strong style="color:#fff">ATIZ PROM</strong>
        <small style="color:rgba(255,255,255,0.6);font-size:0.65rem">Home of All Tech Solutions</small>
      </div>
    </a>
    <h2>Create Your Account</h2>
    <p>Join Atiz Prom and access all our services</p>
  </div>
  <div class="auth-body">
    <?php if ($error): ?>
    <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST" id="registerForm">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <div class="form-row">
        <div class="form-group">
          <label>First Name *</label>
          <input type="text" name="first_name" class="form-control" required placeholder="John" value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>Last Name *</label>
          <input type="text" name="last_name" class="form-control" required placeholder="Doe" value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>">
        </div>
      </div>
      <div class="form-group">
        <label>Email Address *</label>
        <input type="email" name="email" class="form-control" required placeholder="your@email.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Phone Number</label>
        <input type="tel" name="phone" class="form-control" placeholder="+255 700 000 000" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Password *</label>
          <div style="position:relative">
            <input type="password" name="password" class="form-control" id="pwd1" required placeholder="Min 8 characters" style="padding-right:44px">
            <button type="button" onclick="toggleField('pwd1')" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-muted);cursor:pointer"><i class="fas fa-eye"></i></button>
          </div>
        </div>
        <div class="form-group">
          <label>Confirm Password *</label>
          <div style="position:relative">
            <input type="password" name="password_confirm" class="form-control" id="pwd2" required placeholder="Repeat password" style="padding-right:44px">
            <button type="button" onclick="toggleField('pwd2')" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--text-muted);cursor:pointer"><i class="fas fa-eye"></i></button>
          </div>
        </div>
      </div>
      <div id="pwdStrength" style="margin-top:-10px;margin-bottom:14px;font-size:0.8rem"></div>
      <div class="form-group">
        <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;font-weight:400">
          <input type="checkbox" name="agree_terms" required style="margin-top:3px">
          <span>I agree to the <a href="<?= BASE_URL ?>/terms.php">Terms of Service</a> and <a href="<?= BASE_URL ?>/privacy.php">Privacy Policy</a> of Atiz Prom.</span>
        </label>
      </div>
      <button type="submit" class="btn btn-primary btn-block btn-lg"><i class="fas fa-user-plus"></i> Create Account</button>
    </form>
    <div style="text-align:center;margin-top:20px;padding-top:20px;border-top:1px solid var(--border)">
      <p style="font-size:0.88rem;color:var(--text-muted)">Already have an account? <a href="<?= BASE_URL ?>/customer/login.php">Sign In</a></p>
      <a href="<?= BASE_URL ?>" style="font-size:0.82rem;color:var(--text-muted)"><i class="fas fa-arrow-left"></i> Back to Website</a>
    </div>
  </div>
</div>
<script>
function toggleField(id) { const f = document.getElementById(id); f.type = f.type==='password'?'text':'password'; }
document.getElementById('pwd1')?.addEventListener('input', function() {
  const v = this.value, div = document.getElementById('pwdStrength');
  let strength = 0;
  if (v.length >= 8) strength++;
  if (/[A-Z]/.test(v)) strength++;
  if (/[0-9]/.test(v)) strength++;
  if (/[^A-Za-z0-9]/.test(v)) strength++;
  const labels = ['','Weak','Fair','Good','Strong'];
  const colors = ['','#DC3545','#FFC107','#1565C0','#28A745'];
  div.textContent = v ? 'Password strength: ' + (labels[strength]||'Weak') : '';
  div.style.color = colors[strength] || '#DC3545';
});
</script>
</body>
</html>
