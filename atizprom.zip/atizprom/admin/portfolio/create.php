<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','production_manager','graphic_designer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$error = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $thumbnail = null;
        if (!empty($_FILES['thumbnail']['tmp_name'])) {
            $r = uploadFile($_FILES['thumbnail'], 'portfolio');
            if ($r['success']) $thumbnail = $r['path'];
            else $error = $r['message'];
        }
        if (!$error) {
            $id = $db->insert(
                "INSERT INTO portfolio (category, title, description, client_name, project_date, thumbnail, video_url, tags, is_featured, is_active, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,NOW())",
                [$_POST['category'], trim($_POST['title']), trim($_POST['description']??''), trim($_POST['client_name']??''), $_POST['project_date']?:null, $thumbnail, trim($_POST['video_url']??''), trim($_POST['tags']??''), isset($_POST['is_featured'])?1:0, isset($_POST['is_active'])?1:0]
            );
            $auth->logAudit($user['id'], 'PORTFOLIO_CREATED', 'portfolio', $id);
            redirect(BASE_URL.'/admin/portfolio/?created=1');
        }
    }
}
$catLabels = ['photography'=>'Photography','videography'=>'Videography','films'=>'Films','graphics_design'=>'Graphics Design','events_coverage'=>'Events Coverage'];
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Portfolio Item – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Add Portfolio Item</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/portfolio/">Portfolio</a> <span class="sep">/</span> Add New</div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:700px">
    <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <div class="card">
        <div class="card-header"><h4>Event / Project Details</h4></div>
        <div class="card-body">
          <div class="form-row">
            <div class="form-group">
              <label>Category *</label>
              <select name="category" class="form-control" required>
                <?php foreach ($catLabels as $k=>$v): ?>
                <option value="<?= $k ?>"><?= $v ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Event / Project Date</label>
              <input type="date" name="project_date" class="form-control">
            </div>
          </div>
          <div class="form-group">
            <label>Title *</label>
            <input type="text" name="title" class="form-control" required placeholder="e.g. Mwamba & Sonia Wedding">
          </div>
          <div class="form-group">
            <label>Description</label>
            <textarea name="description" class="form-control" rows="4" placeholder="Brief description of the event/project and what was delivered"></textarea>
          </div>
          <div class="form-group">
            <label>Client Name</label>
            <input type="text" name="client_name" class="form-control" placeholder="e.g. Mwamba Family (leave blank if confidential)">
          </div>
          <div class="form-group">
            <label>Cover Image</label>
            <input type="file" name="thumbnail" class="form-control" accept="image/*">
            <div class="form-text">Recommended: landscape image, under 10MB</div>
          </div>
          <div class="form-group">
            <label>Video URL (optional)</label>
            <input type="url" name="video_url" class="form-control" placeholder="https://youtube.com/watch?v=...">
          </div>
          <div class="form-group">
            <label>Tags</label>
            <input type="text" name="tags" class="form-control" placeholder="wedding, outdoor, Kyerwa (comma separated)">
          </div>
          <div class="form-row">
            <div class="form-group">
              <label><input type="checkbox" name="is_featured" value="1"> Feature on homepage</label>
            </div>
            <div class="form-group">
              <label><input type="checkbox" name="is_active" value="1" checked> Visible on public portfolio</label>
            </div>
          </div>
        </div>
        <div class="card-footer d-flex justify-content-end gap-2">
          <a href="<?= BASE_URL ?>/admin/portfolio/" class="btn" style="border:1px solid var(--border)">Cancel</a>
          <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Add to Portfolio</button>
        </div>
      </div>
    </form>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
