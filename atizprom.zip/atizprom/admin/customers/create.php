<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$error = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
        $existing = $db->fetchOne("SELECT id FROM users WHERE email=?", [$email]);
        if ($existing) {
            $error = 'A user with this email already exists.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Please provide a valid email address.';
        } else {
            $hashed = password_hash($_POST['password'] ?: 'password', PASSWORD_BCRYPT, ['cost'=>12]);
            $newId = $db->insert("INSERT INTO users (role_id, branch_id, first_name, last_name, email, phone, address, city, password, is_active, email_verified, created_at) VALUES (8,1,?,?,?,?,?,?,?,1,1,NOW())",
                [trim($_POST['first_name']), trim($_POST['last_name']), $email, trim($_POST['phone']??''), trim($_POST['address']??''), trim($_POST['city']??''), $hashed]);
            $auth->logAudit($user['id'], 'CUSTOMER_CREATED', 'users', $newId);
            redirect(BASE_URL.'/admin/customers/view.php?id='.$newId.'&created=1');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Customer – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Add Customer</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/customers/">Customers</a> <span class="sep">/</span> Add New</div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:700px">
    <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <div class="card">
        <div class="card-header"><h4>Customer Information</h4></div>
        <div class="card-body">
          <div class="form-row">
            <div class="form-group"><label>First Name *</label><input type="text" name="first_name" class="form-control" required></div>
            <div class="form-group"><label>Last Name *</label><input type="text" name="last_name" class="form-control" required></div>
          </div>
          <div class="form-group"><label>Email *</label><input type="email" name="email" class="form-control" required></div>
          <div class="form-group"><label>Phone</label><input type="tel" name="phone" class="form-control" placeholder="+255 700 000 000"></div>
          <div class="form-row">
            <div class="form-group"><label>Address</label><input type="text" name="address" class="form-control"></div>
            <div class="form-group"><label>City</label><input type="text" name="city" class="form-control"></div>
          </div>
          <div class="form-group">
            <label>Temporary Password</label>
            <input type="text" name="password" class="form-control" placeholder="Leave blank for default 'password'">
            <div class="form-text">Customer should change this on first login.</div>
          </div>
        </div>
        <div class="card-footer d-flex justify-content-end gap-2">
          <a href="<?= BASE_URL ?>/admin/customers/" class="btn" style="border:1px solid var(--border)">Cancel</a>
          <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create Customer</button>
        </div>
      </div>
    </form>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
