<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();
$id = (int)($_GET['id'] ?? 0);

if (isPost() && isset($_POST['customer_sign'])) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $postId = (int)($_POST['contract_id'] ?? 0);
        $c = $db->fetchOne("SELECT * FROM contracts WHERE id=? AND customer_id=?", [$postId, $user['id']]);
        if ($c && $c['status'] === 'sent') {
            $db->execute("UPDATE contracts SET customer_signature=?, customer_signed_at=NOW() WHERE id=?", [trim($_POST['signature']), $postId]);
            if ($c['admin_signature']) {
                $db->execute("UPDATE contracts SET status='signed' WHERE id=?", [$postId]);
            }
            $auth->logAudit($user['id'], 'CONTRACT_CUSTOMER_SIGNED', 'contracts', $postId);
            redirect(BASE_URL.'/customer/contracts.php?id='.$postId.'&signed=1');
        }
    }
}

if ($id) {
    $contract = $db->fetchOne("SELECT * FROM contracts WHERE id=? AND customer_id=?", [$id, $user['id']]);
    if (!$contract) redirect(BASE_URL.'/customer/contracts.php');
} else {
    $contracts = $db->fetchAll("SELECT * FROM contracts WHERE customer_id=? ORDER BY created_at DESC", [$user['id']]);
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contracts – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include __DIR__ . '/includes/header.php'; ?>
<div class="customer-layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content" style="max-width:800px">

    <?php if ($id && $contract): ?>
      <a href="<?= BASE_URL ?>/customer/contracts.php" class="customer-breadcrumb" style="display:inline-block"><i class="fas fa-arrow-left"></i> Back to Contracts</a>
      <?php if (isset($_GET['signed'])): ?><div class="alert alert-success mt-3">Thank you — your signature has been recorded!</div><?php endif; ?>

      <div class="d-flex justify-content-between align-items-center mt-3 mb-3">
        <div>
          <h2 style="margin-bottom:2px"><?= htmlspecialchars($contract['title']) ?></h2>
          <p class="text-muted" style="margin:0">Contract #<?= $contract['contract_number'] ?></p>
        </div>
        <?= getStatusBadge($contract['status']) ?>
      </div>

      <?php if ($contract['status'] === 'draft'): ?>
      <div class="card"><div class="card-body text-center" style="padding:50px">
        <i class="fas fa-hourglass-half" style="font-size:2.5rem;color:var(--border);display:block;margin-bottom:14px"></i>
        <h4>Contract Being Prepared</h4>
        <p class="text-muted">Atiz Prom is finalizing the details of this contract. You'll be notified once it's ready for your review and signature.</p>
      </div></div>
      <?php else: ?>
      <div class="card mb-3">
        <div class="card-body" style="white-space:pre-line;font-size:0.92rem;line-height:1.7"><?= htmlspecialchars($contract['content']) ?></div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
        <div class="card">
          <div class="card-header"><h5>Your Signature</h5></div>
          <div class="card-body">
            <?php if ($contract['customer_signature']): ?>
            <div style="font-family:cursive;font-size:1.3rem;border-bottom:2px solid var(--border);padding-bottom:6px"><?= htmlspecialchars($contract['customer_signature']) ?></div>
            <small class="text-muted">Signed <?= formatDate($contract['customer_signed_at']) ?></small>
            <?php elseif ($contract['status'] === 'sent'): ?>
            <form method="POST">
              <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
              <input type="hidden" name="customer_sign" value="1">
              <input type="hidden" name="contract_id" value="<?= $contract['id'] ?>">
              <p class="text-muted" style="font-size:0.85rem">Type your full legal name below to digitally sign this contract.</p>
              <input type="text" name="signature" class="form-control mb-2" placeholder="Type your full name to sign" required>
              <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-signature"></i> Sign Contract</button>
            </form>
            <?php else: ?>
            <p class="text-muted">Not yet available for signature</p>
            <?php endif; ?>
          </div>
        </div>
        <div class="card">
          <div class="card-header"><h5>Atiz Prom Signature</h5></div>
          <div class="card-body">
            <?php if ($contract['admin_signature']): ?>
            <div style="font-family:cursive;font-size:1.3rem;border-bottom:2px solid var(--border);padding-bottom:6px"><?= htmlspecialchars($contract['admin_signature']) ?></div>
            <small class="text-muted">Signed <?= formatDate($contract['admin_signed_at']) ?></small>
            <?php else: ?>
            <p class="text-muted">Awaiting Atiz Prom signature</p>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php endif; ?>

    <?php else: ?>
      <div class="customer-page-header">
        <div class="cph-left">
          <div class="cph-icon"><i class="fas fa-file-signature"></i></div>
          <div><h2>Contracts</h2><div class="cph-subtitle">Digital service agreements for your bookings and projects</div></div>
        </div>
      </div>

      <?php if (empty($contracts)): ?>
      <div class="card"><div class="card-body text-center" style="padding:60px">
        <i class="fas fa-file-signature" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i>
        <h4>No contracts yet</h4>
        <p class="text-muted">A contract is created automatically once a booking is confirmed or a project starts.</p>
      </div></div>
      <?php else: ?>
      <div style="display:grid;gap:14px">
        <?php foreach ($contracts as $c): ?>
        <a href="?id=<?= $c['id'] ?>" class="card" style="text-decoration:none;color:inherit">
          <div class="card-body d-flex align-items-center justify-content-between" style="flex-wrap:wrap">
            <div>
              <strong><?= htmlspecialchars($c['title']) ?></strong><br>
              <small class="text-muted"><?= $c['contract_number'] ?> · <?= $c['value']?formatCurrency($c['value']):'Value TBD' ?></small>
            </div>
            <?= getStatusBadge($c['status']) ?>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    <?php endif; ?>

    </div>
  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
</body>
</html>
