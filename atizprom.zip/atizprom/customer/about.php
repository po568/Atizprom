<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Us – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/home.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<nav class="navbar"><div class="container">
  <a href="<?= BASE_URL ?>" class="navbar-brand"><div class="logo-icon"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div><div class="logo-text"><strong>ATIZ PROM</strong><small>Home of All Tech Solutions</small></div></a>
  <ul class="nav-menu">
    <li><a href="<?= BASE_URL ?>">Home</a></li>
    <li><a href="<?= BASE_URL ?>/customer/services.php">Services</a></li>
    <li><a href="<?= BASE_URL ?>/customer/portfolio.php">Portfolio</a></li>
    <li><a href="<?= BASE_URL ?>/customer/login.php" class="btn-nav-login">Login</a></li>
  </ul>
</div></nav>
<div style="background:#fff"><main><div class="container" style="padding:50px 20px;max-width:900px">

  <div class="section-header"><div class="section-tag">Who We Are</div><h2>About <span class="text-primary">Atiz Prom</span></h2></div>

  <p style="font-size:1.05rem;color:var(--text-muted);line-height:1.9;margin-bottom:20px">
    Atiz Prom — <em>Home of All Tech Solutions</em> — is a technology and creative media company based in Kyerwa, Kagera, Tanzania. We bring together photography, videography, film production, graphics design, computer training, and technology services under one roof, serving individuals, businesses, and organizations across the region.
  </p>
  <p style="font-size:1.05rem;color:var(--text-muted);line-height:1.9;margin-bottom:20px">
    Our mission is to make professional-grade creative and technical services accessible and affordable, while equipping the next generation with practical computer and digital skills through our training programs.
  </p>

  <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:24px;margin:40px 0">
    <div class="card"><div class="card-body">
      <i class="fas fa-bullseye" style="color:var(--blue);font-size:1.6rem"></i>
      <h4 class="mt-2">Our Mission</h4>
      <p class="text-muted">To deliver reliable, high-quality technology and creative media solutions that empower individuals and businesses in Kagera and beyond.</p>
    </div></div>
    <div class="card"><div class="card-body">
      <i class="fas fa-eye" style="color:var(--yellow);font-size:1.6rem"></i>
      <h4 class="mt-2">Our Vision</h4>
      <p class="text-muted">To be the leading hub for technology, media production, and digital skills training in the region.</p>
    </div></div>
  </div>

  <h3 class="mb-3">What We Offer</h3>
  <ul style="line-height:2;color:var(--text-muted);padding-left:20px">
    <li>Technology services & technical support</li>
    <li>Photography, videography & film production</li>
    <li>Graphics design</li>
    <li>Events coverage</li>
    <li>Computer training & courses</li>
    <li>Stationery & office supplies catalog</li>
  </ul>

  <div class="card mt-4" style="background:var(--blue-light)">
    <div class="card-body text-center">
      <h4>Get in Touch</h4>
      <p><i class="fas fa-map-marker-alt"></i> Kyerwa, Kagera, Tanzania &nbsp; | &nbsp; <i class="fas fa-envelope"></i> atizpromltd@gmail.com</p>
      <p>Follow us: <strong>Atiz Prom Arts</strong> on Facebook, Instagram, TikTok & YouTube</p>
    </div>
  </div>

</div></main></div>
<?php include BASE_PATH . '/includes/footer_public.php'; ?>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
</body>
</html>
