<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','finance_officer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$roleId = $_SESSION['user_role'];
$canAdminApprove = in_array($roleId, [1,2]);
$canFinanceApprove = in_array($roleId, [1,2,3]);

if (isPost()) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $eid = (int)$_POST['enrollment_id'];
        $e = $db->fetchOne("SELECT ce.*, c.title as course_title FROM course_enrollments ce JOIN courses c ON ce.course_id=c.id WHERE ce.id=?", [$eid]);

        if (isset($_POST['admin_accept']) && $canAdminApprove) {
            $db->execute("UPDATE course_enrollments SET admin_approved=1, admin_approved_by=?, admin_approved_at=NOW(), status='admin_approved' WHERE id=?", [$user['id'], $eid]);
            $auth->logAudit($user['id'], 'ENROLLMENT_ADMIN_ACCEPTED', 'course_enrollments', $eid);
            // Notify finance officers
            $financeUsers = $db->fetchAll("SELECT id FROM users WHERE role_id=3");
            foreach ($financeUsers as $f) {
                $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                    [$f['id'], 'Enrollment Awaiting Finance Approval', "Enrollment for \"{$e['course_title']}\" has been accepted by admin and needs finance approval.", 'enrollment', BASE_URL.'/admin/enrollments/']);
            }
            $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                [$e['student_id'], 'Enrollment Accepted', "Your enrollment in \"{$e['course_title']}\" has been accepted by our team. Awaiting finance approval.", 'enrollment', BASE_URL.'/customer/my-courses.php']);
            redirect(BASE_URL.'/admin/enrollments/?accepted=1');
        } elseif (isset($_POST['finance_approve']) && $canFinanceApprove) {
            if ($e['admin_approved']) {
                $db->execute("UPDATE course_enrollments SET finance_approved=1, finance_approved_by=?, finance_approved_at=NOW(), status='active', payment_status=? WHERE id=?",
                    [$user['id'], $_POST['payment_status'] ?? 'partial', $eid]);
                $auth->logAudit($user['id'], 'ENROLLMENT_FINANCE_APPROVED', 'course_enrollments', $eid);
                $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                    [$e['student_id'], 'Enrollment Approved — Materials Unlocked', "Your enrollment in \"{$e['course_title']}\" is fully approved. You can now access course materials!", 'enrollment', BASE_URL.'/customer/my-courses.php']);
                redirect(BASE_URL.'/admin/enrollments/?approved=1');
            }
        } elseif (isset($_POST['reject_enrollment'])) {
            $db->execute("UPDATE course_enrollments SET status='dropped' WHERE id=?", [$eid]);
            $auth->logAudit($user['id'], 'ENROLLMENT_REJECTED', 'course_enrollments', $eid);
            $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                [$e['student_id'], 'Enrollment Not Approved', "Your enrollment request for \"{$e['course_title']}\" was not approved. Please contact us for details.", 'enrollment', BASE_URL.'/customer/courses.php']);
            redirect(BASE_URL.'/admin/enrollments/?rejected=1');
        }
    }
}

$filter = $_GET['filter'] ?? 'pending';
if ($filter === 'pending') {
    $where = "ce.status IN ('pending','admin_approved')";
} elseif ($filter === 'active') {
    $where = "ce.status = 'active'";
} else {
    $where = "1=1";
}
$enrollments = $db->fetchAll("SELECT ce.*, c.title as course_title, CONCAT(u.first_name,' ',u.last_name) as student_name, u.email FROM course_enrollments ce JOIN courses c ON ce.course_id=c.id JOIN users u ON ce.student_id=u.id WHERE $where ORDER BY ce.enrolled_at DESC");
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Enrollment Requests – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Enrollment Requests</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/courses/">Courses</a> <span class="sep">/</span> Enrollments</div></div>
    </div>
  </div>
  <div class="content-body">
    <?php if (isset($_GET['accepted'])): ?><div class="alert alert-success mb-3">Enrollment accepted — forwarded to finance for approval.</div><?php endif; ?>
    <?php if (isset($_GET['approved'])): ?><div class="alert alert-success mb-3">Enrollment fully approved — student can now access course materials!</div><?php endif; ?>
    <?php if (isset($_GET['rejected'])): ?><div class="alert alert-success mb-3">Enrollment request declined.</div><?php endif; ?>

    <div class="card">
      <div class="card-body">
        <div class="dt-filters mb-3">
          <a href="?filter=pending" class="btn btn-sm <?= $filter==='pending'?'btn-primary':'btn-outline-primary' ?>">Needs Action</a>
          <a href="?filter=active" class="btn btn-sm <?= $filter==='active'?'btn-primary':'btn-outline-primary' ?>">Active</a>
          <a href="?filter=all" class="btn btn-sm <?= $filter==='all'?'btn-primary':'btn-outline-primary' ?>">All</a>
        </div>

        <?php if (empty($enrollments)): ?>
        <p class="text-center text-muted" style="padding:40px">No enrollment requests here</p>
        <?php else: ?>
        <div style="display:grid;gap:14px">
          <?php foreach ($enrollments as $e): ?>
          <div class="card" style="border:1px solid var(--border)">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-start" style="flex-wrap:wrap;gap:10px">
                <div>
                  <strong><?= htmlspecialchars($e['student_name']) ?></strong> → <?= htmlspecialchars($e['course_title']) ?><br>
                  <small class="text-muted"><?= htmlspecialchars($e['email']) ?> · <?= $e['enrollment_number'] ?> · Requested <?= timeAgo($e['enrolled_at']) ?></small>
                </div>
                <?= getStatusBadge($e['status']) ?>
              </div>

              <div style="display:flex;gap:18px;margin-top:10px;font-size:0.85rem">
                <div class="d-flex align-items-center gap-2">
                  <i class="fas <?= $e['admin_approved']?'fa-check-circle':'fa-circle' ?>" style="color:<?= $e['admin_approved']?'#28A745':'var(--border)' ?>"></i> Admin accepted
                </div>
                <div class="d-flex align-items-center gap-2">
                  <i class="fas <?= $e['finance_approved']?'fa-check-circle':'fa-circle' ?>" style="color:<?= $e['finance_approved']?'#28A745':'var(--border)' ?>"></i> Finance approved
                </div>
              </div>

              <?php if ($e['status'] !== 'active' && $e['status'] !== 'completed' && $e['status'] !== 'dropped'): ?>
              <div class="d-flex gap-2 mt-3" style="flex-wrap:wrap">
                <?php if (!$e['admin_approved'] && $canAdminApprove): ?>
                <form method="POST" style="display:inline">
                  <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
                  <input type="hidden" name="enrollment_id" value="<?= $e['id'] ?>">
                  <button type="submit" name="admin_accept" value="1" class="btn btn-sm btn-primary"><i class="fas fa-check"></i> Admin: Accept</button>
                </form>
                <?php endif; ?>

                <?php if ($e['admin_approved'] && !$e['finance_approved'] && $canFinanceApprove): ?>
                <form method="POST" style="display:inline" class="d-flex gap-1">
                  <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
                  <input type="hidden" name="enrollment_id" value="<?= $e['id'] ?>">
                  <select name="payment_status" class="form-control" style="width:auto;font-size:0.82rem">
                    <option value="paid">Paid in Full</option>
                    <option value="partial" selected>Partial Payment</option>
                  </select>
                  <button type="submit" name="finance_approve" value="1" class="btn btn-sm btn-success"><i class="fas fa-check-double"></i> Finance: Approve</button>
                </form>
                <?php endif; ?>

                <form method="POST" style="display:inline" onsubmit="return confirm('Decline this enrollment request?')">
                  <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
                  <input type="hidden" name="enrollment_id" value="<?= $e['id'] ?>">
                  <button type="submit" name="reject_enrollment" value="1" class="btn btn-sm" style="border:1px solid #DC3545;color:#DC3545"><i class="fas fa-times"></i> Decline</button>
                </form>
              </div>
              <?php elseif ($e['status'] === 'active'): ?>
              <div class="d-flex gap-2 mt-3">
                <a href="<?= BASE_URL ?>/admin/invoices/create.php?enrollment_id=<?= $e['id'] ?>" class="btn btn-sm btn-primary"><i class="fas fa-file-invoice-dollar"></i> Create Invoice</a>
              </div>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
