// =====================================================
// ATIZ PROM - Admin JavaScript
// =====================================================

const Admin = {
  charts: {},

  init() {
    this.initSidebar();
    this.initDataTables();
    this.initDropdowns();
    this.initDeleteConfirm();
    this.initFileUploads();
  },

  // ===== SIDEBAR =====
  initSidebar() {
    const toggleBtn = document.getElementById('sidebarToggle');
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');

    if (toggleBtn) {
      toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        mainContent && mainContent.classList.toggle('expanded');
        localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
      });
    }

    // Restore state
    if (localStorage.getItem('sidebarCollapsed') === 'true') {
      sidebar && sidebar.classList.add('collapsed');
      mainContent && mainContent.classList.add('expanded');
    }

    // Mobile sidebar
    const mobileToggle = document.getElementById('mobileSidebarToggle');
    if (mobileToggle && sidebar) {
      mobileToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
      document.addEventListener('click', (e) => {
        if (!sidebar.contains(e.target) && !mobileToggle.contains(e.target)) {
          sidebar.classList.remove('open');
        }
      });
    }

    // Active link
    const currentPath = window.location.pathname;
    document.querySelectorAll('.sidebar-link').forEach(link => {
      if (currentPath.includes(link.getAttribute('href'))) {
        link.classList.add('active');
      }
    });
  },

  // ===== DATA TABLES =====
  initDataTables() {
    document.querySelectorAll('.dt-search input').forEach(input => {
      input.addEventListener('input', () => {
        const table = input.closest('.dt-wrapper').querySelector('table');
        if (!table) return;
        const q = input.value.toLowerCase();
        table.querySelectorAll('tbody tr').forEach(row => {
          row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
      });
    });

    document.querySelectorAll('.dt-per-page select').forEach(sel => {
      sel.addEventListener('change', () => window.location.reload());
    });
  },

  // ===== DROPDOWNS =====
  initDropdowns() {
    document.querySelectorAll('[data-dropdown-toggle]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const target = document.getElementById(btn.dataset.dropdownToggle);
        if (target) {
          document.querySelectorAll('.dropdown-menu.open').forEach(d => {
            if (d !== target) d.classList.remove('open');
          });
          target.classList.toggle('open');
        }
      });
    });
  },

  // ===== DELETE CONFIRM =====
  initDeleteConfirm() {
    document.querySelectorAll('[data-confirm]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        if (!confirm(btn.dataset.confirm || 'Are you sure?')) e.preventDefault();
      });
    });
  },

  // ===== FILE UPLOADS =====
  initFileUploads() {
    document.querySelectorAll('.file-upload-area').forEach(area => {
      const input = area.querySelector('input[type="file"]');
      area.addEventListener('click', () => input && input.click());
      area.addEventListener('dragover', (e) => { e.preventDefault(); area.classList.add('drag-over'); });
      area.addEventListener('dragleave', () => area.classList.remove('drag-over'));
      area.addEventListener('drop', (e) => {
        e.preventDefault(); area.classList.remove('drag-over');
        if (input && e.dataTransfer.files.length) {
          input.files = e.dataTransfer.files;
          input.dispatchEvent(new Event('change'));
        }
      });
      if (input) {
        input.addEventListener('change', () => {
          const names = Array.from(input.files).map(f => f.name).join(', ');
          const label = area.querySelector('.file-upload-label');
          if (label) label.textContent = names || 'Choose files...';
        });
      }
    });
  },

  // ===== CHARTS =====
  initRevenueChart(labels, data) {
    const ctx = document.getElementById('revenueChart');
    if (!ctx) return;
    if (this.charts.revenue) this.charts.revenue.destroy();
    this.charts.revenue = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Revenue (TZS)',
          data,
          borderColor: '#1565C0',
          backgroundColor: 'rgba(21,101,192,0.08)',
          borderWidth: 2,
          pointBackgroundColor: '#FFC107',
          pointBorderColor: '#1565C0',
          pointRadius: 5,
          fill: true,
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: (c) => 'TZS ' + Number(c.parsed.y).toLocaleString() } } },
        scales: { y: { ticks: { callback: (v) => 'TZS ' + Number(v).toLocaleString() } } }
      }
    });
  },

  initBookingsChart(labels, data) {
    const ctx = document.getElementById('bookingsChart');
    if (!ctx) return;
    this.charts.bookings = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Bookings',
          data,
          backgroundColor: ['rgba(21,101,192,0.8)', 'rgba(255,193,7,0.8)', 'rgba(40,167,69,0.8)', 'rgba(220,53,69,0.8)', 'rgba(111,66,193,0.8)', 'rgba(230,102,0,0.8)'],
          borderRadius: 8
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
      }
    });
  },

  initServicesChart(labels, data) {
    const ctx = document.getElementById('servicesChart');
    if (!ctx) return;
    this.charts.services = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data,
          backgroundColor: ['#1565C0','#FFC107','#28A745','#DC3545','#6F42C1','#E65100','#0097A7'],
          borderWidth: 2,
          borderColor: '#fff'
        }]
      },
      options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
    });
  },

  // ===== STATUS UPDATE =====
  async updateStatus(type, id, status, token) {
    try {
      const res = await fetch(`../api/${type}.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update_status', id, status, csrf_token: token })
      });
      const data = await res.json();
      if (data.success) {
        AtizProm.showToast('Status updated successfully!', 'success');
        setTimeout(() => window.location.reload(), 1200);
      } else {
        AtizProm.showToast(data.message || 'Update failed.', 'error');
      }
    } catch (e) {
      AtizProm.showToast('Network error.', 'error');
    }
  },

  // ===== PRINT =====
  printPage() { window.print(); },

  // ===== EXPORT =====
  exportTable(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;
    let csv = '';
    table.querySelectorAll('tr').forEach(row => {
      const cols = Array.from(row.querySelectorAll('th,td')).map(c => `"${c.textContent.trim().replace(/"/g,'""')}"`);
      csv += cols.join(',') + '\n';
    });
    const blob = new Blob([csv], { type: 'text/csv' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = (filename || 'export') + '.csv'; a.click();
  }
};

document.addEventListener('DOMContentLoaded', () => Admin.init());
