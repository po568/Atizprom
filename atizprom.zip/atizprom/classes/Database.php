<?php
// =====================================================
// ATIZ PROM - Database Connection
// =====================================================

class Database {
    private static $instance = null;
    private $connection;

    private function __construct() {
        try {
            $this->connection = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            if ($this->connection->connect_error) {
                throw new Exception($this->connection->connect_error, $this->connection->connect_errno);
            }
            $this->connection->set_charset("utf8mb4");
        } catch (Exception $e) {
            http_response_code(500);
            $msg = "Database connection failed: " . $e->getMessage() . "\n\n"
                 . "This usually means one of the following:\n"
                 . "1. MySQL is not running in the XAMPP Control Panel (click Start next to MySQL)\n"
                 . "2. The database '" . DB_NAME . "' does not exist yet (import database/atizprom.sql via phpMyAdmin, or run the installer at /installer/)\n"
                 . "3. The credentials in config/config.php (DB_HOST, DB_USER, DB_PASS, DB_NAME) do not match your MySQL setup\n";
            if (ini_get('display_errors')) {
                die('<pre>' . htmlspecialchars($msg) . '</pre>');
            }
            error_log($msg);
            die('A database connection error occurred. Please check the server error log for details, or contact the site administrator.');
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->connection;
    }

    public function query($sql, $params = [], $types = '') {
        $stmt = $this->connection->prepare($sql);
        if (!$stmt) return false;
        if (!empty($params)) {
            if (empty($types)) {
                $types = str_repeat('s', count($params));
            }
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        return $stmt;
    }

    public function fetchAll($sql, $params = [], $types = '') {
        $stmt = $this->query($sql, $params, $types);
        if (!$stmt) return [];
        $result = $stmt->get_result();
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    public function fetchOne($sql, $params = [], $types = '') {
        $stmt = $this->query($sql, $params, $types);
        if (!$stmt) return null;
        $result = $stmt->get_result();
        return $result ? $result->fetch_assoc() : null;
    }

    public function insert($sql, $params = [], $types = '') {
        $stmt = $this->query($sql, $params, $types);
        if (!$stmt) return false;
        return $this->connection->insert_id;
    }

    public function execute($sql, $params = [], $types = '') {
        $stmt = $this->query($sql, $params, $types);
        return $stmt ? $stmt->affected_rows : false;
    }

    public function escape($value) {
        return $this->connection->real_escape_string($value);
    }

    public function lastInsertId() {
        return $this->connection->insert_id;
    }
}
