<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$id = (int)($_GET['id'] ?? 0);
$service = $db->fetchOne("SELECT * FROM services WHERE id=?", [$id]);
if (!$service) redirect(BASE_URL.'/admin/services/');
$categories = $db->fetchAll("SELECT * FROM service_categories ORDER BY sort_order");
$error = ''; $success = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $postId = (int)($_POST['service_id'] ?? $id);
        $image = $service['image'];
        if (!empty($_FILES['image']['tmp_name'])) {
            $r = uploadFile($_FILES['image'], 'documents');
            if ($r['success']) $image = $r['path'];
        }
        $db->execute(
            "UPDATE services SET category_id=?, name=?, description=?, price_from=?, price_to=?, price_label=?, duration=?, image=?, features=?, is_active=?, is_featured=?, sort_order=? WHERE id=?",
            [(int)$_POST['category_id'], trim($_POST['name']), trim($_POST['description']??''), $_POST['price_from']?:null, $_POST['price_to']?:null, trim($_POST['price_label']??'Starting from'), trim($_POST['duration']??''), $image, trim($_POST['features']??''), isset($_POST['is_active'])?1:0, isset($_POST['is_featured'])?1:0, (int)($_POST['sort_order']??0), $postId]
        );
        $auth->logAudit($user['id'], 'SERVICE_UPDATED', 'services', $postId);
        $success = 'Service updated successfully!';
        $service = $db->fetchOne("SELECT * FROM services WHERE id=?", [$postId]);
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Service – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Edit Service</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/services/">Services</a> <span class="sep">/</span> Edit</div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:700px">
    <?php if ($success): ?><div class="alert alert-success mb-3"><?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <?php if ($service['image']): ?>
    <div class="mb-3"><img src="<?= UPLOAD_URL . $service['image'] ?>" style="max-width:200px;border-radius:10px" alt="Current image"></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <input type="hidden" name="service_id" value="<?= $service['id'] ?>">
      <div class="card">
        <div class="card-header"><h4>Service Details</h4></div>
        <div class="card-body">
          <div class="form-group"><label>Service Name *</label><input type="text" name="name" class="form-control" required value="<?= htmlspecialchars($service['name']) ?>"></div>
          <div class="form-group"><label>Description</label><textarea name="description" class="form-control" rows="3"><?= htmlspecialchars($service['description'] ?? '') ?></textarea></div>
          <div class="form-group">
            <label>Category *</label>
            <select name="category_id" class="form-control" required>
              <?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= $service['category_id']==$c['id']?'selected':'' ?>><?= htmlspecialchars($c['name']) ?></option><?php endforeach; ?>
            </select>
          </div>
          <div class="form-row">
            <div class="form-group"><label>Price From (TZS)</label><input type="number" name="price_from" class="form-control" min="0" step="1000" value="<?= $service['price_from'] ?>"></div>
            <div class="form-group"><label>Price To (TZS)</label><input type="number" name="price_to" class="form-control" min="0" step="1000" value="<?= $service['price_to'] ?>"></div>
          </div>
          <div class="form-row">
            <div class="form-group"><label>Price Label</label><input type="text" name="price_label" class="form-control" value="<?= htmlspecialchars($service['price_label'] ?? 'Starting from') ?>"></div>
            <div class="form-group"><label>Duration</label><input type="text" name="duration" class="form-control" value="<?= htmlspecialchars($service['duration'] ?? '') ?>"></div>
          </div>
          <div class="form-group"><label>Features / What's Included</label><textarea name="features" class="form-control" rows="3"><?= htmlspecialchars($service['features'] ?? '') ?></textarea></div>
          <div class="form-group"><label>Replace Service Image</label><input type="file" name="image" class="form-control" accept="image/*"></div>
          <div class="form-row">
            <div class="form-group"><label>Sort Order</label><input type="number" name="sort_order" class="form-control" value="<?= $service['sort_order'] ?>"></div>
            <div class="form-group" style="display:flex;flex-direction:column;gap:6px;justify-content:center">
              <label><input type="checkbox" name="is_active" value="1" <?= $service['is_active']?'checked':'' ?>> Active (visible to customers)</label>
              <label><input type="checkbox" name="is_featured" value="1" <?= $service['is_featured']?'checked':'' ?>> Feature on homepage</label>
            </div>
          </div>
        </div>
        <div class="card-footer d-flex justify-content-end gap-2">
          <a href="<?= BASE_URL ?>/admin/services/" class="btn" style="border:1px solid var(--border)">Cancel</a>
          <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
        </div>
      </div>
    </form>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
