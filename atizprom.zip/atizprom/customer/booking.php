<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();

$success = ''; $error = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $attachments = [];
        if (!empty($_FILES['attachments']['name'][0])) {
            foreach ($_FILES['attachments']['tmp_name'] as $k => $tmp) {
                if ($tmp) {
                    $f = ['name'=>$_FILES['attachments']['name'][$k],'type'=>$_FILES['attachments']['type'][$k],'tmp_name'=>$tmp,'size'=>$_FILES['attachments']['size'][$k]];
                    $r = uploadFile($f, 'projects');
                    if ($r['success']) $attachments[] = $r['path'];
                }
            }
        }
        $bookingNum = $auth->generateNumber('BK', 'bookings', 'booking_number');
        $id = $db->insert(
            "INSERT INTO bookings (booking_number,customer_id,service_id,branch_id,booking_date,event_date,event_time,venue,guests_count,special_requirements,file_attachments,status) VALUES (?,?,?,1,NOW(),?,?,?,?,?,?,'pending')",
            [$bookingNum,$user['id'],$_POST['service_id'],$_POST['event_date']?:null,$_POST['event_time']?:null,$_POST['venue']?:null,$_POST['guests_count']?:null,$_POST['special_requirements']?:null,$attachments?json_encode($attachments):null]
        );
        if ($id) {
            $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                [$user['id'],"Booking Received","Your booking #{$bookingNum} has been submitted and is under review.",'info',BASE_URL.'/customer/bookings/']);
            // Notify admin
            $admins = $db->fetchAll("SELECT id FROM users WHERE role_id IN (1,2)");
            foreach ($admins as $a) {
                $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                    [$a['id'],"New Booking","New booking #{$bookingNum} received from {$user['first_name']} {$user['last_name']}",'booking',BASE_URL.'/admin/bookings/view.php?id='.$id]);
            }
            $auth->logAudit($user['id'], 'BOOKING_CREATE', 'bookings', $id);
            $success = "Booking #{$bookingNum} submitted successfully! We'll contact you shortly to confirm.";
        } else {
            $error = 'Booking submission failed. Please try again.';
        }
    }
}

$categories = $db->fetchAll("SELECT * FROM service_categories WHERE is_active=1 ORDER BY sort_order");
$services   = $db->fetchAll("SELECT s.*, sc.name as cat_name, sc.icon FROM services s JOIN service_categories sc ON s.category_id=sc.id WHERE s.is_active=1 ORDER BY sc.sort_order, s.sort_order");
$selectedService = $_GET['service_id'] ?? null;
$selectedType    = $_GET['type'] ?? null;
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Book a Service – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include __DIR__ . '/includes/header.php'; ?>
<div class="customer-layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content">
      <div class="customer-page-header">
        <div class="cph-left">
          <div class="cph-icon"><i class="fas fa-calendar-plus"></i></div>
          <div><h2>Book a Service</h2><div class="cph-subtitle">Select a service and fill in your booking details</div></div>
        </div>
      </div>

      <?php if ($success): ?>
      <div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
      <?php endif; ?>
      <?php if ($error): ?>
      <div class="alert alert-danger mb-3"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="POST" enctype="multipart/form-data" id="bookingForm">
        <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
        <input type="hidden" name="service_id" id="selectedServiceId" value="<?= htmlspecialchars($selectedService ?? '') ?>">

        <!-- Step 1: Select Service -->
        <div class="card mb-3" id="step1">
          <div class="card-header">
            <h4><span style="background:var(--blue);color:#fff;width:28px;height:28px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;margin-right:10px;font-size:0.85rem">1</span> Select Service</h4>
          </div>
          <div class="card-body">
            <!-- Category Tabs -->
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px" id="catTabs">
              <button type="button" class="btn btn-sm btn-primary cat-tab" data-cat="all">All Services</button>
              <?php foreach ($categories as $c): ?>
              <button type="button" class="btn btn-sm cat-tab" style="border:1px solid var(--border)" data-cat="<?= $c['id'] ?>">
                <i class="fas <?= $c['icon'] ?>"></i> <?= htmlspecialchars($c['name']) ?>
              </button>
              <?php endforeach; ?>
            </div>
            <div class="service-select-grid" id="serviceGrid">
              <?php foreach ($services as $s): ?>
              <div class="service-select-card <?= ($selectedService==$s['id'])?'selected':'' ?>"
                   data-id="<?= $s['id'] ?>" data-cat="<?= $s['category_id'] ?>"
                   onclick="selectService(<?= $s['id'] ?>, '<?= addslashes($s['name']) ?>', '<?= $s['price_from'] ?>')">
                <i class="fas <?= htmlspecialchars($s['icon']) ?>"></i>
                <h4><?= htmlspecialchars($s['name']) ?></h4>
                <div class="price"><?= $s['price_from'] ? 'From '.formatCurrency($s['price_from']) : 'Quote based' ?></div>
              </div>
              <?php endforeach; ?>
            </div>
            <div id="selectedServiceDisplay" style="display:<?= $selectedService?'flex':'none' ?>;align-items:center;gap:12px;margin-top:16px;padding:14px;background:var(--blue-light);border-radius:10px;border:2px solid var(--blue)">
              <i class="fas fa-check-circle" style="color:var(--blue);font-size:1.3rem"></i>
              <div>
                <strong id="selectedServiceName" style="color:var(--blue)">Selected Service</strong>
                <small class="text-muted" id="selectedServicePrice" style="display:block"></small>
              </div>
            </div>
          </div>
        </div>

        <!-- Step 2: Event Details -->
        <div class="card mb-3" id="step2">
          <div class="card-header">
            <h4><span style="background:var(--blue);color:#fff;width:28px;height:28px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;margin-right:10px;font-size:0.85rem">2</span> Event Details</h4>
          </div>
          <div class="card-body">
            <div class="form-row">
              <div class="form-group">
                <label>Event / Service Date *</label>
                <input type="date" name="event_date" class="form-control" required min="<?= date('Y-m-d', strtotime('+1 day')) ?>">
              </div>
              <div class="form-group">
                <label>Preferred Time</label>
                <input type="time" name="event_time" class="form-control">
              </div>
            </div>
            <div class="form-group">
              <label>Venue / Location</label>
              <input type="text" name="venue" class="form-control" placeholder="Where will the event/service take place?">
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Estimated Number of Guests</label>
                <input type="number" name="guests_count" class="form-control" placeholder="0" min="0">
              </div>
              <div class="form-group">
                <label>Duration (hours)</label>
                <select name="duration_hours" class="form-control">
                  <option value="">Not sure</option>
                  <?php foreach ([1,2,3,4,6,8,12] as $h): ?>
                  <option value="<?= $h ?>"><?= $h ?> hour<?= $h>1?'s':'' ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label>Special Requirements / Notes</label>
              <textarea name="special_requirements" class="form-control" rows="4"
                placeholder="Tell us more about your event: themes, styles, specific shots required, equipment needed, etc."></textarea>
            </div>
          </div>
        </div>

        <!-- Step 3: Attachments -->
        <div class="card mb-3">
          <div class="card-header">
            <h4><span style="background:var(--blue);color:#fff;width:28px;height:28px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;margin-right:10px;font-size:0.85rem">3</span> Attachments (Optional)</h4>
          </div>
          <div class="card-body">
            <p class="text-muted" style="font-size:0.9rem">Upload any reference files, scripts, previous work samples, or requirements documents.</p>
            <div class="file-upload-area" style="border:2px dashed var(--border);border-radius:var(--radius);padding:30px;text-align:center;cursor:pointer;transition:var(--transition)" id="uploadArea">
              <input type="file" name="attachments[]" multiple style="display:none" id="fileInput" accept="image/*,.pdf,.zip,.doc,.docx,.mp4,.mov">
              <i class="fas fa-cloud-upload-alt" style="font-size:2.5rem;color:var(--border);display:block;margin-bottom:12px"></i>
              <p class="file-upload-label" style="margin:0;color:var(--text-muted)">Click to upload or drag & drop files here</p>
              <small class="text-muted">Images, PDFs, ZIP files, Documents (max 10MB each)</small>
            </div>
            <div id="fileList" style="margin-top:12px"></div>
          </div>
        </div>

        <!-- Submit -->
        <div class="card">
          <div class="card-body d-flex justify-content-between align-items-center">
            <p class="text-muted" style="margin:0;font-size:0.9rem"><i class="fas fa-info-circle"></i> Our team will contact you within 24 hours to confirm your booking and discuss pricing.</p>
            <div class="d-flex gap-2">
              <a href="<?= BASE_URL ?>/customer/" class="btn" style="border:1px solid var(--border)">Cancel</a>
              <button type="submit" class="btn btn-primary btn-lg" id="submitBtn">
                <i class="fas fa-paper-plane"></i> Submit Booking
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </main>
</div>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script>
function selectService(id, name, price) {
  document.getElementById('selectedServiceId').value = id;
  document.getElementById('selectedServiceName').textContent = name;
  document.getElementById('selectedServicePrice').textContent = price ? 'From TZS ' + Number(price).toLocaleString() : 'Price on quotation';
  document.getElementById('selectedServiceDisplay').style.display = 'flex';
  document.querySelectorAll('.service-select-card').forEach(c => c.classList.remove('selected'));
  document.querySelector(`.service-select-card[data-id="${id}"]`)?.classList.add('selected');
}

// Category filter
document.querySelectorAll('.cat-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.cat-tab').forEach(b => { b.classList.remove('btn-primary'); b.style.borderColor = 'var(--border)'; b.style.background = ''; b.style.color = ''; });
    btn.classList.add('btn-primary'); btn.style.borderColor = ''; btn.style.background = ''; btn.style.color = '';
    const cat = btn.dataset.cat;
    document.querySelectorAll('.service-select-card').forEach(card => {
      card.style.display = (cat === 'all' || card.dataset.cat === cat) ? '' : 'none';
    });
  });
});

// File upload
const area = document.getElementById('uploadArea');
const input = document.getElementById('fileInput');
area.addEventListener('click', () => input.click());
area.addEventListener('dragover', e => { e.preventDefault(); area.style.borderColor='var(--blue)'; });
area.addEventListener('dragleave', () => area.style.borderColor='var(--border)');
area.addEventListener('drop', e => { e.preventDefault(); area.style.borderColor='var(--border)'; input.files = e.dataTransfer.files; showFiles(); });
input.addEventListener('change', showFiles);

function showFiles() {
  const list = document.getElementById('fileList');
  list.innerHTML = Array.from(input.files).map(f =>
    `<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;background:var(--gray-light);border-radius:8px;margin-bottom:6px;font-size:0.85rem">
      <i class="fas fa-file" style="color:var(--blue)"></i>
      <span>${f.name}</span>
      <span class="text-muted" style="margin-left:auto">${(f.size/1024/1024).toFixed(2)} MB</span>
    </div>`
  ).join('');
}

// Auto-select if passed via URL
<?php if ($selectedService): ?>
const card = document.querySelector('.service-select-card[data-id="<?= $selectedService ?>"]');
if (card) { card.click(); }
<?php endif; ?>

// Form validation
document.getElementById('bookingForm').addEventListener('submit', function(e) {
  if (!document.getElementById('selectedServiceId').value) {
    e.preventDefault(); alert('Please select a service first.');
  }
});
</script>
</body>
</html>
