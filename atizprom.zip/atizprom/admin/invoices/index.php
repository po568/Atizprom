<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','finance_officer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$status = $_GET['status'] ?? '';
$where = ['1=1']; $params = []; $types = '';
if ($status) { $where[] = 'i.status=?'; $params[] = $status; $types .= 's'; }
$invoices = $db->fetchAll(
    "SELECT i.*, CONCAT(u.first_name,' ',u.last_name) as customer_name, u.email
     FROM invoices i JOIN users u ON i.customer_id=u.id
     WHERE ".implode(' AND ',$where)." ORDER BY i.created_at DESC",
    $params, $types
);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Invoices – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Invoices</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Invoices</div></div>
    </div>
    <div class="header-actions">
      <a href="<?= BASE_URL ?>/admin/invoices/create.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Create Invoice</a>
    </div>
  </div>
  <div class="content-body">
    <?php if (isset($_GET['created'])): ?><div class="alert alert-success mb-3">Invoice created and sent to customer!</div><?php endif; ?>
    <?php if (isset($_GET['paid'])): ?><div class="alert alert-success mb-3">Payment recorded successfully!</div><?php endif; ?>
    <div class="card">
      <div class="card-body">
        <div class="dt-filters mb-3">
          <a href="?" class="btn btn-sm <?= !$status?'btn-primary':'btn-outline-primary' ?>">All</a>
          <?php foreach (['draft'=>'Draft','sent'=>'Sent','partial'=>'Partial','paid'=>'Paid','overdue'=>'Overdue'] as $k=>$v): ?>
          <a href="?status=<?= $k ?>" class="btn btn-sm <?= $status===$k?'btn-primary':'btn-outline-primary' ?>"><?= $v ?></a>
          <?php endforeach; ?>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Invoice #</th><th>Customer</th><th>Total</th><th>Paid</th><th>Balance</th><th>Due Date</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($invoices as $inv): ?>
              <tr>
                <td><strong style="color:var(--blue)"><?= $inv['invoice_number'] ?></strong></td>
                <td><?= htmlspecialchars($inv['customer_name']) ?></td>
                <td><?= formatCurrency($inv['total']) ?></td>
                <td style="color:#155724"><?= formatCurrency($inv['amount_paid']) ?></td>
                <td style="color:#721C24"><?= formatCurrency($inv['balance']) ?></td>
                <td><?= $inv['due_date'] ? formatDate($inv['due_date']) : '-' ?></td>
                <td><?= getStatusBadge($inv['status']) ?></td>
                <td>
                  <div class="d-flex gap-1">
                    <a href="<?= BASE_URL ?>/admin/invoices/view.php?id=<?= $inv['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-eye"></i></a>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($invoices)): ?><tr><td colspan="8" class="text-center text-muted" style="padding:40px">No invoices yet</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
