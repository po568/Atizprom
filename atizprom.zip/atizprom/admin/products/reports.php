<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','inventory_officer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();

// Pull every invoice that has at least one payment recorded against it (i.e. genuinely "sold", not just drafted)
$invoices = $db->fetchAll("SELECT i.id, i.items, i.created_at FROM invoices i WHERE i.amount_paid > 0");

// Aggregate by product_id across all invoice line items that were tagged from the catalogue
$sales = []; // product_id => ['qty' => x, 'revenue' => y, 'name' => ...]
$untaggedRevenue = 0;
$untaggedCount = 0;

foreach ($invoices as $inv) {
    $items = $inv['items'] ? json_decode($inv['items'], true) : [];
    if (!is_array($items)) continue;
    foreach ($items as $item) {
        $pid = $item['product_id'] ?? null;
        $qty = (float)($item['qty'] ?? 1);
        $lineTotal = $qty * (float)($item['unit_price'] ?? 0);
        if ($pid) {
            if (!isset($sales[$pid])) $sales[$pid] = ['qty' => 0, 'revenue' => 0];
            $sales[$pid]['qty'] += $qty;
            $sales[$pid]['revenue'] += $lineTotal;
        } else {
            $untaggedRevenue += $lineTotal;
            $untaggedCount++;
        }
    }
}

// Attach product details (name, category, current stock status) for tagged sales
$productIds = array_keys($sales);
$productDetails = [];
if (!empty($productIds)) {
    $placeholders = implode(',', array_fill(0, count($productIds), '?'));
    $rows = $db->fetchAll(
        "SELECT p.id, p.name, p.price, p.stock_status, pc.name as category_name FROM products p JOIN product_categories pc ON p.category_id=pc.id WHERE p.id IN ($placeholders)",
        $productIds
    );
    foreach ($rows as $r) { $productDetails[$r['id']] = $r; }
}

// Merge and sort by revenue descending
$report = [];
foreach ($sales as $pid => $s) {
    $report[] = [
        'product_id' => $pid,
        'name' => $productDetails[$pid]['name'] ?? '(Deleted Product #'.$pid.')',
        'category' => $productDetails[$pid]['category_name'] ?? '-',
        'stock_status' => $productDetails[$pid]['stock_status'] ?? null,
        'qty' => $s['qty'],
        'revenue' => $s['revenue'],
    ];
}
usort($report, function($a, $b) { return $b['revenue'] <=> $a['revenue']; });

$totalUnitsSold = array_sum(array_column($report, 'qty'));
$totalRevenue = array_sum(array_column($report, 'revenue')) + $untaggedRevenue;
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sales Report – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Sales Report</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/products/">Products</a> <span class="sep">/</span> Sales Report</div></div>
    </div>
  </div>
  <div class="content-body">
    <p class="text-muted mb-3">Sold products are pulled from invoices that have at least one payment recorded, based on line items added "From Catalogue" when the invoice was created.</p>

    <div class="stats-grid mb-3">
      <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-boxes"></i></div><div class="stat-info"><strong><?= number_format($totalUnitsSold) ?></strong><span>Units Sold (Catalogue)</span></div></div>
      <div class="stat-card"><div class="stat-icon green"><i class="fas fa-coins"></i></div><div class="stat-info"><strong><?= formatCurrency($totalRevenue) ?></strong><span>Total Revenue (All Sold Items)</span></div></div>
      <div class="stat-card"><div class="stat-icon yellow"><i class="fas fa-tags"></i></div><div class="stat-info"><strong><?= count($report) ?></strong><span>Distinct Products Sold</span></div></div>
    </div>

    <div class="card">
      <div class="card-header"><h4>Sold Products by Revenue</h4></div>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Product</th><th>Category</th><th>Current Stock</th><th>Units Sold</th><th>Revenue</th></tr></thead>
          <tbody>
            <?php foreach ($report as $r): ?>
            <tr>
              <td><strong><?= htmlspecialchars($r['name']) ?></strong></td>
              <td><?= htmlspecialchars($r['category']) ?></td>
              <td><?= $r['stock_status'] ? getStatusBadge($r['stock_status']) : '<span class="text-muted">-</span>' ?></td>
              <td><?= number_format($r['qty']) ?></td>
              <td style="color:#155724"><strong><?= formatCurrency($r['revenue']) ?></strong></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($report)): ?>
            <tr><td colspan="5" class="text-center text-muted" style="padding:40px">No catalogue product sales recorded yet. Tag invoice line items with "From Catalogue" when creating invoices to track sales here.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php if ($untaggedCount > 0): ?>
      <div class="card-footer">
        <small class="text-muted"><i class="fas fa-info-circle"></i> <?= $untaggedCount ?> additional paid line item(s) totaling <?= formatCurrency($untaggedRevenue) ?> were not tagged to a specific catalogue product (e.g. services, custom items) and are excluded from the product breakdown above.</small>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
