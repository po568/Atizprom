<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();

if (isPost()) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        if (isset($_POST['create_branch'])) {
            $id = $db->insert(
                "INSERT INTO branches (name, location, address, phone, email, manager_name, is_active, created_at) VALUES (?,?,?,?,?,?,?,NOW())",
                [trim($_POST['name']), trim($_POST['location']), trim($_POST['address']??''), trim($_POST['phone']??''), trim($_POST['email']??''), trim($_POST['manager_name']??''), isset($_POST['is_active'])?1:0]
            );
            $auth->logAudit($user['id'], 'BRANCH_CREATED', 'branches', $id);
            redirect(BASE_URL.'/admin/branches/?created=1');
        } elseif (isset($_POST['update_branch'])) {
            $bid = (int)$_POST['branch_id'];
            $db->execute(
                "UPDATE branches SET name=?, location=?, address=?, phone=?, email=?, manager_name=?, is_active=? WHERE id=?",
                [trim($_POST['name']), trim($_POST['location']), trim($_POST['address']??''), trim($_POST['phone']??''), trim($_POST['email']??''), trim($_POST['manager_name']??''), isset($_POST['is_active'])?1:0, $bid]
            );
            $auth->logAudit($user['id'], 'BRANCH_UPDATED', 'branches', $bid);
            redirect(BASE_URL.'/admin/branches/?updated=1');
        }
    }
}

$branches = $db->fetchAll("SELECT b.*, (SELECT COUNT(*) FROM users WHERE branch_id=b.id) as staff_count FROM branches b ORDER BY b.id");
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Branches – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Branches</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Branches</div></div>
    </div>
    <div class="header-actions">
      <button onclick="AtizProm.openModal('createBranchModal')" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add Branch</button>
    </div>
  </div>
  <div class="content-body">
    <?php if (isset($_GET['created'])): ?><div class="alert alert-success mb-3">Branch added successfully!</div><?php endif; ?>
    <?php if (isset($_GET['updated'])): ?><div class="alert alert-success mb-3">Branch updated successfully!</div><?php endif; ?>

    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px">
      <?php foreach ($branches as $b): ?>
      <div class="card">
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-start">
            <div>
              <h4 style="margin-bottom:2px"><i class="fas fa-building text-primary"></i> <?= htmlspecialchars($b['name']) ?></h4>
              <p class="text-muted" style="margin:0;font-size:0.85rem"><?= htmlspecialchars($b['location']) ?></p>
            </div>
            <?= $b['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-secondary">Inactive</span>' ?>
          </div>
          <div style="margin-top:12px;font-size:0.85rem;display:flex;flex-direction:column;gap:6px">
            <?php if ($b['address']): ?><div><i class="fas fa-map-marker-alt text-muted"></i> <?= htmlspecialchars($b['address']) ?></div><?php endif; ?>
            <?php if ($b['phone']): ?><div><i class="fas fa-phone text-muted"></i> <?= htmlspecialchars($b['phone']) ?></div><?php endif; ?>
            <?php if ($b['email']): ?><div><i class="fas fa-envelope text-muted"></i> <?= htmlspecialchars($b['email']) ?></div><?php endif; ?>
            <?php if ($b['manager_name']): ?><div><i class="fas fa-user-tie text-muted"></i> Manager: <?= htmlspecialchars($b['manager_name']) ?></div><?php endif; ?>
            <div><i class="fas fa-users text-muted"></i> <?= $b['staff_count'] ?> staff member(s)</div>
          </div>
          <button onclick='openEditBranch(<?= htmlspecialchars(json_encode($b)) ?>)' class="btn btn-sm btn-outline-primary btn-block mt-3"><i class="fas fa-edit"></i> Edit Branch</button>
        </div>
      </div>
      <?php endforeach; ?>
      <?php if (empty($branches)): ?>
      <div class="card"><div class="card-body text-center" style="padding:50px"><i class="fas fa-building" style="font-size:2.5rem;color:var(--border);display:block;margin-bottom:14px"></i><p class="text-muted">No branches yet</p></div></div>
      <?php endif; ?>
    </div>
  </div>
</div>
</div>

<!-- Create Branch Modal -->
<div class="modal-overlay" id="createBranchModal">
  <div class="modal">
    <div class="modal-header"><h4>Add New Branch</h4><button class="modal-close" onclick="AtizProm.closeModal('createBranchModal')"><i class="fas fa-times"></i></button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
        <input type="hidden" name="create_branch" value="1">
        <div class="form-group"><label>Branch Name *</label><input type="text" name="name" class="form-control" required placeholder="e.g. Bukoba Branch"></div>
        <div class="form-group"><label>Location *</label><input type="text" name="location" class="form-control" required placeholder="e.g. Bukoba, Kagera, Tanzania"></div>
        <div class="form-group"><label>Address</label><input type="text" name="address" class="form-control" placeholder="Street / office address"></div>
        <div class="form-row">
          <div class="form-group"><label>Phone</label><input type="text" name="phone" class="form-control" placeholder="+255..."></div>
          <div class="form-group"><label>Email</label><input type="email" name="email" class="form-control"></div>
        </div>
        <div class="form-group"><label>Branch Manager</label><input type="text" name="manager_name" class="form-control"></div>
        <div class="form-group"><label><input type="checkbox" name="is_active" value="1" checked> Active</label></div>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="AtizProm.closeModal('createBranchModal')" class="btn" style="border:1px solid var(--border)">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Add Branch</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Branch Modal -->
<div class="modal-overlay" id="editBranchModal">
  <div class="modal">
    <div class="modal-header"><h4>Edit Branch</h4><button class="modal-close" onclick="AtizProm.closeModal('editBranchModal')"><i class="fas fa-times"></i></button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
        <input type="hidden" name="update_branch" value="1">
        <input type="hidden" name="branch_id" id="eb_id">
        <div class="form-group"><label>Branch Name *</label><input type="text" name="name" id="eb_name" class="form-control" required></div>
        <div class="form-group"><label>Location *</label><input type="text" name="location" id="eb_location" class="form-control" required></div>
        <div class="form-group"><label>Address</label><input type="text" name="address" id="eb_address" class="form-control"></div>
        <div class="form-row">
          <div class="form-group"><label>Phone</label><input type="text" name="phone" id="eb_phone" class="form-control"></div>
          <div class="form-group"><label>Email</label><input type="email" name="email" id="eb_email" class="form-control"></div>
        </div>
        <div class="form-group"><label>Branch Manager</label><input type="text" name="manager_name" id="eb_manager" class="form-control"></div>
        <div class="form-group"><label><input type="checkbox" name="is_active" id="eb_active" value="1"> Active</label></div>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="AtizProm.closeModal('editBranchModal')" class="btn" style="border:1px solid var(--border)">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
<script>
function openEditBranch(b) {
  document.getElementById('eb_id').value = b.id;
  document.getElementById('eb_name').value = b.name;
  document.getElementById('eb_location').value = b.location;
  document.getElementById('eb_address').value = b.address || '';
  document.getElementById('eb_phone').value = b.phone || '';
  document.getElementById('eb_email').value = b.email || '';
  document.getElementById('eb_manager').value = b.manager_name || '';
  document.getElementById('eb_active').checked = b.is_active == 1;
  AtizProm.openModal('editBranchModal');
}
</script>
</body>
</html>
