<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','production_manager','graphic_designer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();

// Handle delete
if (isPost() && isset($_POST['delete_id'])) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $id = (int)$_POST['delete_id'];
        $db->execute("DELETE FROM portfolio WHERE id=?", [$id]);
        $auth->logAudit($user['id'], 'PORTFOLIO_DELETED', 'portfolio', $id);
        redirect(BASE_URL.'/admin/portfolio/?deleted=1');
    }
}

$cat = $_GET['cat'] ?? '';
$where = ['1=1']; $params = []; $types = '';
if ($cat) { $where[] = 'category=?'; $params[] = $cat; $types .= 's'; }
$items = $db->fetchAll("SELECT * FROM portfolio WHERE ".implode(' AND ',$where)." ORDER BY created_at DESC", $params, $types);
$catLabels = ['photography'=>'Photography','videography'=>'Videography','films'=>'Films','graphics_design'=>'Graphics Design','events_coverage'=>'Events Coverage'];
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Portfolio – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Portfolio</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Portfolio</div></div>
    </div>
    <div class="header-actions">
      <a href="<?= BASE_URL ?>/admin/portfolio/create.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add Portfolio Item</a>
    </div>
  </div>
  <div class="content-body">
    <?php if (isset($_GET['created'])): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> Portfolio item added successfully!</div><?php endif; ?>
    <?php if (isset($_GET['updated'])): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> Portfolio item updated successfully!</div><?php endif; ?>
    <?php if (isset($_GET['deleted'])): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> Portfolio item removed.</div><?php endif; ?>

    <div class="card">
      <div class="card-body">
        <div class="dt-toolbar mb-3">
          <div class="dt-filters">
            <a href="?" class="btn btn-sm <?= !$cat?'btn-primary':'btn-outline-primary' ?>">All</a>
            <?php foreach ($catLabels as $k=>$v): ?>
            <a href="?cat=<?= $k ?>" class="btn btn-sm <?= $cat===$k?'btn-primary':'btn-outline-primary' ?>"><?= $v ?></a>
            <?php endforeach; ?>
          </div>
        </div>

        <?php if (empty($items)): ?>
        <div class="text-center" style="padding:50px">
          <i class="fas fa-images" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i>
          <h4>No portfolio items yet</h4>
          <p class="text-muted">Showcase completed events and projects done by the company.</p>
          <a href="<?= BASE_URL ?>/admin/portfolio/create.php" class="btn btn-primary mt-2"><i class="fas fa-plus"></i> Add First Item</a>
        </div>
        <?php else: ?>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:18px">
          <?php foreach ($items as $p): ?>
          <div class="card" style="overflow:hidden">
            <div style="height:140px;background:var(--blue-light);display:flex;align-items:center;justify-content:center;overflow:hidden">
              <?php if ($p['thumbnail']): ?>
                <img src="<?= UPLOAD_URL . $p['thumbnail'] ?>" style="width:100%;height:100%;object-fit:cover" alt="<?= htmlspecialchars($p['title']) ?>">
              <?php else: ?>
                <i class="fas fa-image" style="font-size:2rem;color:var(--blue)"></i>
              <?php endif; ?>
            </div>
            <div class="card-body">
              <span class="badge badge-primary" style="margin-bottom:6px"><?= $catLabels[$p['category']] ?? $p['category'] ?></span>
              <h5 style="margin:4px 0"><?= htmlspecialchars($p['title']) ?></h5>
              <small class="text-muted"><?= htmlspecialchars($p['client_name'] ?: 'No client listed') ?> · <?= $p['project_date'] ? formatDate($p['project_date']) : '-' ?></small>
              <div class="d-flex gap-1 mt-2">
                <?php if ($p['is_featured']): ?><span class="badge badge-warning">Featured</span><?php endif; ?>
                <?= $p['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-secondary">Hidden</span>' ?>
              </div>
              <div class="d-flex gap-1 mt-3">
                <a href="<?= BASE_URL ?>/admin/portfolio/edit.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary" style="flex:1"><i class="fas fa-edit"></i> Edit</a>
                <form method="POST" onsubmit="return confirm('Delete this portfolio item permanently?')" style="flex:1">
                  <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
                  <input type="hidden" name="delete_id" value="<?= $p['id'] ?>">
                  <button type="submit" class="btn btn-sm btn-danger" style="width:100%"><i class="fas fa-trash"></i> Delete</button>
                </form>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
