<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','inventory_officer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$id = (int)($_GET['id'] ?? 0);
$product = $db->fetchOne("SELECT * FROM products WHERE id=?", [$id]);
if (!$product) redirect(BASE_URL.'/admin/products/');
$categories = $db->fetchAll("SELECT * FROM product_categories ORDER BY sort_order");
$existingImages = $product['images'] ? json_decode($product['images'], true) : [];
$error = ''; $success = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $postId = (int)($_POST['product_id'] ?? $id);
        $images = $existingImages;
        if (!empty($_FILES['images']['tmp_name'][0])) {
            foreach ($_FILES['images']['tmp_name'] as $i => $tmp) {
                if (!$tmp) continue;
                $f = ['tmp_name'=>$tmp, 'name'=>$_FILES['images']['name'][$i], 'size'=>$_FILES['images']['size'][$i], 'type'=>$_FILES['images']['type'][$i]];
                $r = uploadFile($f, 'products');
                if ($r['success']) $images[] = $r['path'];
            }
        }
        $db->execute(
            "UPDATE products SET category_id=?, name=?, description=?, price=?, unit=?, sku=?, stock_status=?, quantity_in_stock=?, images=?, specifications=?, is_active=?, is_featured=? WHERE id=?",
            [(int)$_POST['category_id'], trim($_POST['name']), trim($_POST['description']??''), (float)$_POST['price'], trim($_POST['unit']??'piece'), trim($_POST['sku']??''), $_POST['stock_status'], (int)($_POST['quantity_in_stock']??0), json_encode($images), trim($_POST['specifications']??''), isset($_POST['is_active'])?1:0, isset($_POST['is_featured'])?1:0, $postId]
        );
        $auth->logAudit($user['id'], 'PRODUCT_UPDATED', 'products', $postId);
        $success = 'Product updated successfully!';
        $product = $db->fetchOne("SELECT * FROM products WHERE id=?", [$postId]);
        $existingImages = $product['images'] ? json_decode($product['images'], true) : [];
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Product – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Edit Product</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/products/">Products</a> <span class="sep">/</span> Edit</div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:700px">
    <?php if ($success): ?><div class="alert alert-success mb-3"><?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <?php if (!empty($existingImages)): ?>
    <div class="d-flex gap-2 mb-3" style="flex-wrap:wrap">
      <?php foreach ($existingImages as $img): ?>
      <img src="<?= UPLOAD_URL . $img ?>" style="width:80px;height:80px;object-fit:cover;border-radius:8px" alt="Product image">
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
      <div class="card">
        <div class="card-header"><h4>Product Details</h4></div>
        <div class="card-body">
          <div class="form-group"><label>Product Name *</label><input type="text" name="name" class="form-control" required value="<?= htmlspecialchars($product['name']) ?>"></div>
          <div class="form-group"><label>Description</label><textarea name="description" class="form-control" rows="3"><?= htmlspecialchars($product['description'] ?? '') ?></textarea></div>
          <div class="form-row">
            <div class="form-group">
              <label>Category *</label>
              <select name="category_id" class="form-control" required>
                <?php foreach ($categories as $c): ?><option value="<?= $c['id'] ?>" <?= $product['category_id']==$c['id']?'selected':'' ?>><?= htmlspecialchars($c['name']) ?></option><?php endforeach; ?>
              </select>
            </div>
            <div class="form-group"><label>Price (TZS) *</label><input type="number" name="price" class="form-control" required min="0" step="100" value="<?= $product['price'] ?>"></div>
          </div>
          <div class="form-row">
            <div class="form-group"><label>Unit</label><input type="text" name="unit" class="form-control" value="<?= htmlspecialchars($product['unit'] ?? 'piece') ?>"></div>
            <div class="form-group"><label>SKU</label><input type="text" name="sku" class="form-control" value="<?= htmlspecialchars($product['sku'] ?? '') ?>"></div>
            <div class="form-group"><label>Quantity in Stock</label><input type="number" name="quantity_in_stock" class="form-control" value="<?= (int)($product['quantity_in_stock'] ?? 0) ?>" min="0"></div>
            <div class="form-group">
              <label>Stock Status</label>
              <select name="stock_status" class="form-control">
                <option value="in_stock" <?= $product['stock_status']==='in_stock'?'selected':'' ?>>In Stock</option>
                <option value="limited" <?= $product['stock_status']==='limited'?'selected':'' ?>>Limited Stock</option>
                <option value="out_of_stock" <?= $product['stock_status']==='out_of_stock'?'selected':'' ?>>Out of Stock</option>
              </select>
            </div>
          </div>
          <div class="form-group"><label>Specifications</label><textarea name="specifications" class="form-control" rows="2"><?= htmlspecialchars($product['specifications'] ?? '') ?></textarea></div>
          <div class="form-group"><label>Add More Images</label><input type="file" name="images[]" class="form-control" accept="image/*" multiple></div>
          <div class="form-row">
            <div class="form-group"><label><input type="checkbox" name="is_active" value="1" <?= $product['is_active']?'checked':'' ?>> Visible in catalog</label></div>
            <div class="form-group"><label><input type="checkbox" name="is_featured" value="1" <?= $product['is_featured']?'checked':'' ?>> Feature on homepage</label></div>
          </div>
        </div>
        <div class="card-footer d-flex justify-content-end gap-2">
          <a href="<?= BASE_URL ?>/admin/products/" class="btn" style="border:1px solid var(--border)">Cancel</a>
          <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
        </div>
      </div>
    </form>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
