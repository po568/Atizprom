<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();
$status = $_GET['status'] ?? '';
$where = ['b.customer_id=?']; $params=[$user['id']]; $types='i';
if ($status) { $where[]='b.status=?'; $params[]=$status; $types.='s'; }
$bookings = $db->fetchAll("SELECT b.*, s.name as service_name, sc.name as category, sc.icon FROM bookings b JOIN services s ON b.service_id=s.id JOIN service_categories sc ON s.category_id=sc.id WHERE ".implode(' AND ',$where)." ORDER BY b.created_at DESC", $params, $types);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Bookings – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include BASE_PATH . '/customer/includes/header.php'; ?>
<div class="customer-layout">
  <?php include BASE_PATH . '/customer/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content">
      <div class="customer-page-header">
        <div class="cph-left">
          <div class="cph-icon"><i class="fas fa-calendar-check"></i></div>
          <div><h2>My Bookings</h2><div class="cph-subtitle">Track all your service bookings</div></div>
        </div>
        <div class="cph-actions">
          <a href="<?= BASE_URL ?>/customer/booking.php" class="btn btn-primary"><i class="fas fa-plus"></i> New Booking</a>
        </div>
      </div>

      <div style="display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap">
        <a href="?" class="btn btn-sm <?= !$status?'btn-primary':'btn-outline-primary' ?>">All</a>
        <?php foreach (['pending'=>'Pending','confirmed'=>'Confirmed','in_progress'=>'In Progress','completed'=>'Completed','cancelled'=>'Cancelled'] as $k=>$v): ?>
        <a href="?status=<?= $k ?>" class="btn btn-sm <?= $status===$k?'btn-primary':'btn-outline-primary' ?>"><?= $v ?></a>
        <?php endforeach; ?>
      </div>

      <?php if (empty($bookings)): ?>
      <div class="card"><div class="card-body text-center" style="padding:60px">
        <i class="fas fa-calendar-times" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i>
        <h4>No bookings found</h4>
        <p class="text-muted">You haven't made any bookings yet.</p>
        <a href="<?= BASE_URL ?>/customer/booking.php" class="btn btn-primary"><i class="fas fa-plus"></i> Make a Booking</a>
      </div></div>
      <?php else: ?>
      <div style="display:grid;gap:16px">
        <?php foreach ($bookings as $b): ?>
        <div class="card">
          <div class="card-body d-flex align-items-center gap-3" style="flex-wrap:wrap">
            <div style="width:50px;height:50px;border-radius:12px;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0">
              <i class="fas <?= htmlspecialchars($b['icon']) ?>"></i>
            </div>
            <div style="flex:1;min-width:200px">
              <div style="font-weight:700"><?= htmlspecialchars($b['service_name']) ?></div>
              <small class="text-muted"><?= $b['booking_number'] ?> · <?= htmlspecialchars($b['category']) ?></small>
            </div>
            <div style="min-width:120px">
              <small class="text-muted">Event Date</small>
              <div style="font-weight:600"><?= $b['event_date']?formatDate($b['event_date']):'TBD' ?></div>
            </div>
            <div style="min-width:120px">
              <small class="text-muted">Amount</small>
              <div style="font-weight:600"><?= $b['total_amount']?formatCurrency($b['total_amount']):'Pending Quote' ?></div>
            </div>
            <div><?= getStatusBadge($b['status']) ?></div>
            <a href="<?= BASE_URL ?>/customer/bookings/view.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-outline-primary">View Details</a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
</body>
</html>
