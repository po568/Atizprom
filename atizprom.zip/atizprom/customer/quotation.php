<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();
$success = ''; $error = '';
$productId = (int)($_GET['product_id'] ?? 0);
$product = $productId ? $db->fetchOne("SELECT p.*, pc.name as cat_name FROM products p JOIN product_categories pc ON p.category_id=pc.id WHERE p.id=?", [$productId]) : null;

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) { $error = 'Invalid security token.'; }
    else {
        $quoteNum = $auth->generateNumber('QT', 'quotations', 'quotation_number');
        $items = [];
        if (!empty($_POST['items'])) {
            foreach ($_POST['items']['name'] as $k => $name) {
                if (trim($name)) $items[] = ['name'=>trim($name),'qty'=>(int)($_POST['items']['qty'][$k]??1),'unit_price'=>(float)($_POST['items']['price'][$k]??0),'total'=>(int)($_POST['items']['qty'][$k]??1)*(float)($_POST['items']['price'][$k]??0)];
            }
        }
        $subtotal = array_sum(array_column($items,'total'));

        $attachments = [];
        if (!empty($_FILES['attachments']['name'][0])) {
            foreach ($_FILES['attachments']['tmp_name'] as $k => $tmp) {
                if ($tmp) { $f=['name'=>$_FILES['attachments']['name'][$k],'type'=>$_FILES['attachments']['type'][$k],'tmp_name'=>$tmp,'size'=>$_FILES['attachments']['size'][$k]]; $r=uploadFile($f,'documents'); if ($r['success']) $attachments[]=$r['path']; }
            }
        }

        $id = $db->insert(
            "INSERT INTO quotations (quotation_number,customer_id,title,description,items,subtotal,total,valid_until,status,customer_notes,file_attachments) VALUES (?,?,?,?,?,?,?,DATE_ADD(NOW(),INTERVAL 30 DAY),'sent',?,?)",
            [$quoteNum,$user['id'],$_POST['title'],$_POST['description']?:null,$items?json_encode($items):null,$subtotal,$subtotal,$_POST['notes']?:null,$attachments?json_encode($attachments):null]
        );
        if ($id) {
            $auth->logAudit($user['id'],'QUOTATION_REQUEST','quotations',$id);
            $success = "Quotation request #{$quoteNum} submitted! We'll send you a detailed quote within 24 hours.";
        } else $error = 'Submission failed. Please try again.';
    }
}
$services = $db->fetchAll("SELECT s.id, s.name, s.price_from, sc.name as cat FROM services s JOIN service_categories sc ON s.category_id=sc.id WHERE s.is_active=1 ORDER BY sc.name,s.name");
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Request Quotation – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include __DIR__ . '/includes/header.php'; ?>
<div class="customer-layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content">
      <div class="customer-page-header">
        <div class="cph-left">
          <div class="cph-icon"><i class="fas fa-file-invoice-dollar"></i></div>
          <div><h2>Request Quotation</h2><div class="cph-subtitle">Tell us what you need and we'll send you a detailed price quotation</div></div>
        </div>
      </div>

      <?php if ($success): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
      <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>

      <form method="POST" enctype="multipart/form-data" style="max-width:860px">
        <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">

        <?php if ($product): ?>
        <div style="background:var(--blue-light);border:2px solid var(--blue);border-radius:var(--radius);padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:14px">
          <i class="fas fa-box" style="font-size:1.5rem;color:var(--blue)"></i>
          <div>
            <strong style="color:var(--blue)">Product Quotation: <?= htmlspecialchars($product['name']) ?></strong>
            <p style="margin:4px 0 0;font-size:0.85rem;color:var(--text-muted)">Listed price: <?= formatCurrency($product['price']) ?> per <?= $product['unit'] ?></p>
          </div>
        </div>
        <?php endif; ?>

        <div class="card mb-3">
          <div class="card-header"><h4>Quotation Details</h4></div>
          <div class="card-body">
            <div class="form-group">
              <label>Title / Subject *</label>
              <input type="text" name="title" class="form-control" required
                value="<?= $product ? htmlspecialchars('Quotation for '.$product['name']) : '' ?>"
                placeholder="e.g. Wedding Photography Package, Logo Design, Office Supplies Order">
            </div>
            <div class="form-group">
              <label>Description / Requirements *</label>
              <textarea name="description" class="form-control" rows="4" required
                placeholder="Describe in detail what you need, including specifications, dimensions, quantities, timelines, etc."><?= $product ? htmlspecialchars("I would like a quotation for: {$product['name']}\nCategory: {$product['cat_name']}\nListed price: ".formatCurrency($product['price'])." per {$product['unit']}\n\nPlease provide your best price and availability.") : '' ?></textarea>
            </div>

            <!-- Item List -->
            <div class="form-group">
              <label>Item List (Optional – Add specific items with quantities)</label>
              <div id="itemsContainer">
                <div class="item-row" style="display:grid;grid-template-columns:3fr 1fr 1fr auto;gap:10px;margin-bottom:10px;align-items:end">
                  <div>
                    <label style="font-size:0.8rem;font-weight:600;margin-bottom:4px">Item Name</label>
                    <input type="text" name="items[name][]" class="form-control" placeholder="e.g. A4 Paper Ream" value="<?= $product ? htmlspecialchars($product['name']) : '' ?>">
                  </div>
                  <div>
                    <label style="font-size:0.8rem;font-weight:600;margin-bottom:4px">Qty</label>
                    <input type="number" name="items[qty][]" class="form-control" placeholder="1" min="1" value="1" oninput="calcTotal(this)">
                  </div>
                  <div>
                    <label style="font-size:0.8rem;font-weight:600;margin-bottom:4px">Est. Price (TZS)</label>
                    <input type="number" name="items[price][]" class="form-control" placeholder="0" min="0" value="<?= $product ? $product['price'] : '' ?>" oninput="calcTotal(this)">
                  </div>
                  <button type="button" onclick="this.closest('.item-row').remove(); calcSubtotal();" style="background:#F8D7DA;border:none;border-radius:8px;width:38px;height:38px;cursor:pointer;color:#721C24;margin-top:20px"><i class="fas fa-times"></i></button>
                </div>
              </div>
              <button type="button" onclick="addItem()" class="btn btn-sm btn-outline-primary"><i class="fas fa-plus"></i> Add Item</button>
              <div id="subtotalRow" style="margin-top:12px;text-align:right;font-size:0.9rem;display:none">
                <strong>Estimated Total: <span id="subtotalDisplay" style="color:var(--blue)">TZS 0</span></strong>
              </div>
            </div>

            <div class="form-group">
              <label>Additional Notes</label>
              <textarea name="notes" class="form-control" rows="3" placeholder="Any other information, preferred payment method, delivery requirements, etc."></textarea>
            </div>

            <div class="form-group">
              <label>Attachments (Optional)</label>
              <div class="file-upload-area" style="border:2px dashed var(--border);border-radius:10px;padding:20px;text-align:center;cursor:pointer" id="uploadArea2">
                <input type="file" name="attachments[]" multiple id="fileInput2" style="display:none" accept="image/*,.pdf,.doc,.docx,.zip">
                <i class="fas fa-paperclip" style="font-size:1.5rem;color:var(--text-muted)"></i>
                <p class="file-upload-label text-muted" style="margin:6px 0 0;font-size:0.85rem">Attach reference files, specs, or designs</p>
              </div>
            </div>
          </div>
        </div>

        <div class="d-flex gap-2 justify-content-end">
          <a href="<?= BASE_URL ?>/customer/" class="btn" style="border:1px solid var(--border)">Cancel</a>
          <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-paper-plane"></i> Submit Quotation Request</button>
        </div>
      </form>
    </div>
  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script>
function addItem() {
  const container = document.getElementById('itemsContainer');
  const row = document.createElement('div');
  row.className = 'item-row';
  row.style.cssText = 'display:grid;grid-template-columns:3fr 1fr 1fr auto;gap:10px;margin-bottom:10px;align-items:end';
  row.innerHTML = `<div><input type="text" name="items[name][]" class="form-control" placeholder="Item name"></div>
    <div><input type="number" name="items[qty][]" class="form-control" placeholder="1" min="1" value="1" oninput="calcSubtotal()"></div>
    <div><input type="number" name="items[price][]" class="form-control" placeholder="0" min="0" oninput="calcSubtotal()"></div>
    <button type="button" onclick="this.closest('.item-row').remove();calcSubtotal();" style="background:#F8D7DA;border:none;border-radius:8px;width:38px;height:38px;cursor:pointer;color:#721C24"><i class="fas fa-times"></i></button>`;
  container.appendChild(row);
}

function calcSubtotal() {
  let total = 0;
  document.querySelectorAll('.item-row').forEach(row => {
    const qty = parseFloat(row.querySelector('[name="items[qty][]"]')?.value) || 0;
    const price = parseFloat(row.querySelector('[name="items[price][]"]')?.value) || 0;
    total += qty * price;
  });
  const row = document.getElementById('subtotalRow');
  row.style.display = total > 0 ? 'block' : 'none';
  document.getElementById('subtotalDisplay').textContent = 'TZS ' + total.toLocaleString();
}

document.getElementById('uploadArea2').addEventListener('click', () => document.getElementById('fileInput2').click());
</script>
</body>
</html>
