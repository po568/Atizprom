<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$success = '';

if (isPost()) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $editableKeys = ['site_name','site_slogan','site_email','site_phone','site_address',
            'currency','currency_symbol','tax_rate','smtp_host','smtp_port','smtp_user','smtp_from_name',
            'facebook_url','instagram_url','tiktok_url','youtube_url'];
        foreach ($editableKeys as $key) {
            if (isset($_POST[$key])) {
                $db->execute("UPDATE settings SET setting_value=? WHERE setting_key=?", [trim($_POST[$key]), $key]);
            }
        }
        // SMTP password: only update if the admin actually typed a new value
        if (!empty($_POST['smtp_pass'])) {
            $db->execute("UPDATE settings SET setting_value=? WHERE setting_key='smtp_pass'", [trim($_POST['smtp_pass'])]);
        }
        // Booleans: checkboxes only appear in POST when checked
        foreach (['maintenance_mode','allow_registration'] as $boolKey) {
            $db->execute("UPDATE settings SET setting_value=? WHERE setting_key=?", [isset($_POST[$boolKey]) ? '1' : '0', $boolKey]);
        }
        $auth->logAudit($user['id'], 'SETTINGS_UPDATED', 'settings', 0);
        $success = 'Settings updated successfully!';
    }
}

$rows = $db->fetchAll("SELECT * FROM settings");
$settings = [];
foreach ($rows as $r) { $settings[$r['setting_key']] = $r['setting_value']; }
function s($settings, $key, $default = '') { return htmlspecialchars($settings[$key] ?? $default); }
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>System Settings – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">System Settings</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Settings</div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:800px">
    <?php if ($success): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>

    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">

      <div class="card mb-3">
        <div class="card-header"><h4><i class="fas fa-globe text-primary"></i> General Information</h4></div>
        <div class="card-body">
          <div class="form-group"><label>Site Name</label><input type="text" name="site_name" class="form-control" value="<?= s($settings,'site_name') ?>"></div>
          <div class="form-group"><label>Slogan</label><input type="text" name="site_slogan" class="form-control" value="<?= s($settings,'site_slogan') ?>"></div>
          <div class="form-row">
            <div class="form-group"><label>Contact Email</label><input type="email" name="site_email" class="form-control" value="<?= s($settings,'site_email') ?>"></div>
            <div class="form-group"><label>Contact Phone</label><input type="text" name="site_phone" class="form-control" value="<?= s($settings,'site_phone') ?>"></div>
          </div>
          <div class="form-group"><label>Address</label><input type="text" name="site_address" class="form-control" value="<?= s($settings,'site_address') ?>"></div>
          <div class="form-row">
            <div class="form-group"><label><input type="checkbox" name="allow_registration" value="1" <?= ($settings['allow_registration']??'1')=='1'?'checked':'' ?>> Allow new customer registration</label></div>
            <div class="form-group"><label><input type="checkbox" name="maintenance_mode" value="1" <?= ($settings['maintenance_mode']??'0')=='1'?'checked':'' ?>> Maintenance mode</label></div>
          </div>
        </div>
      </div>

      <div class="card mb-3">
        <div class="card-header"><h4><i class="fas fa-coins text-primary"></i> Financial Settings</h4></div>
        <div class="card-body">
          <div class="form-row">
            <div class="form-group"><label>Currency Code</label><input type="text" name="currency" class="form-control" value="<?= s($settings,'currency') ?>"></div>
            <div class="form-group"><label>Currency Symbol</label><input type="text" name="currency_symbol" class="form-control" value="<?= s($settings,'currency_symbol') ?>"></div>
            <div class="form-group"><label>Tax Rate (%)</label><input type="number" name="tax_rate" class="form-control" value="<?= s($settings,'tax_rate') ?>" step="0.1" min="0"></div>
          </div>
        </div>
      </div>

      <div class="card mb-3">
        <div class="card-header"><h4><i class="fas fa-envelope text-primary"></i> Email / SMTP Settings</h4></div>
        <div class="card-body">
          <div class="form-row">
            <div class="form-group"><label>SMTP Host</label><input type="text" name="smtp_host" class="form-control" value="<?= s($settings,'smtp_host') ?>"></div>
            <div class="form-group"><label>SMTP Port</label><input type="number" name="smtp_port" class="form-control" value="<?= s($settings,'smtp_port') ?>"></div>
          </div>
          <div class="form-group"><label>SMTP Username</label><input type="text" name="smtp_user" class="form-control" value="<?= s($settings,'smtp_user') ?>"></div>
          <div class="form-group"><label>SMTP Password / App Password</label><input type="password" name="smtp_pass" class="form-control" value="<?= s($settings,'smtp_pass') ?>" placeholder="Leave blank to keep unchanged"></div>
          <div class="form-group"><label>From Name</label><input type="text" name="smtp_from_name" class="form-control" value="<?= s($settings,'smtp_from_name') ?>"></div>
        </div>
      </div>

      <div class="card mb-3">
        <div class="card-header"><h4><i class="fas fa-share-alt text-primary"></i> Social Media Links</h4></div>
        <div class="card-body">
          <div class="form-group"><label><i class="fab fa-facebook"></i> Facebook</label><input type="url" name="facebook_url" class="form-control" value="<?= s($settings,'facebook_url') ?>"></div>
          <div class="form-group"><label><i class="fab fa-instagram"></i> Instagram</label><input type="url" name="instagram_url" class="form-control" value="<?= s($settings,'instagram_url') ?>"></div>
          <div class="form-group"><label><i class="fab fa-tiktok"></i> TikTok</label><input type="url" name="tiktok_url" class="form-control" value="<?= s($settings,'tiktok_url') ?>"></div>
          <div class="form-group"><label><i class="fab fa-youtube"></i> YouTube</label><input type="url" name="youtube_url" class="form-control" value="<?= s($settings,'youtube_url') ?>"></div>
        </div>
      </div>

      <div class="d-flex justify-content-end">
        <button type="submit" class="btn btn-primary btn-lg"><i class="fas fa-save"></i> Save All Settings</button>
      </div>
    </form>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
