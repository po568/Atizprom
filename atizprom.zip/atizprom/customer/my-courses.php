<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();
$courseId = (int)($_GET['id'] ?? 0);

if ($courseId) {
    $enrollment = $db->fetchOne(
        "SELECT ce.*, c.title, c.description, c.category, c.instructor_id,
         CONCAT(i.first_name,' ',i.last_name) as instructor_name
         FROM course_enrollments ce
         JOIN courses c ON ce.course_id=c.id
         LEFT JOIN users i ON c.instructor_id=i.id
         WHERE ce.course_id=? AND ce.student_id=?",
        [$courseId, $user['id']]
    );
    if (!$enrollment) redirect(BASE_URL.'/customer/my-courses.php');
    $canAccess = in_array($enrollment['status'], ['active', 'completed']);
    if ($canAccess) {
        $lessons = $db->fetchAll(
            "SELECT * FROM course_lessons WHERE course_id=? AND is_active=1
             ORDER BY scheduled_date IS NULL, scheduled_date, scheduled_time, sort_order",
            [$courseId]
        );
        $materials = $db->fetchAll(
            "SELECT * FROM course_materials WHERE course_id=? ORDER BY created_at DESC",
            [$courseId]
        );
    }
} else {
    $myCourses = $db->fetchAll(
        "SELECT ce.*, c.title, c.category, c.thumbnail
         FROM course_enrollments ce JOIN courses c ON ce.course_id=c.id
         WHERE ce.student_id=? ORDER BY ce.enrolled_at DESC",
        [$user['id']]
    );
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Courses – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include __DIR__ . '/includes/header.php'; ?>
<div class="customer-layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content" style="max-width:860px">

    <?php if ($courseId && $enrollment): ?>
      <a href="<?= BASE_URL ?>/customer/my-courses.php" class="customer-breadcrumb" style="display:inline-block"><i class="fas fa-arrow-left"></i> Back to My Courses</a>
      <div class="d-flex justify-content-between align-items-center mt-3 mb-3">
        <div>
          <h2 style="margin-bottom:2px"><?= htmlspecialchars($enrollment['title']) ?></h2>
          <p class="text-muted" style="margin:0">Instructor: <strong><?= htmlspecialchars($enrollment['instructor_name'] ?: 'To be assigned') ?></strong> · Enrollment #<?= $enrollment['enrollment_number'] ?></p>
        </div>
        <?= getStatusBadge($enrollment['status']) ?>
      </div>

      <?php if (!$canAccess): ?>
      <!-- Approval pending -->
      <div class="card"><div class="card-body text-center" style="padding:50px">
        <i class="fas fa-lock" style="font-size:2.5rem;color:var(--border);display:block;margin-bottom:14px"></i>
        <h4>Materials Not Yet Available</h4>
        <p class="text-muted">Course materials and timetable will unlock once your enrollment has been accepted by our admin team and approved by finance.</p>
        <div style="display:inline-flex;flex-direction:column;gap:8px;text-align:left;margin-top:14px">
          <div class="d-flex align-items-center gap-2">
            <i class="fas <?= $enrollment['admin_approved']?'fa-check-circle':'fa-circle' ?>" style="color:<?= $enrollment['admin_approved']?'#28A745':'var(--border)' ?>"></i>
            <span>Admin acceptance <?= $enrollment['admin_approved']?'<strong>(done)</strong>':'<span class="text-muted">(pending)</span>' ?></span>
          </div>
          <div class="d-flex align-items-center gap-2">
            <i class="fas <?= $enrollment['finance_approved']?'fa-check-circle':'fa-circle' ?>" style="color:<?= $enrollment['finance_approved']?'#28A745':'var(--border)' ?>"></i>
            <span>Finance approval <?= $enrollment['finance_approved']?'<strong>(done)</strong>':'<span class="text-muted">(pending)</span>' ?></span>
          </div>
        </div>
      </div></div>

      <?php else: ?>
      <!-- Progress bar -->
      <div class="card mb-4">
        <div class="card-body">
          <div class="d-flex justify-content-between mb-2"><strong>Your Progress</strong><span><?= $enrollment['progress'] ?>%</span></div>
          <div class="progress"><div class="progress-bar" style="width:<?= $enrollment['progress'] ?>%"></div></div>
        </div>
      </div>

      <!-- Tabs -->
      <div style="display:flex;gap:0;border-bottom:2px solid var(--border);margin-bottom:24px">
        <button class="mctab active" onclick="switchMCTab('timetable',this)" style="padding:10px 20px;border:none;background:none;cursor:pointer;font-weight:600;border-bottom:3px solid var(--blue);color:var(--blue)">
          <i class="fas fa-calendar-alt"></i> Timetable
        </button>
        <button class="mctab" onclick="switchMCTab('materials',this)" style="padding:10px 20px;border:none;background:none;cursor:pointer;font-weight:600;color:var(--text-muted)">
          <i class="fas fa-folder-open"></i> Learning Materials (<?= count($materials) ?>)
        </button>
      </div>

      <!-- Timetable tab -->
      <div id="mctab-timetable">
        <div class="card">
          <div class="card-header"><h4>Lesson Timetable</h4></div>
          <div class="card-body" style="padding:0">
            <?php if (empty($lessons)): ?>
            <p class="text-muted text-center" style="padding:40px">
              <i class="fas fa-calendar-times" style="font-size:2rem;display:block;margin-bottom:10px;opacity:0.3"></i>
              Your instructor hasn't scheduled any lessons yet. Check back soon.
            </p>
            <?php else: ?>
            <?php foreach ($lessons as $i => $l): ?>
            <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;gap:14px;align-items:flex-start">
              <div style="width:38px;height:38px;border-radius:50%;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0"><?= $i+1 ?></div>
              <div style="flex:1">
                <strong><?= htmlspecialchars($l['title']) ?></strong>
                <?php if ($l['description']): ?><p class="text-muted" style="font-size:0.85rem;margin:4px 0"><?= htmlspecialchars($l['description']) ?></p><?php endif; ?>
                <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:0.82rem;margin-top:6px">
                  <?php if ($l['scheduled_date']): ?>
                  <span style="color:var(--blue)"><i class="fas fa-calendar"></i> <?= date('D, d M Y', strtotime($l['scheduled_date'])) ?></span>
                  <?php endif; ?>
                  <?php if ($l['scheduled_time']): ?>
                  <span style="color:var(--blue)"><i class="fas fa-clock"></i> <?= date('H:i', strtotime($l['scheduled_time'])) ?></span>
                  <?php endif; ?>
                  <?php if ($l['duration_minutes']): ?>
                  <span class="text-muted"><i class="fas fa-hourglass-half"></i> <?= $l['duration_minutes'] ?> min</span>
                  <?php endif; ?>
                </div>
                <div class="d-flex gap-2 mt-2">
                  <?php if ($l['video_url']): ?>
                  <a href="<?= htmlspecialchars($l['video_url']) ?>" target="_blank" class="btn btn-sm btn-primary"><i class="fas fa-play"></i> Watch Lesson</a>
                  <?php endif; ?>
                  <?php if ($l['file_attachment']): ?>
                  <a href="<?= UPLOAD_URL . $l['file_attachment'] ?>" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-download"></i> Lesson File</a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Materials tab -->
      <div id="mctab-materials" style="display:none">
        <div class="card">
          <div class="card-header"><h4>Learning Materials</h4></div>
          <div class="card-body" style="padding:0">
            <?php if (empty($materials)): ?>
            <p class="text-muted text-center" style="padding:40px">
              <i class="fas fa-folder-open" style="font-size:2rem;display:block;margin-bottom:10px;opacity:0.3"></i>
              No materials uploaded yet by your instructor.
            </p>
            <?php else: ?>
            <?php
            $generalMaterials = array_filter($materials, function($m) { return !$m['lesson_id']; });
            $lessonMaterials   = array_filter($materials, function($m) { return  $m['lesson_id']; });
            ?>
            <?php if ($generalMaterials): ?>
            <div style="padding:12px 20px;background:var(--blue-light)"><strong style="font-size:0.85rem;color:var(--blue)"><i class="fas fa-star"></i> General Course Materials</strong></div>
            <?php foreach ($generalMaterials as $m): ?>
            <div style="padding:14px 20px;border-bottom:1px solid var(--border);display:flex;gap:12px;align-items:center">
              <div style="width:36px;height:36px;border-radius:8px;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <i class="fas <?= in_array(strtolower($m['file_type']),['pdf'])? 'fa-file-pdf':( in_array(strtolower($m['file_type']),['ppt','pptx'])? 'fa-file-powerpoint': 'fa-file' ) ?>"></i>
              </div>
              <div style="flex:1">
                <strong><?= htmlspecialchars($m['title']) ?></strong>
                <?php if ($m['description']): ?><p class="text-muted" style="font-size:0.82rem;margin:2px 0"><?= htmlspecialchars($m['description']) ?></p><?php endif; ?>
                <small class="text-muted"><?= $m['file_type'] ?> · Uploaded <?= timeAgo($m['created_at']) ?></small>
              </div>
              <a href="<?= UPLOAD_URL . $m['file_path'] ?>" target="_blank" class="btn btn-sm btn-primary"><i class="fas fa-download"></i> Download</a>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
            <?php if ($lessonMaterials): ?>
            <div style="padding:12px 20px;background:#f8f9fa"><strong style="font-size:0.85rem;color:var(--text-muted)"><i class="fas fa-list"></i> Lesson-Specific Materials</strong></div>
            <?php foreach ($lessonMaterials as $m): ?>
            <div style="padding:14px 20px;border-bottom:1px solid var(--border);display:flex;gap:12px;align-items:center">
              <div style="width:36px;height:36px;border-radius:8px;background:var(--gray-light);color:var(--text-muted);display:flex;align-items:center;justify-content:center;flex-shrink:0">
                <i class="fas fa-file-alt"></i>
              </div>
              <div style="flex:1">
                <strong><?= htmlspecialchars($m['title']) ?></strong>
                <small class="text-muted"> · <?= $m['file_type'] ?> · <?= timeAgo($m['created_at']) ?></small>
              </div>
              <a href="<?= UPLOAD_URL . $m['file_path'] ?>" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-download"></i> Download</a>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php endif; ?>

    <?php else: ?>
      <!-- Course list -->
      <div class="customer-page-header">
        <div class="cph-left">
          <div class="cph-icon"><i class="fas fa-graduation-cap"></i></div>
          <div><h2>My Courses</h2><div class="cph-subtitle">Track your enrollments and access course materials</div></div>
        </div>
      </div>

      <?php if (empty($myCourses)): ?>
      <div class="card"><div class="card-body text-center" style="padding:60px">
        <i class="fas fa-graduation-cap" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i>
        <h4>No course enrollments yet</h4>
        <a href="<?= BASE_URL ?>/customer/courses.php" class="btn btn-primary mt-2">Browse Courses</a>
      </div></div>
      <?php else: ?>
      <div style="display:grid;gap:16px">
        <?php foreach ($myCourses as $mc): ?>
        <a href="?id=<?= $mc['course_id'] ?>" class="card" style="text-decoration:none;color:inherit">
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
              <h4 style="margin:0"><?= htmlspecialchars($mc['title']) ?></h4>
              <?= getStatusBadge($mc['status']) ?>
            </div>
            <?php if (in_array($mc['status'],['active','completed'])): ?>
            <div class="progress mt-2"><div class="progress-bar" style="width:<?= $mc['progress'] ?>%"></div></div>
            <small class="text-muted"><?= $mc['progress'] ?>% complete · <?= $mc['enrollment_number'] ?></small>
            <?php else: ?>
            <small class="text-muted"><i class="fas fa-hourglass-half"></i> Awaiting approval · <?= $mc['enrollment_number'] ?></small>
            <?php endif; ?>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    <?php endif; ?>

    </div>
  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script>
function switchMCTab(tab, btn) {
  document.querySelectorAll('[id^="mctab-"]').forEach(t => t.style.display = 'none');
  document.getElementById('mctab-' + tab).style.display = 'block';
  document.querySelectorAll('.mctab').forEach(b => {
    b.style.color = 'var(--text-muted)';
    b.style.borderBottom = '3px solid transparent';
  });
  btn.style.color = 'var(--blue)';
  btn.style.borderBottom = '3px solid var(--blue)';
}
</script>
</body>
</html>
