<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$user = $auth->getCurrentUser();
$db = Database::getInstance();
$notifs = $db->fetchAll("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50", [$user['id']]);
$db->execute("UPDATE notifications SET is_read=1 WHERE user_id=?", [$user['id']]);
?>
<!DOCTYPE html><html lang="en" <?= themeAttr() ?>><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notifications – Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"></head>
<body><div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include __DIR__.'/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
<div class="top-header"><div class="header-left"><button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button><div class="header-title">Notifications</div></div></div>
<div class="content-body">
<div class="card"><div class="card-body" style="padding:0">
<?php if (empty($notifs)): ?>
<p class="text-center text-muted" style="padding:50px">No notifications yet</p>
<?php else: foreach ($notifs as $n): ?>
<div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;gap:14px">
<div style="width:38px;height:38px;border-radius:10px;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center"><i class="fas fa-bell"></i></div>
<div><div style="font-weight:600"><?=htmlspecialchars($n['title'])?></div><div style="font-size:0.88rem;color:var(--text-muted)"><?=htmlspecialchars($n['message'])?></div><small class="text-muted"><?=timeAgo($n['created_at'])?></small></div>
</div>
<?php endforeach; endif; ?>
</div></div>
</div></div></div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script><script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body></html>
