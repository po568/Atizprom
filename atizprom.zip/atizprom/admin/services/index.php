<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();

if (isPost() && isset($_POST['delete_id'])) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $db->execute("DELETE FROM services WHERE id=?", [(int)$_POST['delete_id']]);
        $auth->logAudit($user['id'], 'SERVICE_DELETED', 'services', (int)$_POST['delete_id']);
        redirect(BASE_URL.'/admin/services/?deleted=1');
    }
}

$catId = $_GET['cat'] ?? '';
$where = ['1=1']; $params = []; $types = '';
if ($catId) { $where[] = 's.category_id=?'; $params[] = (int)$catId; $types .= 'i'; }
$services = $db->fetchAll(
    "SELECT s.*, sc.name as category_name, sc.icon FROM services s JOIN service_categories sc ON s.category_id=sc.id WHERE ".implode(' AND ',$where)." ORDER BY sc.sort_order, s.sort_order",
    $params, $types
);
$categories = $db->fetchAll("SELECT * FROM service_categories ORDER BY sort_order");
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Services – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Services</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Services</div></div>
    </div>
    <div class="header-actions">
      <a href="<?= BASE_URL ?>/admin/services/create.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add Service</a>
    </div>
  </div>
  <div class="content-body">
    <?php if (isset($_GET['created'])): ?><div class="alert alert-success mb-3">Service added successfully!</div><?php endif; ?>
    <?php if (isset($_GET['updated'])): ?><div class="alert alert-success mb-3">Service updated successfully!</div><?php endif; ?>
    <?php if (isset($_GET['deleted'])): ?><div class="alert alert-success mb-3">Service removed.</div><?php endif; ?>

    <div class="card">
      <div class="card-body">
        <div class="dt-filters mb-3">
          <a href="?" class="btn btn-sm <?= !$catId?'btn-primary':'btn-outline-primary' ?>">All Categories</a>
          <?php foreach ($categories as $c): ?>
          <a href="?cat=<?= $c['id'] ?>" class="btn btn-sm <?= $catId==$c['id']?'btn-primary':'btn-outline-primary' ?>"><i class="fas <?= $c['icon'] ?>"></i> <?= htmlspecialchars($c['name']) ?></a>
          <?php endforeach; ?>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Service</th><th>Category</th><th>Starting Price</th><th>Duration</th><th>Active</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($services as $s): ?>
              <tr>
                <td><strong><?= htmlspecialchars($s['name']) ?></strong></td>
                <td><i class="fas <?= $s['icon'] ?>"></i> <?= htmlspecialchars($s['category_name']) ?></td>
                <td><?= $s['price_from'] ? formatCurrency($s['price_from']) : 'Custom Quote' ?></td>
                <td><?= htmlspecialchars($s['duration'] ?: '-') ?></td>
                <td><?= $s['is_active'] ? '<span class="badge badge-success">Yes</span>' : '<span class="badge badge-secondary">No</span>' ?></td>
                <td>
                  <div class="d-flex gap-1">
                    <a href="<?= BASE_URL ?>/admin/services/edit.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                    <form method="POST" onsubmit="return confirm('Delete this service permanently?')">
                      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
                      <input type="hidden" name="delete_id" value="<?= $s['id'] ?>">
                      <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                    </form>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($services)): ?><tr><td colspan="6" class="text-center text-muted" style="padding:40px">No services yet</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
