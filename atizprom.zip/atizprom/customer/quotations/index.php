<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();

// Handle accept/reject — customer can express interest or decline, but final approval is admin-only
if (isPost() && isset($_POST['quotation_action'])) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $qid = (int)$_POST['quotation_id'];
        $newStatus = $_POST['quotation_action']==='accept' ? 'accepted' : 'rejected';
        $db->execute("UPDATE quotations SET status=? WHERE id=? AND customer_id=? AND status='sent'", [$newStatus,$qid,$user['id']]);
        $auth->logAudit($user['id'],'QUOTATION_'.strtoupper($newStatus),'quotations',$qid);
        if ($newStatus === 'accepted') {
            $q = $db->fetchOne("SELECT * FROM quotations WHERE id=?", [$qid]);
            $admins = $db->fetchAll("SELECT id FROM users WHERE role_id IN (1,2)");
            foreach ($admins as $a) {
                $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                    [$a['id'], 'Quotation Accepted by Customer', "{$user['first_name']} {$user['last_name']} accepted quotation #{$q['quotation_number']}. Final approval needed.", 'quotation', BASE_URL.'/admin/quotations/']);
            }
        }
    }
}

$quotations = $db->fetchAll("SELECT * FROM quotations WHERE customer_id=? ORDER BY created_at DESC", [$user['id']]);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Quotations – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include BASE_PATH . '/customer/includes/header.php'; ?>
<div class="customer-layout">
  <?php include BASE_PATH . '/customer/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content">
      <div class="customer-page-header">
        <div class="cph-left">
          <div class="cph-icon"><i class="fas fa-file-alt"></i></div>
          <div><h2>My Quotations</h2><div class="cph-subtitle">View and respond to your quotation requests</div></div>
        </div>
        <div class="cph-actions">
          <a href="<?= BASE_URL ?>/customer/quotation.php" class="btn btn-primary"><i class="fas fa-plus"></i> New Request</a>
        </div>
      </div>

      <?php if (empty($quotations)): ?>
      <div class="card"><div class="card-body text-center" style="padding:60px"><i class="fas fa-file-invoice" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i><h4>No quotations yet</h4></div></div>
      <?php else: ?>
      <div style="display:grid;gap:16px">
        <?php foreach ($quotations as $q): ?>
        <div class="card">
          <div class="card-body">
            <div class="d-flex align-items-center justify-content-between mb-2">
              <div>
                <strong><?= htmlspecialchars($q['title']) ?></strong><br>
                <small class="text-muted"><?= $q['quotation_number'] ?> · Requested <?= timeAgo($q['created_at']) ?></small>
              </div>
              <?= getStatusBadge($q['status']) ?>
            </div>
            <p style="font-size:0.9rem;color:var(--text-muted)"><?= htmlspecialchars(substr($q['description'] ?? '',0,150)) ?></p>
            <div class="d-flex align-items-center justify-content-between" style="margin-top:12px">
              <div>
                <?php if ($q['total'] > 0): ?>
                <span style="font-size:1.2rem;font-weight:800;color:var(--blue)"><?= formatCurrency($q['total']) ?></span>
                <?php else: ?>
                <span class="text-muted">Awaiting price quote</span>
                <?php endif; ?>
              </div>
              <?php if ($q['status']==='sent'): ?>
              <div class="d-flex gap-2">
                <form method="POST" style="display:inline">
                  <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
                  <input type="hidden" name="quotation_id" value="<?= $q['id'] ?>">
                  <button type="submit" name="quotation_action" value="reject" class="btn btn-sm" style="border:1px solid #DC3545;color:#DC3545" onclick="return confirm('Decline this quotation?')"><i class="fas fa-times"></i> Decline</button>
                  <button type="submit" name="quotation_action" value="accept" class="btn btn-sm btn-success"><i class="fas fa-check"></i> Accept Price</button>
                </form>
              </div>
              <?php elseif ($q['status']==='accepted'): ?>
              <span class="badge badge-info"><i class="fas fa-clock"></i> Awaiting Atiz Prom's final approval</span>
              <?php endif; ?>
            </div>
            <?php if ($q['admin_notes']): ?>
            <div style="background:var(--blue-light);border-radius:8px;padding:10px 14px;margin-top:10px;font-size:0.85rem">
              <strong>Note from Atiz Prom:</strong> <?= htmlspecialchars($q['admin_notes']) ?>
            </div>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
</body>
</html>
