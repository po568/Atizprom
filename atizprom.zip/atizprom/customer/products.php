<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$db = Database::getInstance();

// Public page - no login required
$catId  = (int)($_GET['cat'] ?? 0);
$search = $_GET['search'] ?? '';
$page   = max(1,(int)($_GET['page'] ?? 1));
$perPage= 12; $offset = ($page-1)*$perPage;

$where = ['p.is_active=1']; $params = []; $types = '';
if ($catId) { $where[] = 'p.category_id=?'; $params[] = $catId; $types .= 'i'; }
if ($search) { $where[] = '(p.name LIKE ? OR p.description LIKE ?)'; $q='%'.$search.'%'; $params=array_merge($params,[$q,$q]); $types.='ss'; }

$whereStr = implode(' AND ', $where);
$total = $db->fetchOne("SELECT COUNT(*) c FROM products p WHERE $whereStr", $params, $types)['c'] ?? 0;
$totalPages = ceil($total/$perPage);

$params[] = $perPage; $params[] = $offset; $types .= 'ii';
$products = $db->fetchAll("SELECT p.*, pc.name as cat_name FROM products p JOIN product_categories pc ON p.category_id=pc.id WHERE $whereStr ORDER BY p.is_featured DESC, p.created_at DESC LIMIT ? OFFSET ?", $params, $types);
$categories = $db->fetchAll("SELECT * FROM product_categories WHERE is_active=1 ORDER BY sort_order");
$isLoggedIn = $auth->isLoggedIn();
$user = $isLoggedIn ? $auth->getCurrentUser() : null;
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Products Catalog – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<?php if ($isLoggedIn && $user && $user['role_slug']==='customer'): ?>
<?php include __DIR__ . '/includes/header.php'; ?>
<div class="customer-layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="customer-main">
<?php else: ?>
<!-- Public navbar -->
<nav class="navbar" id="navbar">
  <div class="container">
    <a href="<?= BASE_URL ?>" class="navbar-brand">
      <div class="logo-icon"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div>
      <div class="logo-text"><strong>ATIZ PROM</strong><small>Home of All Tech Solutions</small></div>
    </a>
    <ul class="nav-menu" id="navMenu">
      <li><a href="<?= BASE_URL ?>">Home</a></li>
      <li><a href="<?= BASE_URL ?>/customer/services.php">Services</a></li>
      <li><a href="<?= BASE_URL ?>/customer/portfolio.php">Portfolio</a></li>
      <li class="nav-divider"></li>
      <li><a href="<?= BASE_URL ?>/customer/login.php" class="btn-nav-login"><i class="fas fa-user"></i> Login</a></li>
    </ul>
  </div>
</nav>
<div style="background:#F0F2F5;min-height:calc(100vh - 70px)">
<main>
<?php endif; ?>

    <div class="customer-content" style="<?= !$isLoggedIn?'max-width:1200px;margin:0 auto;padding:30px 20px':'' ?>">
      <?php if ($isLoggedIn && $user && $user['role_slug']==='customer'): ?>
      <div class="customer-page-header">
        <div class="cph-left">
          <div class="cph-icon"><i class="fas fa-box-open"></i></div>
          <div><h2>Products Catalog</h2><div class="cph-subtitle">Browse our products and request a quotation for any item. <strong>Online purchase is not available — contact us to order.</strong></div></div>
        </div>
      </div>
      <?php else: ?>
      <div style="margin-bottom:24px">
        <h2 style="margin-bottom:4px"><i class="fas fa-box-open text-primary"></i> Products Catalog</h2>
        <p class="text-muted">Browse our products and request a quotation for any item. <strong>Note: Online purchase is not available — contact us to order.</strong></p>
      </div>
      <?php endif; ?>

      <!-- Search & Filters -->
      <div class="card mb-4">
        <div class="card-body" style="padding:16px">
          <form method="GET" class="d-flex gap-2 align-items-center flex-wrap">
            <div style="flex:1;min-width:200px;position:relative">
              <i class="fas fa-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted)"></i>
              <input type="text" name="search" class="form-control" placeholder="Search products..." value="<?= htmlspecialchars($search) ?>" style="padding-left:36px">
            </div>
            <select name="cat" class="form-control" style="width:auto" onchange="this.form.submit()">
              <option value="">All Categories</option>
              <?php foreach ($categories as $c): ?>
              <option value="<?= $c['id'] ?>" <?= $catId==$c['id']?'selected':'' ?>><?= htmlspecialchars($c['name']) ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary">Search</button>
            <?php if ($search||$catId): ?><a href="<?= BASE_URL ?>/customer/products.php" class="btn" style="border:1px solid var(--border)">Clear</a><?php endif; ?>
          </form>
        </div>
      </div>

      <!-- Category Quick Links -->
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px">
        <a href="<?= BASE_URL ?>/customer/products.php" class="btn btn-sm <?= !$catId?'btn-primary':'btn-outline-primary' ?>">All</a>
        <?php foreach ($categories as $c): ?>
        <a href="?cat=<?= $c['id'] ?>" class="btn btn-sm <?= $catId==$c['id']?'btn-primary':'btn-outline-primary' ?>"><?= htmlspecialchars($c['name']) ?></a>
        <?php endforeach; ?>
      </div>

      <!-- Product Grid -->
      <?php if (empty($products)): ?>
      <div class="card">
        <div class="card-body text-center" style="padding:60px">
          <i class="fas fa-box-open" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i>
          <h4>No products found</h4>
          <p class="text-muted">Try a different search or category.</p>
        </div>
      </div>
      <?php else: ?>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:20px">
        <?php foreach ($products as $p): ?>
        <div class="product-card">
          <div class="product-card-img">
            <?php
            $imgs = $p['images'] ? json_decode($p['images'], true) : [];
            if (!empty($imgs[0])): ?>
              <img src="<?= UPLOAD_URL . $imgs[0] ?>" alt="<?= htmlspecialchars($p['name']) ?>">
            <?php else: ?>
              <i class="fas fa-image"></i>
            <?php endif; ?>
            <?php if ($p['is_featured']): ?>
            <div style="position:absolute;top:10px;left:10px;background:var(--yellow);color:var(--dark);padding:3px 10px;border-radius:20px;font-size:0.72rem;font-weight:700">FEATURED</div>
            <?php endif; ?>
          </div>
          <div class="product-card-body">
            <div style="font-size:0.75rem;color:var(--blue);font-weight:700;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:4px"><?= htmlspecialchars($p['cat_name']) ?></div>
            <h4><?= htmlspecialchars($p['name']) ?></h4>
            <p style="font-size:0.82rem;color:var(--text-muted);margin-bottom:8px"><?= htmlspecialchars(substr($p['description'],0,80)) ?>...</p>
            <div class="d-flex align-items-center justify-content-between mb-2">
              <div>
                <div class="product-card-price"><?= formatCurrency($p['price']) ?></div>
                <div class="product-card-unit">per <?= htmlspecialchars($p['unit']) ?></div>
              </div>
              <div class="product-stock <?= $p['stock_status']==='in_stock'?'in-stock':($p['stock_status']==='limited'?'limited':'out-stock') ?>">
                <i class="fas fa-circle" style="font-size:0.6rem"></i>
                <?= $p['stock_status']==='in_stock'?'In Stock':($p['stock_status']==='limited'?'Limited Stock':'Out of Stock') ?>
              </div>
            </div>
            <div class="d-flex gap-2">
              <button onclick="openProductModal(<?= htmlspecialchars(json_encode($p)) ?>)" class="btn btn-sm btn-outline-primary" style="flex:1"><i class="fas fa-eye"></i> View</button>
              <a href="<?= BASE_URL ?>/customer/quotation.php?product_id=<?= $p['id'] ?>" class="btn btn-sm btn-primary" style="flex:1"><i class="fas fa-file-invoice"></i> Quote</a>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Pagination -->
      <?php if ($totalPages > 1): ?>
      <div class="pagination mt-4">
        <?php for ($i=1;$i<=$totalPages;$i++): ?>
        <a href="?cat=<?= $catId ?>&search=<?= urlencode($search) ?>&page=<?= $i ?>" class="page-btn <?= $i===$page?'active':'' ?>"><?= $i ?></a>
        <?php endfor; ?>
      </div>
      <?php endif; ?>
      <?php endif; ?>

      <!-- Info Banner -->
      <div style="background:var(--blue-light);border:1px solid var(--blue);border-radius:var(--radius);padding:20px 24px;margin-top:30px;display:flex;align-items:center;gap:16px">
        <i class="fas fa-info-circle" style="font-size:1.5rem;color:var(--blue);flex-shrink:0"></i>
        <div>
          <strong style="color:var(--blue)">How to Order</strong>
          <p style="margin:4px 0 0;font-size:0.9rem;color:var(--text-muted)">Online purchasing is not available. To order any product, click <strong>Request Quote</strong> to send us your requirements, and our team will contact you with pricing and availability details.</p>
        </div>
      </div>
    </div>

<?php if ($isLoggedIn && $user && $user['role_slug']==='customer'): ?>
  </main>
</div>
<?php else: ?>
</main>
</div>
<?php include BASE_PATH . '/includes/footer_public.php'; ?>
<?php endif; ?>

<!-- Product Modal -->
<div class="modal-overlay" id="productModal">
  <div class="modal" style="max-width:640px">
    <div class="modal-header">
      <h4 id="modalProductName">Product Details</h4>
      <button class="modal-close" onclick="AtizProm.closeModal('productModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body" id="modalProductBody"></div>
    <div class="modal-footer">
      <button onclick="AtizProm.closeModal('productModal')" class="btn" style="border:1px solid var(--border)">Close</button>
      <a id="modalQuoteBtn" href="#" class="btn btn-primary"><i class="fas fa-file-invoice"></i> Request Quotation</a>
    </div>
  </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script>
function openProductModal(p) {
  document.getElementById('modalProductName').textContent = p.name;
  document.getElementById('modalQuoteBtn').href = '<?= BASE_URL ?>/customer/quotation.php?product_id=' + p.id;
  const body = document.getElementById('modalProductBody');
  const imgs = p.images ? JSON.parse(p.images) : [];
  body.innerHTML = `
    ${imgs[0] ? `<img src="<?= UPLOAD_URL ?>${imgs[0]}" style="width:100%;border-radius:10px;margin-bottom:16px;object-fit:cover;max-height:250px">` : ''}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
      <div><strong>Price:</strong> <span style="color:var(--blue);font-weight:700">TZS ${Number(p.price).toLocaleString()}</span> per ${p.unit}</div>
      <div><strong>SKU:</strong> ${p.sku || 'N/A'}</div>
      <div><strong>Category:</strong> ${p.cat_name || ''}</div>
      <div><strong>Status:</strong> ${p.stock_status === 'in_stock' ? '<span style="color:#155724">In Stock</span>' : p.stock_status === 'limited' ? '<span style="color:#856404">Limited Stock</span>' : '<span style="color:#721C24">Out of Stock</span>'}</div>
    </div>
    <p>${p.description || ''}</p>
    ${p.specifications ? `<div style="background:var(--gray-light);border-radius:8px;padding:14px;margin-top:12px"><strong>Specifications:</strong><br><small>${p.specifications}</small></div>` : ''}
    <div style="background:var(--yellow-light);border:1px solid var(--yellow);border-radius:8px;padding:12px;margin-top:14px;font-size:0.85rem">
      <i class="fas fa-info-circle" style="color:var(--yellow-dark)"></i> <strong>Note:</strong> Online purchase is not available. Click "Request Quotation" to order this product.
    </div>`;
  AtizProm.openModal('productModal');
}
</script>
</body>
</html>
