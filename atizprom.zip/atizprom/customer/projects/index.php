<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();
$id = (int)($_GET['id'] ?? 0);

if ($id) {
    $project = $db->fetchOne("SELECT * FROM projects WHERE id=? AND customer_id=?", [$id, $user['id']]);
    if (!$project) redirect(BASE_URL.'/customer/projects/');
    $milestones = $db->fetchAll("SELECT * FROM project_milestones WHERE project_id=? ORDER BY sort_order, due_date", [$id]);
    $files = $db->fetchAll("SELECT * FROM project_files WHERE project_id=? ORDER BY created_at DESC", [$id]);
} else {
    $projects = $db->fetchAll("SELECT * FROM projects WHERE customer_id=? ORDER BY created_at DESC", [$user['id']]);
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Projects – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include BASE_PATH . '/customer/includes/header.php'; ?>
<div class="customer-layout">
  <?php include BASE_PATH . '/customer/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content">
    <?php if ($id && $project): ?>
      <a href="<?= BASE_URL ?>/customer/projects/" class="customer-breadcrumb" style="display:inline-block"><i class="fas fa-arrow-left"></i> Back to Projects</a>
      <div class="d-flex align-items-center justify-content-between mt-3 mb-4">
        <div><h2 style="margin-bottom:4px"><?= htmlspecialchars($project['title']) ?></h2><p class="text-muted" style="margin:0">Project #<?= $project['project_number'] ?></p></div>
        <?= getStatusBadge($project['status']) ?>
      </div>
      <div class="card mb-3">
        <div class="card-body">
          <div class="d-flex justify-content-between mb-2"><strong>Progress</strong><span><?= $project['progress'] ?>%</span></div>
          <div class="progress"><div class="progress-bar" style="width:<?= $project['progress'] ?>%"></div></div>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
        <div class="card">
          <div class="card-header"><h4>Project Details</h4></div>
          <div class="card-body">
            <p><?= nl2br(htmlspecialchars($project['description'] ?? 'No description provided.')) ?></p>
            <div style="margin-top:14px;display:flex;flex-direction:column;gap:8px;font-size:0.9rem">
              <div class="d-flex justify-content-between"><span class="text-muted">Category</span><strong><?= htmlspecialchars($project['category'] ?: '-') ?></strong></div>
              <div class="d-flex justify-content-between"><span class="text-muted">Start Date</span><strong><?= formatDate($project['start_date']) ?></strong></div>
              <div class="d-flex justify-content-between"><span class="text-muted">Deadline</span><strong><?= formatDate($project['deadline']) ?></strong></div>
              <div class="d-flex justify-content-between"><span class="text-muted">Budget</span><strong><?= $project['budget']?formatCurrency($project['budget']):'-' ?></strong></div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header"><h4>Milestones</h4></div>
          <div class="card-body">
            <?php if (empty($milestones)): ?>
            <p class="text-muted text-center" style="padding:20px">No milestones set yet</p>
            <?php else: ?>
            <div class="timeline">
              <?php foreach ($milestones as $m): ?>
              <div class="timeline-item">
                <div class="timeline-dot <?= $m['status'] ?>"></div>
                <div class="timeline-content">
                  <h5><?= htmlspecialchars($m['title']) ?></h5>
                  <p><?= htmlspecialchars($m['description'] ?? '') ?></p>
                  <div class="timeline-time"><?= $m['due_date']?formatDate($m['due_date']):'' ?> · <?= getStatusBadge($m['status']) ?></div>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php if (!empty($files)): ?>
      <div class="card mt-3">
        <div class="card-header"><h4>Project Files</h4></div>
        <div class="card-body">
          <?php foreach ($files as $f): ?>
          <a href="<?= UPLOAD_URL . $f['file_path'] ?>" target="_blank" class="d-flex align-items-center gap-2" style="padding:10px 0;border-bottom:1px solid var(--border)">
            <i class="fas fa-file-download text-primary"></i> <?= htmlspecialchars($f['file_name']) ?>
            <small class="text-muted" style="margin-left:auto"><?= timeAgo($f['created_at']) ?></small>
          </a>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

    <?php else: ?>
      <div class="customer-page-header">
        <div class="cph-left">
          <div class="cph-icon"><i class="fas fa-project-diagram"></i></div>
          <div><h2>My Projects</h2><div class="cph-subtitle">Track the progress of all your projects with Atiz Prom</div></div>
        </div>
      </div>
      <?php if (empty($projects)): ?>
      <div class="card"><div class="card-body text-center" style="padding:60px"><i class="fas fa-project-diagram" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i><h4>No projects yet</h4><p class="text-muted">Projects are created once your bookings or quotations are confirmed.</p></div></div>
      <?php else: ?>
      <div style="display:grid;gap:16px">
        <?php foreach ($projects as $p): ?>
        <a href="?id=<?= $p['id'] ?>" class="card" style="text-decoration:none;color:inherit">
          <div class="card-body">
            <div class="d-flex align-items-center justify-content-between mb-2">
              <div><strong><?= htmlspecialchars($p['title']) ?></strong><br><small class="text-muted"><?= $p['project_number'] ?></small></div>
              <?= getStatusBadge($p['status']) ?>
            </div>
            <div class="progress"><div class="progress-bar" style="width:<?= $p['progress'] ?>%"></div></div>
            <small class="text-muted"><?= $p['progress'] ?>% complete</small>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    <?php endif; ?>
    </div>
  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
</body>
</html>
