<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','inventory_officer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();

if (isPost() && isset($_POST['delete_id'])) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $db->execute("DELETE FROM products WHERE id=?", [(int)$_POST['delete_id']]);
        $auth->logAudit($user['id'], 'PRODUCT_DELETED', 'products', (int)$_POST['delete_id']);
        redirect(BASE_URL.'/admin/products/?deleted=1');
    }
} elseif (isPost() && isset($_POST['quick_stock_update'])) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $db->execute("UPDATE products SET stock_status=? WHERE id=?", [$_POST['stock_status'], (int)$_POST['product_id']]);
        redirect(BASE_URL.'/admin/products/?stock_updated=1');
    }
}

$catId = $_GET['cat'] ?? '';
$where = ['1=1']; $params = []; $types = '';
if ($catId) { $where[] = 'p.category_id=?'; $params[] = (int)$catId; $types .= 'i'; }
$products = $db->fetchAll("SELECT p.*, pc.name as category_name FROM products p JOIN product_categories pc ON p.category_id=pc.id WHERE ".implode(' AND ',$where)." ORDER BY p.created_at DESC", $params, $types);
$categories = $db->fetchAll("SELECT * FROM product_categories ORDER BY sort_order");
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Product Catalog – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Product Catalog</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Products</div></div>
    </div>
    <div class="header-actions">
      <a href="<?= BASE_URL ?>/admin/products/records.php" class="btn btn-outline-primary btn-sm"><i class="fas fa-clipboard-list"></i> Stock Records</a>
      <a href="<?= BASE_URL ?>/admin/products/reports.php" class="btn btn-outline-primary btn-sm"><i class="fas fa-chart-line"></i> Sales Report</a>
      <a href="<?= BASE_URL ?>/admin/products/create.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Add Product</a>
    </div>
  </div>
  <div class="content-body">
    <?php if (isset($_GET['created'])): ?><div class="alert alert-success mb-3">Product added to catalog!</div><?php endif; ?>
    <?php if (isset($_GET['updated'])): ?><div class="alert alert-success mb-3">Product updated!</div><?php endif; ?>
    <?php if (isset($_GET['deleted'])): ?><div class="alert alert-success mb-3">Product removed.</div><?php endif; ?>
    <?php if (isset($_GET['stock_updated'])): ?><div class="alert alert-success mb-3">Stock status updated.</div><?php endif; ?>

    <div class="card">
      <div class="card-body">
        <div class="dt-filters mb-3">
          <a href="?" class="btn btn-sm <?= !$catId?'btn-primary':'btn-outline-primary' ?>">All Categories</a>
          <?php foreach ($categories as $c): ?>
          <a href="?cat=<?= $c['id'] ?>" class="btn btn-sm <?= $catId==$c['id']?'btn-primary':'btn-outline-primary' ?>"><?= htmlspecialchars($c['name']) ?></a>
          <?php endforeach; ?>
        </div>

        <?php if (empty($products)): ?>
        <p class="text-center text-muted" style="padding:50px">No products in the catalog yet — add what's currently available to advertise to customers.</p>
        <?php else: ?>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Qty</th><th>Stock</th><th>Active</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($products as $p): ?>
              <tr>
                <td><strong><?= htmlspecialchars($p['name']) ?></strong><?= $p['is_featured']?' <span class="badge badge-warning">Featured</span>':'' ?></td>
                <td><?= htmlspecialchars($p['category_name']) ?></td>
                <td><?= formatCurrency($p['price']) ?></td>
                <td><?= number_format((int)($p['quantity_in_stock'] ?? 0)) ?></td>
                <td>
                  <form method="POST" class="d-flex gap-1" style="align-items:center">
                    <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
                    <input type="hidden" name="quick_stock_update" value="1">
                    <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                    <select name="stock_status" class="form-control" style="width:auto;font-size:0.8rem;padding:4px 8px" onchange="this.form.submit()">
                      <option value="in_stock" <?= $p['stock_status']==='in_stock'?'selected':'' ?>>In Stock</option>
                      <option value="limited" <?= $p['stock_status']==='limited'?'selected':'' ?>>Limited Stock</option>
                      <option value="out_of_stock" <?= $p['stock_status']==='out_of_stock'?'selected':'' ?>>Out of Stock</option>
                    </select>
                  </form>
                </td>
                <td><?= $p['is_active'] ? '<span class="badge badge-success">Yes</span>' : '<span class="badge badge-secondary">No</span>' ?></td>
                <td>
                  <div class="d-flex gap-1">
                    <a href="<?= BASE_URL ?>/admin/products/edit.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
                    <form method="POST" onsubmit="return confirm('Delete this product permanently?')">
                      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
                      <input type="hidden" name="delete_id" value="<?= $p['id'] ?>">
                      <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                    </form>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
