# Administrator Manual – Atiz Prom Management System

## 1. Logging In
Visit `/admin/login.php` and sign in with your staff credentials. Roles determine which modules are visible in the sidebar.

## 2. Roles & Permissions

| Role | Access |
|---|---|
| Super Admin | Everything, including Settings and Branches |
| Admin | Customers, Bookings, Quotations, Projects, Contracts, Tickets, Portfolio, Courses, Products |
| Finance Officer | Invoices, Payments, Reports (+ Admin module access) |
| Production Manager | Bookings, Projects (media production focus) |
| Graphic Designer | Design-related projects and requests |
| Course Instructor | Courses, lessons, assignments, quizzes |
| Inventory Officer | Products and stationery catalog |

## 3. Dashboard Overview
The dashboard displays key metrics (customers, bookings, projects, revenue, enrollments, open tickets, pending quotations), a 6-month revenue chart, a bookings-by-service breakdown, recent bookings, and quick-action shortcuts.

## 4. Managing Bookings
- **Bookings → New Booking** to create on behalf of a customer
- Filter by status (Pending, Confirmed, In Progress, Completed, Cancelled) or search by booking number/customer/service
- Click the eye icon to view full details; the edit icon to modify
- Status changes trigger automatic customer notifications

## 5. Handling Quotation Requests
1. New requests appear with status **Draft/Sent** and `total = 0`
2. Click the paper-plane icon to open **Send Price Quotation**
3. Enter the final total and admin notes, then send — the customer is notified and can review in their portal

## 6. Managing Customers
- View customer profiles, booking/project counts, and activity from **Customers**
- Use **Add Customer** to manually register a client (e.g., for walk-in or phone bookings)

## 7. Projects & Milestones
- Convert confirmed bookings/quotations into **Projects** to track production work
- Update progress percentage, milestones, deadlines, and status through delivery

## 8. Finance Module (Finance Officer / Admin)
- **Invoices:** generate itemized invoices linked to bookings/projects with tax and discount support
- **Payments:** record payments by method (Cash, M-Pesa, Airtel Money, Tigo Pesa, HaloPesa, Bank Transfer) against invoices
- **Reports:** view monthly/annual revenue, booking, and completion-rate reports

## 9. Course Management
- Create/edit courses with category, mode (online/offline/hybrid), price, and capacity
- Add lessons, assignments, and quizzes per course
- Review enrollment requests and mark them active once payment is confirmed
- Issue certificates upon course completion

## 10. Product Catalog Management
- Add/edit/delete products under **Products**, organized by category (Office Supplies, Stationery, Technology, Printing Materials)
- Upload product images and mark items as featured or out-of-stock
- Remember: customers can only request quotes — there is no online checkout

## 11. Portfolio Management
- Upload completed work samples under **Portfolio**, categorized as Photography, Videography, Films, Graphics Design, or Events Coverage
- Mark featured items to surface them on the public homepage

## 12. Support Tickets
- Respond to customer tickets under **Support Tickets**; update status (Open → In Progress → Resolved → Closed)
- Assign tickets to specific staff members as needed

## 13. User & Role Management (Super Admin / Admin)
- Create staff accounts and assign roles under **Users & Roles**
- Manage branch records under **Branches** (default: Kyerwa Branch)

## 14. System Settings (Super Admin only)
- Update site information, SMTP email settings, currency/tax rate, and social media links under **Settings**

## 15. Security Best Practices
- Change all default passwords immediately after installation
- Delete the `/installer/` folder once setup is complete
- Review `audit_logs` periodically for suspicious activity
- Keep PHP and MySQL/MariaDB updated on the hosting server

---
For technical support, contact your system administrator or **atizpromltd@gmail.com**.
