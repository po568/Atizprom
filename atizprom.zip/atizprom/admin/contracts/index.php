<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$status = $_GET['status'] ?? '';
$where = ['1=1']; $params = []; $types = '';
if ($status) { $where[] = 'c.status=?'; $params[] = $status; $types .= 's'; }
$contracts = $db->fetchAll("SELECT c.*, CONCAT(u.first_name,' ',u.last_name) as customer_name, b.booking_number, p.project_number FROM contracts c JOIN users u ON c.customer_id=u.id LEFT JOIN bookings b ON c.booking_id=b.id LEFT JOIN projects p ON c.project_id=p.id WHERE ".implode(' AND ',$where)." ORDER BY c.created_at DESC", $params, $types);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contracts – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Contracts</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Contracts</div></div>
    </div>
  </div>
  <div class="content-body">
    <div class="card">
      <div class="card-body">
        <div class="d-flex align-items-center gap-3 mb-3">
          <div style="width:50px;height:50px;border-radius:14px;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center;font-size:1.4rem"><i class="fas fa-file-signature"></i></div>
          <div><h3 style="margin-bottom:2px">Contracts</h3><p class="text-muted" style="margin:0">Every confirmed booking and project automatically gets a draft contract here for you to review and send.</p></div>
        </div>
        <div class="dt-filters mb-3">
          <a href="?" class="btn btn-sm <?= !$status?'btn-primary':'btn-outline-primary' ?>">All</a>
          <?php foreach (['draft'=>'Draft','sent'=>'Sent','signed'=>'Signed','expired'=>'Expired','cancelled'=>'Cancelled'] as $k=>$v): ?>
          <a href="?status=<?= $k ?>" class="btn btn-sm <?= $status===$k?'btn-primary':'btn-outline-primary' ?>"><?= $v ?></a>
          <?php endforeach; ?>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Contract #</th><th>Customer</th><th>Title</th><th>Linked To</th><th>Value</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($contracts as $c): ?>
              <tr>
                <td><strong style="color:var(--blue)"><?= $c['contract_number'] ?></strong></td>
                <td><?= htmlspecialchars($c['customer_name']) ?></td>
                <td><?= htmlspecialchars($c['title']) ?></td>
                <td><?= $c['booking_number'] ? 'Booking '.$c['booking_number'] : ($c['project_number'] ? 'Project '.$c['project_number'] : '-') ?></td>
                <td><?= $c['value'] ? formatCurrency($c['value']) : '-' ?></td>
                <td><?= getStatusBadge($c['status']) ?></td>
                <td><a href="<?= BASE_URL ?>/admin/contracts/view.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-eye"></i> Manage</a></td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($contracts)): ?>
              <tr><td colspan="7" class="text-center text-muted" style="padding:40px">No contracts yet — they're created automatically when a booking is confirmed or a project is started</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
