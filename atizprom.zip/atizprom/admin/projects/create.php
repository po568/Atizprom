<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','production_manager','graphic_designer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$error = '';

$customers = $db->fetchAll("SELECT id, first_name, last_name, email FROM users WHERE role_id=8 ORDER BY first_name");
$bookings = $db->fetchAll("SELECT id, booking_number, customer_id FROM bookings WHERE status IN ('confirmed','in_progress')");
$quotations = $db->fetchAll("SELECT id, quotation_number, customer_id FROM quotations WHERE status IN ('accepted','approved')");
$staff = $db->fetchAll("SELECT id, first_name, last_name, role_id FROM users WHERE role_id IN (4,5) ORDER BY first_name");

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $projectNum = $auth->generateNumber('PJ', 'projects', 'project_number');
        $id = $db->insert(
            "INSERT INTO projects (project_number, customer_id, booking_id, quotation_id, manager_id, title, description, category, start_date, deadline, status, priority, budget, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NOW())",
            [$projectNum, (int)$_POST['customer_id'], $_POST['booking_id']?:null, $_POST['quotation_id']?:null, $_POST['manager_id']?:null, trim($_POST['title']), trim($_POST['description']??''), trim($_POST['category']??''), $_POST['start_date']?:null, $_POST['deadline']?:null, $_POST['status'], $_POST['priority'], $_POST['budget']?:null]
        );
        $auth->logAudit($user['id'], 'PROJECT_CREATED', 'projects', $id);

        // Auto-generate a draft digital contract for this project
        ensureContractExists($auth, 'project', $id);

        $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
            [(int)$_POST['customer_id'], 'New Project Started', "A new project \"".trim($_POST['title'])."\" has been created for you. A contract is being prepared for your review.", 'project', BASE_URL.'/customer/projects/?id='.$id]);

        redirect(BASE_URL.'/admin/projects/?created=1');
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>New Project – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">New Project</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/projects/">Projects</a> <span class="sep">/</span> New</div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:760px">
    <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <div class="alert alert-success mb-3" style="background:#E3F2FD;color:#0D47A1"><i class="fas fa-info-circle"></i> A draft digital contract will be generated automatically once this project is created.</div>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <div class="card">
        <div class="card-header"><h4>Project Details</h4></div>
        <div class="card-body">
          <div class="form-row">
            <div class="form-group">
              <label>Customer *</label>
              <select name="customer_id" class="form-control" required>
                <option value="">Select customer</option>
                <?php foreach ($customers as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['first_name'].' '.$c['last_name']) ?> (<?= htmlspecialchars($c['email']) ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Assign Manager</label>
              <select name="manager_id" class="form-control">
                <option value="">Unassigned</option>
                <?php foreach ($staff as $s): ?>
                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['first_name'].' '.$s['last_name']) ?> (<?= $s['role_id']==4?'Production':'Design' ?>)</option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label>Project Title *</label>
            <input type="text" name="title" class="form-control" required placeholder="e.g. Corporate Brand Film – Kagera Business Center">
          </div>
          <div class="form-group">
            <label>Description</label>
            <textarea name="description" class="form-control" rows="3" placeholder="Scope of work and deliverables"></textarea>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Category</label>
              <input type="text" name="category" class="form-control" placeholder="e.g. Videography, Graphics Design">
            </div>
            <div class="form-group">
              <label>Priority</label>
              <select name="priority" class="form-control">
                <option value="normal">Normal</option>
                <option value="low">Low</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Link to Booking (optional)</label>
              <select name="booking_id" class="form-control">
                <option value="">None</option>
                <?php foreach ($bookings as $b): ?>
                <option value="<?= $b['id'] ?>"><?= $b['booking_number'] ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Link to Quotation (optional)</label>
              <select name="quotation_id" class="form-control">
                <option value="">None</option>
                <?php foreach ($quotations as $q): ?>
                <option value="<?= $q['id'] ?>"><?= $q['quotation_number'] ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Start Date</label>
              <input type="date" name="start_date" class="form-control">
            </div>
            <div class="form-group">
              <label>Deadline</label>
              <input type="date" name="deadline" class="form-control">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Budget (TZS)</label>
              <input type="number" name="budget" class="form-control" min="0" step="1000">
            </div>
            <div class="form-group">
              <label>Initial Status</label>
              <select name="status" class="form-control">
                <option value="pending">Pending</option>
                <option value="approved">Approved</option>
                <option value="in_progress">In Progress</option>
              </select>
            </div>
          </div>
        </div>
        <div class="card-footer d-flex justify-content-end gap-2">
          <a href="<?= BASE_URL ?>/admin/projects/" class="btn" style="border:1px solid var(--border)">Cancel</a>
          <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create Project</button>
        </div>
      </div>
    </form>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
