<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$db = Database::getInstance();
$isLoggedIn = $auth->isLoggedIn();
$user = $isLoggedIn ? $auth->getCurrentUser() : null;

$serviceId = (int)($_GET['id'] ?? 0);
$catId = (int)($_GET['cat'] ?? 0);

if ($serviceId) {
    $service = $db->fetchOne("SELECT s.*, sc.name as cat_name, sc.icon FROM services s JOIN service_categories sc ON s.category_id=sc.id WHERE s.id=?", [$serviceId]);
    $related = $db->fetchAll("SELECT * FROM services WHERE category_id=? AND id!=? AND is_active=1 LIMIT 4", [$service['category_id'],$serviceId]);
} else {
    $service = null;
    $where = ['s.is_active=1']; $params=[]; $types='';
    if ($catId) { $where[]='s.category_id=?'; $params[]=$catId; $types.='i'; }
    $services = $db->fetchAll("SELECT s.*, sc.name as cat_name, sc.icon FROM services s JOIN service_categories sc ON s.category_id=sc.id WHERE ".implode(' AND ',$where)." ORDER BY sc.sort_order, s.sort_order", $params, $types);
    $categories = $db->fetchAll("SELECT * FROM service_categories WHERE is_active=1 ORDER BY sort_order");
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $service ? htmlspecialchars($service['name']) : 'Our Services' ?> – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/home.css">
<?php if ($isLoggedIn): ?><link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css"><?php endif; ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php if ($isLoggedIn && $user && $user['role_slug']==='customer'): ?>
<?php include __DIR__ . '/includes/header.php'; ?>
<div class="customer-layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="customer-main"><div class="customer-content">
<?php else: ?>
<nav class="navbar" id="navbar">
  <div class="container">
    <a href="<?= BASE_URL ?>" class="navbar-brand"><div class="logo-icon"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div><div class="logo-text"><strong>ATIZ PROM</strong><small>Home of All Tech Solutions</small></div></a>
    <ul class="nav-menu" id="navMenu">
      <li><a href="<?= BASE_URL ?>">Home</a></li>
      <li><a href="<?= BASE_URL ?>/customer/services.php">Services</a></li>
      <li><a href="<?= BASE_URL ?>/customer/portfolio.php">Portfolio</a></li>
      <li><a href="<?= BASE_URL ?>/customer/courses.php">Courses</a></li>
      <li class="nav-divider"></li>
      <li><a href="<?= BASE_URL ?>/customer/login.php" class="btn-nav-login"><i class="fas fa-user"></i> Login</a></li>
      <li><a href="<?= BASE_URL ?>/customer/register.php" class="btn-nav-register">Get Started</a></li>
    </ul>
  </div>
</nav>
<div style="background:#fff"><main><div class="container" style="padding:40px 20px">
<?php endif; ?>

  <?php if ($service): ?>
  <!-- SINGLE SERVICE -->
  <a href="<?= BASE_URL ?>/customer/services.php" style="font-size:0.85rem;color:var(--text-muted)"><i class="fas fa-arrow-left"></i> Back to Services</a>
  <div style="display:grid;grid-template-columns:2fr 1fr;gap:40px;margin-top:20px;align-items:start">
    <div>
      <div class="section-tag mb-2"><?= htmlspecialchars($service['cat_name']) ?></div>
      <h1 style="font-size:2rem;margin-bottom:16px"><?= htmlspecialchars($service['name']) ?></h1>
      <p style="font-size:1.05rem;color:var(--text-muted);line-height:1.8"><?= nl2br(htmlspecialchars($service['description'])) ?></p>
      <?php if ($service['features']): ?>
      <div class="card mt-3"><div class="card-header"><h4>What's Included</h4></div><div class="card-body"><p><?= nl2br(htmlspecialchars($service['features'])) ?></p></div></div>
      <?php endif; ?>
    </div>
    <div class="card" style="position:sticky;top:100px">
      <div style="background:linear-gradient(135deg,var(--blue),var(--blue-dark));padding:24px;text-align:center">
        <div style="font-size:1.6rem;font-weight:900;color:#fff"><?= $service['price_from']?formatCurrency($service['price_from']):'Custom Quote' ?></div>
        <small style="color:rgba(255,255,255,0.7)"><?= $service['price_label'] ?? 'Starting from' ?><?= $service['duration']?' · '.$service['duration']:'' ?></small>
      </div>
      <div class="card-body">
        <a href="<?= BASE_URL ?>/customer/booking.php?service_id=<?= $service['id'] ?>" class="btn btn-primary btn-block btn-lg mb-2"><i class="fas fa-calendar-check"></i> Book This Service</a>
        <a href="<?= BASE_URL ?>/customer/quotation.php" class="btn btn-outline-primary btn-block"><i class="fas fa-file-invoice"></i> Request Custom Quote</a>
      </div>
    </div>
  </div>
  <?php if (!empty($related)): ?>
  <h3 class="mt-4 mb-3">Related Services</h3>
  <div class="services-grid">
    <?php foreach ($related as $r): ?>
    <div class="service-card">
      <div class="service-icon"><i class="fas <?= $service['icon'] ?>"></i></div>
      <h3><?= htmlspecialchars($r['name']) ?></h3>
      <p><?= htmlspecialchars(substr($r['description'],0,80)) ?>...</p>
      <a href="?id=<?= $r['id'] ?>" class="btn btn-sm btn-service">Learn More <i class="fas fa-arrow-right"></i></a>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php else: ?>
  <!-- SERVICES LIST -->
  <div class="section-header"><div class="section-tag">What We Offer</div><h2>Our <span class="text-primary">Services</span></h2><p>Complete creative and technology solutions for every need</p></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-bottom:30px">
    <a href="?" class="btn btn-sm <?= !$catId?'btn-primary':'btn-outline-primary' ?>">All</a>
    <?php foreach ($categories as $c): ?>
    <a href="?cat=<?= $c['id'] ?>" class="btn btn-sm <?= $catId==$c['id']?'btn-primary':'btn-outline-primary' ?>"><i class="fas <?= $c['icon'] ?>"></i> <?= htmlspecialchars($c['name']) ?></a>
    <?php endforeach; ?>
  </div>
  <div class="services-grid">
    <?php foreach ($services as $s): ?>
    <div class="service-card">
      <div class="service-icon"><i class="fas <?= htmlspecialchars($s['icon']) ?>"></i></div>
      <div class="service-cat"><?= htmlspecialchars($s['cat_name']) ?></div>
      <h3><?= htmlspecialchars($s['name']) ?></h3>
      <p><?= htmlspecialchars(substr($s['description'],0,90)) ?>...</p>
      <?php if ($s['price_from']): ?><div class="service-price"><?= $s['price_label'] ?> <?= formatCurrency($s['price_from']) ?></div><?php endif; ?>
      <a href="?id=<?= $s['id'] ?>" class="btn btn-sm btn-service">Learn More <i class="fas fa-arrow-right"></i></a>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

<?php if ($isLoggedIn && $user && $user['role_slug']==='customer'): ?>
  </div></main>
</div>
<?php else: ?>
</div></main></div>
<?php include BASE_PATH . '/includes/footer_public.php'; ?>
<?php endif; ?>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
</body>
</html>
