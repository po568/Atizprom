<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','inventory_officer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$error = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $productId = $_POST['product_id'] ?: null;
        $itemName = trim($_POST['item_name']);
        // If a catalogue product was selected, use its name for consistency
        if ($productId) {
            $p = $db->fetchOne("SELECT name FROM products WHERE id=?", [$productId]);
            if ($p) $itemName = $p['name'];
        }
        if (!$itemName) {
            $error = 'Please enter an item name or select a product from the catalogue.';
        } else {
            $qty = (int)$_POST['quantity'];
            $movementType = $_POST['movement_type'];

            $db->insert(
                "INSERT INTO inventory_records (product_id, item_name, movement_type, quantity, unit_cost, supplier, reference, notes, recorded_by, created_at) VALUES (?,?,?,?,?,?,?,?,?,NOW())",
                [$productId, $itemName, $movementType, $qty, $_POST['unit_cost']?:null, trim($_POST['supplier']??''), trim($_POST['reference']??''), trim($_POST['notes']??''), $user['id']]
            );

            // Keep the catalogue product's quantity_in_stock in sync if this record is linked to one
            if ($productId) {
                $delta = in_array($movementType, ['stock_in','returned']) ? $qty : -$qty;
                $db->execute("UPDATE products SET quantity_in_stock = GREATEST(0, quantity_in_stock + ?) WHERE id=?", [$delta, $productId]);
                // Auto-adjust stock_status based on the new quantity
                $updated = $db->fetchOne("SELECT quantity_in_stock FROM products WHERE id=?", [$productId]);
                if ($updated) {
                    $newStatus = $updated['quantity_in_stock'] <= 0 ? 'out_of_stock' : ($updated['quantity_in_stock'] <= 5 ? 'limited' : 'in_stock');
                    $db->execute("UPDATE products SET stock_status=? WHERE id=?", [$newStatus, $productId]);
                }
            }

            $auth->logAudit($user['id'], 'INVENTORY_RECORD_ADDED', 'inventory_records', 0);
            redirect(BASE_URL.'/admin/products/records.php?added=1');
        }
    }
}

$products = $db->fetchAll("SELECT id, name, quantity_in_stock FROM products ORDER BY name");
$records = $db->fetchAll(
    "SELECT ir.*, CONCAT(u.first_name,' ',u.last_name) as recorded_by_name
     FROM inventory_records ir LEFT JOIN users u ON ir.recorded_by=u.id
     ORDER BY ir.created_at DESC LIMIT 100"
);
$movementLabels = ['stock_in'=>'Stock In','stock_out'=>'Stock Out','adjustment'=>'Adjustment','damaged'=>'Damaged/Written Off','returned'=>'Returned'];
$movementColors = ['stock_in'=>'success','stock_out'=>'warning','adjustment'=>'info','damaged'=>'danger','returned'=>'secondary'];
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Inventory Records – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Inventory Records</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/products/">Products</a> <span class="sep">/</span> Records</div></div>
    </div>
  </div>
  <div class="content-body">
    <?php if (isset($_GET['added'])): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> Inventory record added successfully!</div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <div class="card mb-3">
      <div class="card-header"><h4><i class="fas fa-plus-circle text-primary"></i> Add Inventory Record</h4></div>
      <form method="POST">
        <div class="card-body">
          <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
          <div class="form-row">
            <div class="form-group">
              <label>Catalogue Product (optional)</label>
              <select name="product_id" id="productSelect" class="form-control" onchange="document.getElementById('itemNameInput').value = this.value ? this.options[this.selectedIndex].dataset.name : '';">
                <option value="">Type a custom item name below</option>
                <?php foreach ($products as $p): ?>
                <option value="<?= $p['id'] ?>" data-name="<?= htmlspecialchars($p['name']) ?>"><?= htmlspecialchars($p['name']) ?> (currently <?= (int)$p['quantity_in_stock'] ?> in stock)</option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Item Name (if not in catalogue)</label>
              <input type="text" name="item_name" id="itemNameInput" class="form-control" placeholder="e.g. Office supplies not yet in catalogue">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Movement Type *</label>
              <select name="movement_type" class="form-control" required>
                <option value="stock_in">Stock In (received shipment)</option>
                <option value="stock_out">Stock Out (sold / issued)</option>
                <option value="adjustment">Adjustment (manual correction)</option>
                <option value="damaged">Damaged / Written Off</option>
                <option value="returned">Returned (back to stock)</option>
              </select>
            </div>
            <div class="form-group">
              <label>Quantity *</label>
              <input type="number" name="quantity" class="form-control" required min="1" placeholder="e.g. 20">
            </div>
            <div class="form-group">
              <label>Unit Cost (TZS, optional)</label>
              <input type="number" name="unit_cost" class="form-control" min="0" step="100" placeholder="Cost per unit">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Supplier (optional)</label>
              <input type="text" name="supplier" class="form-control" placeholder="e.g. Kagera Stationery Suppliers">
            </div>
            <div class="form-group">
              <label>Reference / Receipt #</label>
              <input type="text" name="reference" class="form-control" placeholder="Invoice or delivery note number">
            </div>
          </div>
          <div class="form-group">
            <label>Notes</label>
            <textarea name="notes" class="form-control" rows="2" placeholder="Any additional details about this record"></textarea>
          </div>
        </div>
        <div class="card-footer text-right">
          <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Add Record</button>
        </div>
      </form>
    </div>

    <div class="card">
      <div class="card-header"><h4>Recent Inventory Records</h4></div>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Date</th><th>Item</th><th>Type</th><th>Qty</th><th>Unit Cost</th><th>Supplier</th><th>Reference</th><th>Recorded By</th></tr></thead>
          <tbody>
            <?php foreach ($records as $r): ?>
            <tr>
              <td><?= formatDate($r['created_at']) ?></td>
              <td><strong><?= htmlspecialchars($r['item_name']) ?></strong></td>
              <td><span class="badge badge-<?= $movementColors[$r['movement_type']] ?? 'secondary' ?>"><?= $movementLabels[$r['movement_type']] ?? $r['movement_type'] ?></span></td>
              <td><?= number_format($r['quantity']) ?></td>
              <td><?= $r['unit_cost'] ? formatCurrency($r['unit_cost']) : '-' ?></td>
              <td><?= htmlspecialchars($r['supplier'] ?: '-') ?></td>
              <td><?= htmlspecialchars($r['reference'] ?: '-') ?></td>
              <td><?= htmlspecialchars($r['recorded_by_name'] ?: '-') ?></td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($records)): ?>
            <tr><td colspan="8" class="text-center text-muted" style="padding:40px">No inventory records yet</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
