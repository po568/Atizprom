<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();

// Toggle active/inactive
if (isPost() && isset($_POST['toggle_active'])) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $uid = (int)$_POST['user_id'];
        if ($uid !== $user['id']) {
            $target = $db->fetchOne("SELECT is_active, role_id FROM users WHERE id=?", [$uid]);
            if ($target && $target['role_id'] != 1) { // never deactivate a super admin from here
                $db->execute("UPDATE users SET is_active=? WHERE id=?", [$target['is_active']?0:1, $uid]);
                $auth->logAudit($user['id'], 'STAFF_STATUS_TOGGLED', 'users', $uid);
            }
        }
        redirect(BASE_URL.'/admin/users/?toggled=1');
    }
}

$roleFilter = $_GET['role'] ?? '';
$where = ['role_id != 8']; $params = []; $types = ''; // staff only, customers managed separately
if ($roleFilter) { $where[] = 'role_id=?'; $params[] = (int)$roleFilter; $types .= 'i'; }
$staff = $db->fetchAll("SELECT u.*, r.name as role_name FROM users u JOIN roles r ON u.role_id=r.id WHERE ".implode(' AND ',$where)." ORDER BY u.role_id, u.first_name", $params, $types);
$roles = $db->fetchAll("SELECT * FROM roles WHERE id != 8 ORDER BY id");
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Users & Roles – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Users & Roles</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Users</div></div>
    </div>
    <div class="header-actions">
      <a href="<?= BASE_URL ?>/admin/users/create.php" class="btn btn-primary btn-sm"><i class="fas fa-user-plus"></i> Add Staff Member</a>
    </div>
  </div>
  <div class="content-body">
    <?php if (isset($_GET['created'])): ?><div class="alert alert-success mb-3">Staff account created successfully!</div><?php endif; ?>
    <?php if (isset($_GET['toggled'])): ?><div class="alert alert-success mb-3">Account status updated.</div><?php endif; ?>

    <div class="card">
      <div class="card-body">
        <div class="dt-filters mb-3">
          <a href="?" class="btn btn-sm <?= !$roleFilter?'btn-primary':'btn-outline-primary' ?>">All Staff</a>
          <?php foreach ($roles as $r): ?>
          <a href="?role=<?= $r['id'] ?>" class="btn btn-sm <?= $roleFilter==$r['id']?'btn-primary':'btn-outline-primary' ?>"><?= htmlspecialchars($r['name']) ?></a>
          <?php endforeach; ?>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($staff as $s): ?>
              <tr>
                <td><div class="d-flex align-items-center gap-2"><div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--blue),var(--yellow));color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:0.8rem"><?= strtoupper(substr($s['first_name'],0,1)) ?></div><strong><?= htmlspecialchars($s['first_name'].' '.$s['last_name']) ?></strong></div></td>
                <td><?= htmlspecialchars($s['email']) ?></td>
                <td><span class="badge badge-primary"><?= htmlspecialchars($s['role_name']) ?></span></td>
                <td><?= $s['is_active'] ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>' ?></td>
                <td><?= formatDate($s['created_at']) ?></td>
                <td>
                  <?php if ($s['id'] !== $user['id'] && $s['role_id'] != 1): ?>
                  <form method="POST" style="display:inline" onsubmit="return confirm('<?= $s['is_active']?'Deactivate':'Reactivate' ?> this account?')">
                    <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
                    <input type="hidden" name="toggle_active" value="1">
                    <input type="hidden" name="user_id" value="<?= $s['id'] ?>">
                    <button type="submit" class="btn btn-sm <?= $s['is_active']?'btn-danger':'btn-success' ?>"><?= $s['is_active']?'Deactivate':'Activate' ?></button>
                  </form>
                  <?php else: ?>
                  <small class="text-muted">—</small>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($staff)): ?>
              <tr><td colspan="6" class="text-center text-muted" style="padding:40px">No staff members found</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
