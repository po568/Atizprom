<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');
$pageName = basename($_SERVER['PHP_SELF'], '.php');
$titles = ['my-courses'=>'My Courses','invoices'=>'Invoices','contracts'=>'Contracts','chat'=>'Live Chat','notifications'=>'Notifications'];
$icons = ['my-courses'=>'fa-graduation-cap','invoices'=>'fa-receipt','contracts'=>'fa-file-signature','chat'=>'fa-comments','notifications'=>'fa-bell'];
$title = $titles[$pageName] ?? 'Page';
$icon = $icons[$pageName] ?? 'fa-circle';
$db = Database::getInstance();
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $title ?> – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include __DIR__ . '/includes/header.php'; ?>
<div class="customer-layout">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content">
      <div class="customer-page-header">
        <div class="cph-left">
          <div class="cph-icon"><i class="fas <?= $icon ?>"></i></div>
          <div><h2><?= $title ?></h2><div class="cph-subtitle">
      <?php if ($pageName==='notifications'):
        $notifs = $db->fetchAll("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50", [$user['id']]);
        $db->execute("UPDATE notifications SET is_read=1 WHERE user_id=?", [$user['id']]);
        echo "All your notifications";
      else: echo "This section is available in your portal"; endif; ?>
      </div></div>
        </div>
      </div>

      <?php if ($pageName==='notifications'): ?>
      <div class="card">
        <div class="card-body" style="padding:0">
          <?php if (empty($notifs)): ?>
          <p class="text-center text-muted" style="padding:50px"><i class="fas fa-bell-slash" style="font-size:2.5rem;display:block;margin-bottom:14px;opacity:0.3"></i>No notifications yet</p>
          <?php else: foreach ($notifs as $n): ?>
          <div style="padding:16px 20px;border-bottom:1px solid var(--border);display:flex;gap:14px">
            <div style="width:38px;height:38px;border-radius:10px;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center;flex-shrink:0"><i class="fas fa-bell"></i></div>
            <div>
              <div style="font-weight:600"><?= htmlspecialchars($n['title']) ?></div>
              <div style="font-size:0.88rem;color:var(--text-muted)"><?= htmlspecialchars($n['message']) ?></div>
              <small class="text-muted"><?= timeAgo($n['created_at']) ?></small>
            </div>
          </div>
          <?php endforeach; endif; ?>
        </div>
      </div>
      <?php elseif ($pageName==='chat'): ?>
      <div class="card">
        <div class="card-body" style="text-align:center;padding:60px">
          <i class="fas fa-comments" style="font-size:3rem;color:var(--blue);display:block;margin-bottom:16px"></i>
          <h4>Live Chat Support</h4>
          <p class="text-muted">Our support team typically responds within minutes during business hours (Mon–Sat, 8AM–6PM EAT).</p>
          <a href="<?= BASE_URL ?>/customer/tickets/" class="btn btn-primary">Open a Support Ticket Instead</a>
        </div>
      </div>
      <?php elseif ($pageName==='invoices'): ?>
      <?php $invoices = $db->fetchAll("SELECT * FROM invoices WHERE customer_id=? ORDER BY created_at DESC", [$user['id']]); ?>
      <div class="card">
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Invoice #</th><th>Total</th><th>Paid</th><th>Balance</th><th>Due Date</th><th>Status</th></tr></thead>
            <tbody>
              <?php foreach ($invoices as $inv): ?>
              <tr><td><?= $inv['invoice_number'] ?></td><td><?= formatCurrency($inv['total']) ?></td><td><?= formatCurrency($inv['amount_paid']) ?></td><td><?= formatCurrency($inv['balance']) ?></td><td><?= formatDate($inv['due_date']) ?></td><td><?= getStatusBadge($inv['status']) ?></td></tr>
              <?php endforeach; ?>
              <?php if (empty($invoices)): ?><tr><td colspan="6" class="text-center text-muted" style="padding:40px">No invoices yet</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php elseif ($pageName==='contracts'): ?>
      <?php $contracts = $db->fetchAll("SELECT * FROM contracts WHERE customer_id=? ORDER BY created_at DESC", [$user['id']]); ?>
      <div class="card">
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Contract #</th><th>Title</th><th>Value</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              <?php foreach ($contracts as $c): ?>
              <tr><td><?= $c['contract_number'] ?></td><td><?= htmlspecialchars($c['title']) ?></td><td><?= formatCurrency($c['value']) ?></td><td><?= getStatusBadge($c['status']) ?></td><td><a href="#" class="btn btn-sm btn-outline-primary">View</a></td></tr>
              <?php endforeach; ?>
              <?php if (empty($contracts)): ?><tr><td colspan="5" class="text-center text-muted" style="padding:40px">No contracts yet</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php else: ?>
      <?php $myCourses = $db->fetchAll("SELECT ce.*, c.title, c.category, c.thumbnail FROM course_enrollments ce JOIN courses c ON ce.course_id=c.id WHERE ce.student_id=? ORDER BY ce.enrolled_at DESC", [$user['id']]); ?>
      <?php if (empty($myCourses)): ?>
      <div class="card"><div class="card-body text-center" style="padding:60px"><i class="fas fa-graduation-cap" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i><h4>No course enrollments yet</h4><a href="<?= BASE_URL ?>/customer/courses.php" class="btn btn-primary mt-2">Browse Courses</a></div></div>
      <?php else: ?>
      <div style="display:grid;gap:16px">
        <?php foreach ($myCourses as $mc): ?>
        <div class="course-progress-card">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <h4><?= htmlspecialchars($mc['title']) ?></h4>
            <?= getStatusBadge($mc['status']) ?>
          </div>
          <div class="progress"><div class="progress-bar" style="width:<?= $mc['progress'] ?>%"></div></div>
          <small class="text-muted"><?= $mc['progress'] ?>% complete · Enrollment #<?= $mc['enrollment_number'] ?></small>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
      <?php endif; ?>
    </div>
  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
</body>
</html>
