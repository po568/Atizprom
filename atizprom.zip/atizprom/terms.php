<?php
define('BASE_PATH', __DIR__);
require_once __DIR__ . '/includes/bootstrap.php';
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Terms of Service – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<nav class="navbar"><div class="container">
  <a href="<?= BASE_URL ?>" class="navbar-brand"><div class="logo-icon"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div><div class="logo-text"><strong>ATIZ PROM</strong></div></a>
  <ul class="nav-menu"><li><a href="<?= BASE_URL ?>">Home</a></li></ul>
</div></nav>
<div style="background:#fff"><main><div class="container" style="padding:50px 20px;max-width:800px">
<h1>Terms of Service</h1>
<p class="text-muted">Last updated: 2026</p>

<h3 class="mt-4">1. Acceptance of Terms</h3>
<p>By accessing or using the Atiz Prom website and customer portal, you agree to be bound by these Terms of Service.</p>

<h3 class="mt-4">2. Services</h3>
<p>Atiz Prom provides technology services, photography, videography, film production, graphics design, events coverage, and computer training. Bookings and quotations submitted through the portal are requests; confirmation of service and final pricing is provided by Atiz Prom staff.</p>

<h3 class="mt-4">3. Product Catalog</h3>
<p>Products listed in our catalog are for informational and inquiry purposes only. No online purchase or payment is processed through this website; customers may request a quotation for any listed product.</p>

<h3 class="mt-4">4. User Accounts</h3>
<p>You are responsible for maintaining the confidentiality of your account credentials and for all activity under your account.</p>

<h3 class="mt-4">5. Payments</h3>
<p>Payments are arranged directly with Atiz Prom through accepted methods including Cash, M-Pesa, Airtel Money, Tigo Pesa, HaloPesa, or Bank Transfer.</p>

<h3 class="mt-4">6. Cancellations</h3>
<p>Booking cancellations should be communicated as early as possible. Please contact our support team to cancel or reschedule any confirmed booking.</p>

<h3 class="mt-4">7. Intellectual Property</h3>
<p>All content produced by Atiz Prom for clients remains subject to the terms agreed in individual service contracts.</p>

<h3 class="mt-4">8. Contact</h3>
<p>For questions about these terms, contact us at atizpromltd@gmail.com.</p>
</div></main></div>
<?php include __DIR__ . '/includes/footer_public.php'; ?>
</body>
</html>
