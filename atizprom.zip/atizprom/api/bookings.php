<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';

header('Content-Type: application/json');
$auth = new Auth();
$auth->requireLogin();

if (!$auth->isAdmin()) jsonResponse(['success'=>false,'message'=>'Unauthorized.'], 403);

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if (!$auth->validateCSRF($input['csrf_token'] ?? '')) {
    jsonResponse(['success'=>false,'message'=>'Invalid security token.']);
}

$db = Database::getInstance();
$action = $input['action'] ?? '';

if ($action === 'update_status') {
    $id = (int)($input['id'] ?? 0);
    $status = $input['status'] ?? '';
    $valid = ['pending','confirmed','in_progress','completed','cancelled'];
    if (!in_array($status, $valid) || !$id) {
        jsonResponse(['success'=>false,'message'=>'Invalid status or booking ID.']);
    }

    $old = $db->fetchOne("SELECT * FROM bookings WHERE id=?", [$id]);
    if (!$old) jsonResponse(['success'=>false,'message'=>'Booking not found.']);

    $db->execute("UPDATE bookings SET status=? WHERE id=?", [$status, $id]);
    $auth->logAudit($_SESSION['user_id'], 'BOOKING_STATUS_UPDATE', 'bookings', $id, ['status'=>$old['status']], ['status'=>$status]);

    if ($status === 'confirmed' && $old['status'] !== 'confirmed') {
        ensureContractExists($auth, 'booking', $id);
    }

    // Notify customer
    $db->execute("INSERT INTO notifications (user_id, title, message, type, link) VALUES (?,?,?,?,?)",
        [$old['customer_id'], 'Booking Status Updated', "Your booking #{$old['booking_number']} status changed to " . ucfirst(str_replace('_',' ',$status)), 'booking', BASE_URL.'/customer/bookings/view.php?id='.$id]);

    jsonResponse(['success'=>true,'message'=>'Booking status updated successfully.']);
}

jsonResponse(['success'=>false,'message'=>'Unknown action.']);
