<?php
$unread = getNotificationCount($user['id'] ?? 0);
?>
<header class="customer-header">
  <div class="container">
    <a href="<?= BASE_URL ?>/customer/" class="navbar-brand" style="text-decoration:none">
      <div class="logo-icon"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div>
      <div class="logo-text">
        <strong>ATIZ PROM</strong>
        <small>Customer Portal</small>
      </div>
    </a>
    <div class="customer-header-actions">
      <a href="<?= BASE_URL ?>/customer/notifications.php" class="header-icon-btn" title="Notifications" style="position:relative;width:40px;height:40px;border-radius:10px;background:var(--gray-light);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;color:var(--text)">
        <i class="fas fa-bell"></i>
        <?php if ($unread > 0): ?><span class="notif-badge"><?= $unread ?></span><?php endif; ?>
      </a>
      <a href="<?= BASE_URL ?>/customer/chat.php" class="header-icon-btn" title="Live Chat" style="width:40px;height:40px;border-radius:10px;background:var(--gray-light);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;color:var(--text)">
        <i class="fas fa-comments"></i>
      </a>
      <div class="dropdown">
        <div class="user-avatar-btn" style="cursor:pointer" onclick="document.getElementById('custUserDrop').classList.toggle('open')">
          <?php if (!empty($user['profile_picture'])): ?>
            <img src="<?= UPLOAD_URL . $user['profile_picture'] ?>" alt="Avatar" style="width:36px;height:36px;border-radius:50%;object-fit:cover">
          <?php else: ?>
            <div class="user-avatar"><?= strtoupper(substr($user['first_name'],0,1)) ?></div>
          <?php endif; ?>
          <div class="user-info-text">
            <strong><?= htmlspecialchars($user['first_name']) ?></strong>
            <small>Customer</small>
          </div>
          <i class="fas fa-chevron-down" style="font-size:0.75rem;color:var(--text-muted)"></i>
        </div>
        <div class="dropdown-menu" id="custUserDrop" style="right:0">
          <a class="dropdown-item" href="<?= BASE_URL ?>/customer/profile.php"><i class="fas fa-user"></i> My Profile</a>
          <a class="dropdown-item" href="<?= BASE_URL ?>/customer/bookings/"><i class="fas fa-calendar"></i> My Bookings</a>
          <a class="dropdown-item" href="<?= BASE_URL ?>/customer/tickets/"><i class="fas fa-headset"></i> Support</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="<?= BASE_URL ?>"><i class="fas fa-home"></i> Public Website</a>
          <a class="dropdown-item danger" href="<?= BASE_URL ?>/customer/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </div>
      <!-- Mobile sidebar toggle -->
      <button class="nav-toggle" id="custSidebarToggle" style="margin-left:6px"><i class="fas fa-bars"></i></button>
    </div>
  </div>
</header>
<script>
document.getElementById('custSidebarToggle')?.addEventListener('click', () => {
  document.getElementById('custSidebar')?.classList.toggle('open');
});
</script>
