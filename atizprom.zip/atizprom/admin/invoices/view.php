<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','finance_officer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$id = (int)($_GET['id'] ?? 0);

if (isPost()) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $postId = (int)($_POST['invoice_id'] ?? $id);
        if (isset($_POST['record_payment'])) {
            $amount = (float)$_POST['payment_amount'];
            $inv = $db->fetchOne("SELECT * FROM invoices WHERE id=?", [$postId]);
            // Overpayment is allowed (e.g. a customer pays extra as a deposit toward future
            // work), but the form requires explicit confirmation before submitting one --
            // see the JS confirm() on the payment form below.
            if ($inv && $amount > 0) {
                // Record the payment
                $db->insert(
                    "INSERT INTO payments (invoice_id, customer_id, amount, payment_method, payment_date, transaction_ref, notes, confirmed_by, status, created_at)
                     VALUES (?,?,?,?,?,?,?,?,?,NOW())",
                    [$postId, $inv['customer_id'], $amount, $_POST['payment_method'], $_POST['payment_date'] ?: date('Y-m-d'), trim($_POST['reference']??''), trim($_POST['payment_notes']??''), $user['id'], 'confirmed']
                );
                // Update invoice paid/balance (balance can go negative to represent credit/overpayment)
                $newPaid    = $inv['amount_paid'] + $amount;
                $newBalance = $inv['total'] - $newPaid;
                $newStatus  = $newBalance <= 0 ? 'paid' : ($newPaid > 0 ? 'partial' : 'sent');
                $db->execute("UPDATE invoices SET amount_paid=?, balance=?, status=? WHERE id=?", [$newPaid, $newBalance, $newStatus, $postId]);
                // If linked to an enrollment, update payment_status too
                if ($inv['enrollment_id']) {
                    $newPayStatus = $newBalance <= 0 ? 'paid' : 'partial';
                    $db->execute("UPDATE course_enrollments SET amount_paid=?, payment_status=? WHERE id=?", [$newPaid, $newPayStatus, $inv['enrollment_id']]);
                }
                $auth->logAudit($user['id'], 'PAYMENT_RECORDED', 'invoices', $postId);
                $balanceMsg = $newBalance < 0 ? ('Credit balance: ' . formatCurrency(abs($newBalance))) : ('Balance: ' . formatCurrency($newBalance));
                $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                    [$inv['customer_id'], 'Payment Received', formatCurrency($amount)." payment recorded on Invoice #{$inv['invoice_number']}. {$balanceMsg}", 'invoice', BASE_URL.'/customer/invoices.php?id='.$postId]);
                redirect(BASE_URL.'/admin/invoices/view.php?id='.$postId.'&paid=1');
            } else {
                redirect(BASE_URL.'/admin/invoices/view.php?id='.$postId.'&error=overpay');
            }
        } elseif (isset($_POST['resend_invoice'])) {
            $inv = $db->fetchOne("SELECT * FROM invoices WHERE id=?", [$postId]);
            if ($inv && $inv['status'] === 'draft') {
                $db->execute("UPDATE invoices SET status='sent' WHERE id=?", [$postId]);
            }
            $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                [$inv['customer_id'], 'Invoice Reminder', "Reminder: Invoice #{$inv['invoice_number']} for ".formatCurrency($inv['total'])." is due on ".formatDate($inv['due_date']), 'invoice', BASE_URL.'/customer/invoices.php?id='.$postId]);
            redirect(BASE_URL.'/admin/invoices/view.php?id='.$postId.'&sent=1');
        }
    }
}

$invoice = $db->fetchOne(
    "SELECT i.*, CONCAT(u.first_name,' ',u.last_name) as customer_name, u.email, u.phone
     FROM invoices i JOIN users u ON i.customer_id=u.id WHERE i.id=?",
    [$id]
);
if (!$invoice) redirect(BASE_URL.'/admin/invoices/');
$items = $invoice['items'] ? json_decode($invoice['items'], true) : [];
$payments = $db->fetchAll("SELECT * FROM payments WHERE invoice_id=? ORDER BY payment_date DESC", [$id]);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Invoice <?= $invoice['invoice_number'] ?> – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Invoice <?= $invoice['invoice_number'] ?></div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/invoices/">Invoices</a> <span class="sep">/</span> View</div></div>
    </div>
    <div class="header-actions">
      <button onclick="window.print()" class="btn btn-sm" style="border:1px solid var(--border)"><i class="fas fa-print"></i> Print</button>
      <form method="POST" style="display:inline" onsubmit="return confirm('Send reminder to customer?')">
        <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
        <input type="hidden" name="resend_invoice" value="1">
        <input type="hidden" name="invoice_id" value="<?= $invoice['id'] ?>">
        <button type="submit" class="btn btn-sm btn-outline-primary"><i class="fas fa-paper-plane"></i> Send Reminder</button>
      </form>
    </div>
  </div>
  <div class="content-body" style="max-width:860px">
    <?php if (isset($_GET['paid'])): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> Payment recorded!</div><?php endif; ?>
    <?php if (isset($_GET['sent'])): ?><div class="alert alert-success mb-3"><i class="fas fa-paper-plane"></i> Invoice reminder sent to customer.</div><?php endif; ?>
    <?php if (($_GET['error'] ?? '') === 'overpay'): ?><div class="alert alert-danger mb-3"><i class="fas fa-exclamation-circle"></i> That amount exceeds the remaining balance on this invoice. Please enter an amount up to the outstanding balance.</div><?php endif; ?>

    <!-- Invoice print area -->
    <div class="card mb-3" id="printArea">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-start mb-4">
          <div>
            <img src="<?= BASE_URL ?>/assets/images/logo.webp" style="height:50px;border-radius:8px" alt="Atiz Prom Logo">
            <div style="margin-top:8px">
              <strong>ATIZ PROM</strong><br>
              <small class="text-muted"><?= htmlspecialchars(getSetting('site_address','Kyerwa, Kagera, Tanzania')) ?></small><br>
              <small class="text-muted"><?= htmlspecialchars(getSetting('site_email','atizpromltd@gmail.com')) ?></small><br>
              <small class="text-muted"><?= htmlspecialchars(getSetting('site_phone','+255626296753')) ?></small>
            </div>
          </div>
          <div style="text-align:right">
            <h2 style="color:var(--blue);margin-bottom:4px">INVOICE</h2>
            <strong>#<?= $invoice['invoice_number'] ?></strong><br>
            <small class="text-muted">Issued: <?= formatDate($invoice['created_at']) ?></small><br>
            <small class="text-muted">Due: <?= formatDate($invoice['due_date']) ?></small><br>
            <?= getStatusBadge($invoice['status']) ?>
          </div>
        </div>
        <div class="card mb-3" style="background:var(--gray-light)">
          <div class="card-body">
            <strong>Bill To:</strong><br>
            <?= htmlspecialchars($invoice['customer_name']) ?><br>
            <?= htmlspecialchars($invoice['email']) ?><br>
            <?= $invoice['phone'] ? htmlspecialchars($invoice['phone']) : '' ?>
          </div>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Description</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr></thead>
            <tbody>
              <?php foreach ($items as $item): ?>
              <tr>
                <td><?= htmlspecialchars($item['description'] ?? '') ?></td>
                <td><?= (int)($item['qty'] ?? 1) ?></td>
                <td><?= formatCurrency($item['unit_price'] ?? 0) ?></td>
                <td><?= formatCurrency(($item['qty']??1) * ($item['unit_price']??0)) ?></td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($items)): ?><tr><td colspan="4" class="text-muted text-center">No line items</td></tr><?php endif; ?>
            </tbody>
            <tfoot>
              <tr><td colspan="3" style="text-align:right"><strong>Subtotal</strong></td><td><?= formatCurrency($invoice['subtotal']) ?></td></tr>
              <?php if ($invoice['discount'] > 0): ?><tr><td colspan="3" style="text-align:right">Discount</td><td>-<?= formatCurrency($invoice['discount']) ?></td></tr><?php endif; ?>
              <tr><td colspan="3" style="text-align:right">Tax (<?= getSetting('tax_rate','18') ?>%)</td><td><?= formatCurrency($invoice['tax']) ?></td></tr>
              <tr style="font-size:1.1rem"><td colspan="3" style="text-align:right"><strong>Total</strong></td><td><strong><?= formatCurrency($invoice['total']) ?></strong></td></tr>
              <tr><td colspan="3" style="text-align:right;color:#155724">Amount Paid</td><td style="color:#155724"><?= formatCurrency($invoice['amount_paid']) ?></td></tr>
              <?php if ($invoice['balance'] < 0): ?>
              <tr><td colspan="3" style="text-align:right;color:#155724"><strong>Credit Balance</strong></td><td style="color:#155724"><strong><?= formatCurrency(abs($invoice['balance'])) ?> overpaid</strong></td></tr>
              <?php else: ?>
              <tr><td colspan="3" style="text-align:right;color:#721C24"><strong>Balance Due</strong></td><td style="color:#721C24"><strong><?= formatCurrency($invoice['balance']) ?></strong></td></tr>
              <?php endif; ?>
            </tfoot>
          </table>
        </div>
        <?php if ($invoice['notes']): ?><p style="font-size:0.85rem;color:var(--text-muted);margin-top:10px"><strong>Notes:</strong> <?= nl2br(htmlspecialchars($invoice['notes'])) ?></p><?php endif; ?>
        <p style="font-size:0.8rem;color:var(--text-muted);margin-top:16px;border-top:1px solid var(--border);padding-top:12px">Payment accepted via Cash, M-Pesa, Airtel Money, Tigo Pesa, HaloPesa, or Bank Transfer.</p>
      </div>
    </div>

    <!-- Payment history -->
    <?php if (!empty($payments)): ?>
    <div class="card mb-3">
      <div class="card-header"><h4>Payment History</h4></div>
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Reference</th></tr></thead>
          <tbody>
            <?php foreach ($payments as $p): ?>
            <tr><td><?= formatDate($p['payment_date']) ?></td><td style="color:#155724"><strong><?= formatCurrency($p['amount']) ?></strong></td><td><?= htmlspecialchars(ucfirst(str_replace('_',' ',$p['payment_method']))) ?></td><td><?= htmlspecialchars($p['transaction_ref'] ?: '-') ?></td></tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>

    <!-- Record payment -->
    <?php if ($invoice['status'] !== 'cancelled'): ?>
    <div class="card no-print">
      <div class="card-header"><h4>Record Payment</h4></div>
      <form method="POST" onsubmit="return confirmPaymentAmount(this)">
        <div class="card-body">
          <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
          <input type="hidden" name="record_payment" value="1">
          <input type="hidden" name="invoice_id" value="<?= $invoice['id'] ?>">
          <div class="form-row">
            <div class="form-group">
              <label>Amount (TZS) *</label>
              <input type="number" name="payment_amount" id="paymentAmountInput" class="form-control" required min="1" step="100" value="<?= $invoice['balance'] > 0 ? $invoice['balance'] : '' ?>" data-balance="<?= $invoice['balance'] ?>" placeholder="Enter amount">
              <div class="form-text">
                <?php if ($invoice['balance'] > 0): ?>
                Outstanding balance: <?= formatCurrency($invoice['balance']) ?>. You can record a partial amount, or more than the balance (e.g. a deposit toward future work) — you'll be asked to confirm if it exceeds the balance.
                <?php elseif ($invoice['balance'] < 0): ?>
                This invoice currently has a credit balance of <?= formatCurrency(abs($invoice['balance'])) ?>. You can still record an additional payment if needed.
                <?php else: ?>
                This invoice is fully paid. You can still record an additional payment (e.g. for a new charge) if needed.
                <?php endif; ?>
              </div>
            </div>
            <div class="form-group">
              <label>Payment Method *</label>
              <select name="payment_method" class="form-control">
                <option value="cash">Cash</option>
                <option value="mpesa">M-Pesa</option>
                <option value="airtel_money">Airtel Money</option>
                <option value="tigo_pesa">Tigo Pesa</option>
                <option value="halopesa">HaloPesa</option>
                <option value="bank_transfer">Bank Transfer</option>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group"><label>Payment Date *</label><input type="date" name="payment_date" class="form-control" value="<?= date('Y-m-d') ?>"></div>
            <div class="form-group"><label>Reference / Receipt #</label><input type="text" name="reference" class="form-control" placeholder="Transaction ID or receipt number"></div>
          </div>
          <div class="form-group"><label>Notes</label><textarea name="payment_notes" class="form-control" rows="2" placeholder="Any relevant notes for this payment"></textarea></div>
        </div>
        <div class="card-footer text-right"><button type="submit" class="btn btn-success"><i class="fas fa-check-circle"></i> Record Payment</button></div>
      </form>
    </div>
    <?php endif; ?>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
<script>
function confirmPaymentAmount(form) {
  const input = document.getElementById('paymentAmountInput');
  const balance = parseFloat(input.dataset.balance) || 0;
  const amount = parseFloat(input.value) || 0;
  if (amount > balance) {
    const over = (amount - balance).toLocaleString();
    return confirm('This amount is TZS ' + over + ' more than the outstanding balance. Record it anyway as an overpayment / credit?');
  }
  return true;
}
</script>
</body>
</html>
