<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$user = $auth->getCurrentUser();
$db = Database::getInstance();
$success=''; $error='';
if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) { $error='Invalid token.'; }
    elseif (isset($_POST['update_profile'])) {
        $pic = $user['profile_picture'];
        if (!empty($_FILES['profile_picture']['tmp_name'])) { $r = uploadFile($_FILES['profile_picture'],'profiles'); if ($r['success']) $pic=$r['path']; }
        $db->execute("UPDATE users SET first_name=?,last_name=?,phone=?,profile_picture=? WHERE id=?",[trim($_POST['first_name']),trim($_POST['last_name']),trim($_POST['phone']??''),$pic,$user['id']]);
        $success='Profile updated!'; $user = $auth->getCurrentUser();
    } elseif (isset($_POST['change_password'])) {
        if (!password_verify($_POST['current_password'],$user['password'])) $error='Current password incorrect.';
        elseif ($_POST['new_password']!==$_POST['confirm_password']) $error='Passwords do not match.';
        else { $db->execute("UPDATE users SET password=? WHERE id=?",[password_hash($_POST['new_password'],PASSWORD_BCRYPT,['cost'=>12]),$user['id']]); $success='Password updated!'; }
    }
}
?>
<!DOCTYPE html><html lang="en" <?= themeAttr() ?>><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Profile – Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"></head>
<body><div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include __DIR__.'/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
<div class="top-header"><div class="header-left"><button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button><div class="header-title">My Profile</div></div></div>
<div class="content-body" style="max-width:700px">
<?php if($success):?><div class="alert alert-success mb-3"><?=htmlspecialchars($success)?></div><?php endif;?>
<?php if($error):?><div class="alert alert-danger mb-3"><?=htmlspecialchars($error)?></div><?php endif;?>
<form method="POST" enctype="multipart/form-data">
<input type="hidden" name="csrf_token" value="<?=$auth->getCSRFToken()?>"><input type="hidden" name="update_profile" value="1">
<div class="card mb-3"><div class="card-header"><h4>Personal Information</h4></div><div class="card-body">
<div class="form-row"><div class="form-group"><label>First Name</label><input type="text" name="first_name" class="form-control" value="<?=htmlspecialchars($user['first_name'])?>"></div>
<div class="form-group"><label>Last Name</label><input type="text" name="last_name" class="form-control" value="<?=htmlspecialchars($user['last_name'])?>"></div></div>
<div class="form-group"><label>Email</label><input type="email" class="form-control" value="<?=htmlspecialchars($user['email'])?>" disabled></div>
<div class="form-group"><label>Phone</label><input type="tel" name="phone" class="form-control" value="<?=htmlspecialchars($user['phone']??'')?>"></div>
<div class="form-group"><label>Profile Picture</label><input type="file" name="profile_picture" class="form-control" accept="image/*"></div>
</div><div class="card-footer text-right"><button class="btn btn-primary">Save Changes</button></div></div>
</form>
<form method="POST">
<input type="hidden" name="csrf_token" value="<?=$auth->getCSRFToken()?>"><input type="hidden" name="change_password" value="1">
<div class="card"><div class="card-header"><h4>Change Password</h4></div><div class="card-body">
<div class="form-group"><label>Current Password</label><input type="password" name="current_password" class="form-control" required></div>
<div class="form-group"><label>New Password</label><input type="password" name="new_password" class="form-control" required></div>
<div class="form-group"><label>Confirm Password</label><input type="password" name="confirm_password" class="form-control" required></div>
</div><div class="card-footer text-right"><button class="btn btn-primary">Update Password</button></div></div>
</form>
</div></div></div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script><script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body></html>
