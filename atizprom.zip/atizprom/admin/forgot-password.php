<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$db = Database::getInstance();
$success = ''; $error = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
        $u = $db->fetchOne("SELECT id FROM users WHERE email=?", [$email]);
        // Always show success to prevent email enumeration
        if ($u) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 3600);
            $db->execute("UPDATE users SET reset_token=?, reset_token_expires=? WHERE id=?", [$token, $expires, $u['id']]);
            // In production: send email with reset link containing $token
            // mail($email, "Password Reset", "Reset link: " . BASE_URL . "/customer/reset-password.php?token=" . $token);
        }
        $success = 'If an account exists with that email, a password reset link has been sent.';
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>body{background:linear-gradient(135deg,var(--dark-2),var(--dark-3));min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.auth-box{background:#fff;border-radius:20px;max-width:440px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,0.4);overflow:hidden}
.auth-header{background:linear-gradient(135deg,var(--blue),var(--blue-dark));padding:28px;text-align:center}
.auth-header h2{color:#fff;margin-bottom:4px}.auth-header p{color:rgba(255,255,255,0.7);margin:0;font-size:0.85rem}
.auth-body{padding:32px}</style>
</head>
<body>
<div class="auth-box">
  <div class="auth-header">
    <i class="fas fa-key" style="font-size:2rem;color:#fff;margin-bottom:10px;display:block"></i>
    <h2>Forgot Password?</h2>
    <p>Enter your email to receive a reset link</p>
  </div>
  <div class="auth-body">
    <?php if ($success): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
    <a href="<?= BASE_URL ?>/admin/login.php" class="btn btn-primary btn-block mt-2">Back to Login</a>
    <?php else: ?>
    <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <div class="form-group">
        <label>Email Address *</label>
        <input type="email" name="email" class="form-control" required placeholder="your@email.com">
      </div>
      <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-paper-plane"></i> Send Reset Link</button>
    </form>
    <p class="text-center mt-3"><a href="<?= BASE_URL ?>/admin/login.php" style="font-size:0.85rem"><i class="fas fa-arrow-left"></i> Back to Login</a></p>
    <?php endif; ?>
  </div>
</div>
</body>
</html>
