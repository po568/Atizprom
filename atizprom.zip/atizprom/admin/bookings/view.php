<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','production_manager']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$id = (int)($_GET['id'] ?? 0);

if (isPost() && isset($_POST['update_status'])) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $postId = (int)($_POST['booking_id'] ?? $id);
        $old = $db->fetchOne("SELECT * FROM bookings WHERE id=?", [$postId]);
        $db->execute("UPDATE bookings SET status=?, total_amount=?, notes=? WHERE id=?", [$_POST['status'],$_POST['total_amount']?:null,$_POST['notes']?:null,$postId]);
        $auth->logAudit($user['id'],'BOOKING_UPDATE','bookings',$postId,['status'=>$old['status']],['status'=>$_POST['status']]);
        $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
            [$old['customer_id'],'Booking Updated',"Your booking #{$old['booking_number']} status is now ".ucfirst(str_replace('_',' ',$_POST['status'])),'booking',BASE_URL.'/customer/bookings/view.php?id='.$postId]);
        if ($_POST['status'] === 'confirmed' && $old['status'] !== 'confirmed') {
            ensureContractExists($auth, 'booking', $postId);
        }
        redirect(BASE_URL.'/admin/bookings/view.php?id='.$postId.'&updated=1');
    }
}

$booking = $db->fetchOne("SELECT b.*, s.name as service_name, sc.name as category, CONCAT(u.first_name,' ',u.last_name) as customer_name, u.email, u.phone FROM bookings b JOIN services s ON b.service_id=s.id JOIN service_categories sc ON s.category_id=sc.id JOIN users u ON b.customer_id=u.id WHERE b.id=?", [$id]);
if (!$booking) redirect(BASE_URL.'/admin/bookings/');
$attachments = $booking['file_attachments'] ? json_decode($booking['file_attachments'], true) : [];
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Booking <?= $booking['booking_number'] ?> – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Booking <?= $booking['booking_number'] ?></div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/bookings/">Bookings</a> <span class="sep">/</span> View</div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:900px">
    <?php if (isset($_GET['created'])): ?><div class="alert alert-success mb-3">Booking created successfully!</div><?php endif; ?>
    <?php if (isset($_GET['updated'])): ?><div class="alert alert-success mb-3">Booking updated successfully!</div><?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
      <div>
        <h3><?= htmlspecialchars($booking['service_name']) ?></h3>
        <p class="text-muted" style="margin:0"><?= htmlspecialchars($booking['category']) ?></p>
      </div>
      <?= getStatusBadge($booking['status']) ?>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
      <div class="card">
        <div class="card-header"><h4>Customer</h4></div>
        <div class="card-body">
          <p><strong><?= htmlspecialchars($booking['customer_name']) ?></strong></p>
          <p class="text-muted"><?= htmlspecialchars($booking['email']) ?><br><?= htmlspecialchars($booking['phone'] ?: '-') ?></p>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h4>Event Details</h4></div>
        <div class="card-body">
          <div class="d-flex justify-content-between"><span class="text-muted">Date</span><strong><?= $booking['event_date']?formatDate($booking['event_date']):'TBD' ?></strong></div>
          <div class="d-flex justify-content-between"><span class="text-muted">Time</span><strong><?= $booking['event_time']?date('H:i',strtotime($booking['event_time'])):'TBD' ?></strong></div>
          <div class="d-flex justify-content-between"><span class="text-muted">Venue</span><strong><?= htmlspecialchars($booking['venue'] ?: '-') ?></strong></div>
          <div class="d-flex justify-content-between"><span class="text-muted">Guests</span><strong><?= $booking['guests_count'] ?: '-' ?></strong></div>
        </div>
      </div>
    </div>

    <?php if ($booking['special_requirements']): ?>
    <div class="card mt-3"><div class="card-header"><h4>Special Requirements</h4></div><div class="card-body"><p><?= nl2br(htmlspecialchars($booking['special_requirements'])) ?></p></div></div>
    <?php endif; ?>

    <?php if (!empty($attachments)): ?>
    <div class="card mt-3"><div class="card-header"><h4>Attachments</h4></div><div class="card-body">
      <?php foreach ($attachments as $a): ?>
      <a href="<?= UPLOAD_URL . $a ?>" target="_blank" class="d-flex align-items-center gap-2" style="padding:8px 0;border-bottom:1px solid var(--border)"><i class="fas fa-paperclip"></i> <?= basename($a) ?></a>
      <?php endforeach; ?>
    </div></div>
    <?php endif; ?>

    <div class="card mt-3">
      <div class="card-header"><h4>Update Booking</h4></div>
      <form method="POST">
        <div class="card-body">
          <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
          <input type="hidden" name="update_status" value="1">
          <input type="hidden" name="booking_id" value="<?= $booking['id'] ?>">
          <div class="form-row">
            <div class="form-group">
              <label>Status</label>
              <select name="status" class="form-control">
                <?php foreach (['pending','confirmed','in_progress','completed','cancelled'] as $s): ?>
                <option value="<?= $s ?>" <?= $booking['status']===$s?'selected':'' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Total Amount (TZS)</label>
              <input type="number" name="total_amount" class="form-control" value="<?= $booking['total_amount'] ?>" min="0" step="1000">
            </div>
          </div>
          <div class="form-group">
            <label>Internal Notes</label>
            <textarea name="notes" class="form-control" rows="3"><?= htmlspecialchars($booking['notes'] ?? '') ?></textarea>
          </div>
        </div>
        <div class="card-footer text-right"><button class="btn btn-primary"><i class="fas fa-save"></i> Update Booking</button></div>
      </form>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
