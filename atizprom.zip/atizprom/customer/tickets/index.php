<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();
$success = ''; $error = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) { $error = 'Invalid token.'; }
    elseif (isset($_POST['ticket_id']) && isset($_POST['reply'])) {
        // Reply to ticket
        $db->execute("INSERT INTO ticket_replies (ticket_id,user_id,message) VALUES (?,?,?)", [$_POST['ticket_id'],$user['id'],trim($_POST['reply'])]);
        $db->execute("UPDATE tickets SET status='open',updated_at=NOW() WHERE id=? AND customer_id=?", [$_POST['ticket_id'],$user['id']]);
        $success = 'Reply sent.';
    } else {
        // New ticket
        $ticketNum = $auth->generateNumber('TK','tickets','ticket_number');
        $id = $db->insert("INSERT INTO tickets (ticket_number,customer_id,subject,message,category,priority) VALUES (?,?,?,?,?,?)",
            [$ticketNum,$user['id'],trim($_POST['subject']),trim($_POST['message']),$_POST['category']??'inquiry',$_POST['priority']??'normal']);
        if ($id) {
            $db->execute("INSERT INTO ticket_replies (ticket_id,user_id,message) VALUES (?,?,?)", [$id,$user['id'],trim($_POST['message'])]);
            $auth->logAudit($user['id'],'TICKET_CREATE','tickets',$id);
            $success = "Support ticket #{$ticketNum} submitted. We'll respond within 24 hours.";
        } else $error = 'Failed to submit ticket.';
    }
}

$viewId = (int)($_GET['view'] ?? 0);
if ($viewId) {
    $ticket = $db->fetchOne("SELECT * FROM tickets WHERE id=? AND customer_id=?", [$viewId,$user['id']]);
    if (!$ticket) redirect(BASE_URL.'/customer/tickets/');
    $replies = $db->fetchAll("SELECT tr.*, CONCAT(u.first_name,' ',u.last_name) as author, u.role_id FROM ticket_replies tr JOIN users u ON tr.user_id=u.id WHERE tr.ticket_id=? ORDER BY tr.created_at ASC", [$viewId]);
    // Mark as read (from customer side)
    $db->execute("UPDATE tickets SET status=CASE WHEN status='resolved' THEN 'resolved' ELSE status END WHERE id=?", [$viewId]);
} else {
    $ticket = null; $replies = [];
    $tickets = $db->fetchAll("SELECT * FROM tickets WHERE customer_id=? ORDER BY updated_at DESC", [$user['id']]);
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Support Tickets – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include BASE_PATH . '/customer/includes/header.php'; ?>
<div class="customer-layout">
  <?php include BASE_PATH . '/customer/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content">
      <?php if ($success): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
      <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>

      <?php if ($ticket): ?>
      <!-- TICKET THREAD VIEW -->
      <div style="max-width:760px">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <a href="<?= BASE_URL ?>/customer/tickets/" style="color:var(--text-muted);font-size:0.85rem"><i class="fas fa-arrow-left"></i> Back to Tickets</a>
          <?= getStatusBadge($ticket['status']) ?>
        </div>
        <div class="card mb-3">
          <div class="card-header">
            <div>
              <h4 style="margin-bottom:4px"><?= htmlspecialchars($ticket['subject']) ?></h4>
              <small class="text-muted">Ticket #<?= $ticket['ticket_number'] ?> · <?= ucfirst($ticket['category']) ?> · <?= ucfirst($ticket['priority']) ?> priority · <?= timeAgo($ticket['created_at']) ?></small>
            </div>
          </div>
          <div class="card-body">
            <div class="ticket-thread">
              <?php foreach ($replies as $r): ?>
              <div class="ticket-message <?= $r['role_id'] != 8 ? 'admin' : '' ?>">
                <div class="msg-avatar <?= $r['role_id'] == 8 ? 'customer' : 'staff' ?>">
                  <?= strtoupper(substr($r['author'],0,1)) ?>
                </div>
                <div>
                  <div style="font-size:0.78rem;font-weight:600;margin-bottom:4px;color:var(--text-muted)"><?= htmlspecialchars($r['author']) ?> · <?= timeAgo($r['created_at']) ?></div>
                  <div class="msg-bubble">
                    <p><?= nl2br(htmlspecialchars($r['message'])) ?></p>
                  </div>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
          <?php if ($ticket['status'] !== 'closed'): ?>
          <div class="card-footer">
            <form method="POST">
              <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
              <input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>">
              <div class="form-group">
                <textarea name="reply" class="form-control" rows="3" required placeholder="Type your reply..."></textarea>
              </div>
              <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send Reply</button>
              </div>
            </form>
          </div>
          <?php endif; ?>
        </div>
      </div>

      <?php else: ?>
      <!-- TICKETS LIST -->
      <div class="customer-page-header">
        <div class="cph-left">
          <div class="cph-icon"><i class="fas fa-headset"></i></div>
          <div><h2>Support Tickets</h2><div class="cph-subtitle">Get help from our support team</div></div>
        </div>
        <div class="cph-actions">
          <button onclick="AtizProm.openModal('newTicketModal')" class="btn btn-primary"><i class="fas fa-plus"></i> New Ticket</button>
        </div>
      </div>

      <?php if (empty($tickets)): ?>
      <div class="card"><div class="card-body text-center" style="padding:60px">
        <i class="fas fa-headset" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i>
        <h4>No support tickets yet</h4>
        <p class="text-muted">Need help? Submit a support ticket and we'll get back to you!</p>
        <button onclick="AtizProm.openModal('newTicketModal')" class="btn btn-primary"><i class="fas fa-plus"></i> Open First Ticket</button>
      </div></div>
      <?php else: ?>
      <div class="card">
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Ticket #</th><th>Subject</th><th>Category</th><th>Priority</th><th>Status</th><th>Last Update</th><th>Action</th></tr></thead>
            <tbody>
              <?php foreach ($tickets as $t): ?>
              <tr>
                <td><strong style="color:var(--blue)"><?= $t['ticket_number'] ?></strong></td>
                <td><?= htmlspecialchars($t['subject']) ?></td>
                <td><?= ucfirst($t['category']) ?></td>
                <td><?= ucfirst($t['priority']) ?></td>
                <td><?= getStatusBadge($t['status']) ?></td>
                <td><?= timeAgo($t['updated_at']) ?></td>
                <td><a href="?view=<?= $t['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-eye"></i> View</a></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endif; ?>
      <?php endif; ?>
    </div>
  </main>
</div>

<!-- New Ticket Modal -->
<div class="modal-overlay" id="newTicketModal">
  <div class="modal">
    <div class="modal-header">
      <h4><i class="fas fa-ticket-alt text-primary"></i> Open Support Ticket</h4>
      <button class="modal-close" onclick="AtizProm.closeModal('newTicketModal')"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
        <div class="form-group">
          <label>Subject *</label>
          <input type="text" name="subject" class="form-control" required placeholder="Brief description of your issue">
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Category</label>
            <select name="category" class="form-control">
              <option value="inquiry">General Inquiry</option>
              <option value="complaint">Complaint</option>
              <option value="technical">Technical Issue</option>
              <option value="billing">Billing / Payment</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div class="form-group">
            <label>Priority</label>
            <select name="priority" class="form-control">
              <option value="low">Low</option>
              <option value="normal" selected>Normal</option>
              <option value="high">High</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label>Message *</label>
          <textarea name="message" class="form-control" rows="5" required placeholder="Describe your issue in detail..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="AtizProm.closeModal('newTicketModal')" class="btn" style="border:1px solid var(--border)">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit Ticket</button>
      </div>
    </form>
  </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
</body>
</html>
