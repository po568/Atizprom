<?php
define('BASE_PATH', __DIR__);
require_once __DIR__ . '/includes/bootstrap.php';
$auth = new Auth();
$db = Database::getInstance();

// Redirect if logged in
if ($auth->isLoggedIn()) {
    if ($auth->isAdmin()) redirect(BASE_URL . '/admin/');
    else redirect(BASE_URL . '/customer/');
}

$services = $db->fetchAll("SELECT s.*, c.name as cat_name, c.icon FROM services s JOIN service_categories c ON s.category_id = c.id WHERE s.is_featured = 1 AND s.is_active = 1 ORDER BY s.sort_order LIMIT 8");
$portfolio = $db->fetchAll("SELECT * FROM portfolio WHERE is_featured = 1 AND is_active = 1 ORDER BY created_at DESC LIMIT 6");
$testimonials = $db->fetchAll("SELECT * FROM testimonials WHERE is_approved = 1 AND is_featured = 1 ORDER BY id DESC LIMIT 4");
$courses = $db->fetchAll("SELECT * FROM courses WHERE is_featured = 1 AND is_active = 1 LIMIT 4");
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Atiz Prom – Home of All Tech Solutions. Professional photography, videography, film production, graphics design, computer courses and more in Kyerwa, Tanzania.">
<meta name="keywords" content="Atiz Prom, photography Tanzania, videography Kagera, film production, graphics design, computer courses Kyerwa">
<meta property="og:title" content="Atiz Prom – Home of All Tech Solutions">
<meta property="og:description" content="Professional Technology & Creative Media Company in Kyerwa, Kagera, Tanzania">
<meta property="og:type" content="website">
<meta property="og:url" content="<?= BASE_URL ?>">
<title>Atiz Prom – Home of All Tech Solutions</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/home.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<!-- TOP BAR -->
<div class="topbar">
  <div class="container">
    <div class="topbar-left">
      <span><i class="fas fa-map-marker-alt"></i> Kyerwa, Kagera, Tanzania</span>
      <span><i class="fas fa-envelope"></i> <?= htmlspecialchars(getSetting('site_email', 'atizpromltd@gmail.com')) ?></span>
    </div>
    <div class="topbar-right">
      <a href="<?= getSetting('facebook_url', 'https://facebook.com/AtizPromArts') ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
      <a href="<?= getSetting('instagram_url', 'https://instagram.com/atiz_prom') ?>" target="_blank"><i class="fab fa-instagram"></i></a>
      <a href="<?= getSetting('tiktok_url', 'https://tiktok.com/@atizpromarts') ?>" target="_blank"><i class="fab fa-tiktok"></i></a>
      <a href="<?= getSetting('youtube_url', 'https://youtube.com/@AtizPromArts') ?>" target="_blank"><i class="fab fa-youtube"></i></a>
      <?php include __DIR__ . '/includes/lang_switcher.php'; ?>
    </div>
  </div>
</div>

<!-- NAVBAR -->
<nav class="navbar" id="navbar">
  <div class="container">
    <a href="<?= BASE_URL ?>" class="navbar-brand">
      <div class="logo-icon"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div>
      <div class="logo-text">
        <strong>ATIZ PROM</strong>
        <small>Home of All Tech Solutions</small>
      </div>
    </a>
    <button class="nav-toggle" id="navToggle"><i class="fas fa-bars"></i></button>
    <ul class="nav-menu" id="navMenu">
      <li><a href="#home"><?= t('nav_home') ?></a></li>
      <li><a href="#services"><?= t('nav_services') ?></a></li>
      <li><a href="#portfolio"><?= t('nav_portfolio') ?></a></li>
      <li><a href="#courses"><?= t('nav_courses') ?></a></li>
      <li><a href="#products"><?= t('nav_products') ?></a></li>
      <li><a href="#about"><?= t('nav_about') ?></a></li>
      <li><a href="#contact"><?= t('nav_contact') ?></a></li>
      <li class="nav-divider"></li>
      <li><a href="<?= BASE_URL ?>/customer/" class="btn-nav-login"><i class="fas fa-user"></i> <?= t('nav_login') ?></a></li>
      <li><a href="<?= BASE_URL ?>/customer/register.php" class="btn-nav-register"><?= t('nav_get_started') ?></a></li>
    </ul>
  </div>
</nav>

<!-- HERO -->
<section class="hero" id="home">
  <div class="hero-bg"></div>
  <div class="hero-overlay"></div>
  <div class="container hero-content">
    <div class="hero-text">
      <div class="hero-badge"><i class="fas fa-star"></i> <?= t('home_hero_badge') ?></div>
      <h1 class="hero-title"><?= str_replace(['{tech}','{creativity}'], ['<span class="text-yellow">'.t('home_hero_tech').'</span>','<span class="text-yellow">'.t('home_hero_creativity').'</span>'], t('home_hero_title_full')) ?></h1>
      <p class="hero-subtitle"><?= t('home_hero_subtitle') ?></p>
      <div class="hero-buttons">
        <a href="<?= BASE_URL ?>/customer/services.php" class="btn btn-primary btn-lg"><i class="fas fa-rocket"></i> <?= t('home_explore_services') ?></a>
        <a href="<?= BASE_URL ?>/customer/booking.php" class="btn btn-outline-light btn-lg"><i class="fas fa-calendar-check"></i> <?= t('home_book_now') ?></a>
      </div>
      <div class="hero-stats">
        <div class="stat"><strong>500+</strong><span><?= t('home_stat_projects') ?></span></div>
        <div class="stat-divider"></div>
        <div class="stat"><strong>200+</strong><span><?= t('home_stat_clients') ?></span></div>
        <div class="stat-divider"></div>
        <div class="stat"><strong>50+</strong><span><?= t('home_stat_courses') ?></span></div>
        <div class="stat-divider"></div>
        <div class="stat"><strong>5+</strong><span><?= t('home_stat_experience') ?></span></div>
      </div>
    </div>
    <div class="hero-image">
      <div class="hero-card hero-card-1"><i class="fas fa-camera"></i><span><?= t('home_hero_photography') ?></span></div>
      <div class="hero-card hero-card-2"><i class="fas fa-video"></i><span><?= t('home_hero_videography') ?></span></div>
      <div class="hero-card hero-card-3"><i class="fas fa-palette"></i><span><?= t('home_hero_design') ?></span></div>
      <div class="hero-circle"></div>
    </div>
  </div>
</section>

<!-- SERVICES -->
<section class="section" id="services">
  <div class="container">
    <div class="section-header">
      <div class="section-tag"><?= t('home_what_we_do') ?></div>
      <h2><?= t('home_our_services') ?> <span class="text-primary"></span></h2>
      <p><?= t('home_services_full_subtitle') ?></p>
    </div>
    <div class="services-grid">
      <?php foreach ($services as $s): ?>
      <div class="service-card" data-aos="fade-up">
        <div class="service-icon"><i class="fas <?= htmlspecialchars($s['icon']) ?>"></i></div>
        <div class="service-cat"><?= htmlspecialchars($s['cat_name']) ?></div>
        <h3><?= htmlspecialchars($s['name']) ?></h3>
        <p><?= htmlspecialchars($s['description']) ?></p>
        <?php if ($s['price_from']): ?>
        <div class="service-price"><?= $s['price_label'] ?> <?= formatCurrency($s['price_from']) ?></div>
        <?php endif; ?>
        <a href="<?= BASE_URL ?>/customer/services.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-service"><?= t('home_learn_more') ?> <i class="fas fa-arrow-right"></i></a>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="text-center mt-4">
      <a href="<?= BASE_URL ?>/customer/services.php" class="btn btn-primary"><?= t('home_view_all_services') ?></a>
    </div>
  </div>
</section>

<!-- WHY CHOOSE US -->
<section class="section section-dark">
  <div class="container">
    <div class="section-header light">
      <div class="section-tag"><?= t('home_why_us_tag') ?></div>
      <h2><?= str_replace('{trusted}', '<span class="text-yellow">'.t('home_why_us_trusted').'</span>', t('home_why_us_title')) ?></h2>
    </div>
    <div class="features-grid">
      <div class="feature-item">
        <div class="feature-icon"><i class="fas fa-medal"></i></div>
        <h4><?= t('feat1_title') ?></h4>
        <p><?= t('feat1_desc') ?></p>
      </div>
      <div class="feature-item">
        <div class="feature-icon"><i class="fas fa-clock"></i></div>
        <h4><?= t('feat2_title') ?></h4>
        <p><?= t('feat2_desc') ?></p>
      </div>
      <div class="feature-item">
        <div class="feature-icon"><i class="fas fa-shield-alt"></i></div>
        <h4><?= t('feat3_title') ?></h4>
        <p><?= t('feat3_desc') ?></p>
      </div>
      <div class="feature-item">
        <div class="feature-icon"><i class="fas fa-headset"></i></div>
        <h4><?= t('feat4_title') ?></h4>
        <p><?= t('feat4_desc') ?></p>
      </div>
      <div class="feature-item">
        <div class="feature-icon"><i class="fas fa-coins"></i></div>
        <h4><?= t('feat5_title') ?></h4>
        <p><?= t('feat5_desc') ?></p>
      </div>
      <div class="feature-item">
        <div class="feature-icon"><i class="fas fa-users"></i></div>
        <h4><?= t('feat6_title') ?></h4>
        <p><?= t('feat6_desc') ?></p>
      </div>
    </div>
  </div>
</section>

<!-- PORTFOLIO -->
<section class="section" id="portfolio">
  <div class="container">
    <div class="section-header">
      <div class="section-tag"><?= t('home_our_work') ?></div>
      <h2><?= t('home_featured_portfolio') ?></h2>
      <p><?= t('home_portfolio_showcase') ?></p>
    </div>
    <div class="portfolio-filter">
      <button class="filter-btn active" data-filter="all"><?= t('pf_filter_all') ?></button>
      <button class="filter-btn" data-filter="photography"><?= t('pf_filter_photography') ?></button>
      <button class="filter-btn" data-filter="videography"><?= t('pf_filter_videography') ?></button>
      <button class="filter-btn" data-filter="films"><?= t('pf_filter_films') ?></button>
      <button class="filter-btn" data-filter="graphics_design"><?= t('pf_filter_graphics') ?></button>
      <button class="filter-btn" data-filter="events_coverage"><?= t('pf_filter_events') ?></button>
    </div>
    <div class="portfolio-grid" id="portfolioGrid">
      <?php foreach ($portfolio as $p): ?>
      <div class="portfolio-item" data-category="<?= $p['category'] ?>">
        <div class="portfolio-thumb">
          <?php if ($p['thumbnail']): ?>
            <img src="<?= UPLOAD_URL . $p['thumbnail'] ?>" alt="<?= htmlspecialchars($p['title']) ?>">
          <?php else: ?>
            <div class="portfolio-placeholder"><i class="fas fa-image"></i></div>
          <?php endif; ?>
          <div class="portfolio-overlay">
            <div class="portfolio-info">
              <span class="portfolio-cat"><?= ucfirst(str_replace('_',' ',$p['category'])) ?></span>
              <h4><?= htmlspecialchars($p['title']) ?></h4>
              <?php if ($p['client_name']): ?>
              <p><i class="fas fa-user"></i> <?= htmlspecialchars($p['client_name']) ?></p>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="text-center mt-4">
      <a href="<?= BASE_URL ?>/customer/portfolio.php" class="btn btn-primary"><?= t('home_view_full_portfolio') ?></a>
    </div>
  </div>
</section>

<!-- COURSES -->
<section class="section bg-light" id="courses">
  <div class="container">
    <div class="section-header">
      <div class="section-tag"><?= t('home_learn_grow') ?></div>
      <h2><?= t('home_computer_courses') ?></h2>
      <p><?= t('home_courses_it_subtitle') ?></p>
    </div>
    <div class="courses-grid">
      <?php foreach ($courses as $c): ?>
      <div class="course-card">
        <div class="course-header">
          <div class="course-icon"><i class="fas fa-laptop-code"></i></div>
          <span class="course-mode badge-<?= $c['mode'] ?>"><?= ucfirst($c['mode']) ?></span>
        </div>
        <h3><?= htmlspecialchars($c['title']) ?></h3>
        <p><?= htmlspecialchars(substr($c['description'], 0, 100)) ?>...</p>
        <div class="course-meta">
          <?php if ($c['duration']): ?><span><i class="fas fa-clock"></i> <?= $c['duration'] ?></span><?php endif; ?>
          <span class="course-price"><?= formatCurrency($c['price']) ?></span>
        </div>
        <a href="<?= BASE_URL ?>/customer/courses.php?id=<?= $c['id'] ?>" class="btn btn-outline-primary btn-sm btn-block"><?= t('home_view_course') ?></a>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="text-center mt-4">
      <a href="<?= BASE_URL ?>/customer/courses.php" class="btn btn-primary"><?= t('home_view_all_courses_btn') ?></a>
    </div>
  </div>
</section>

<!-- PRODUCTS -->
<section class="section" id="products">
  <div class="container">
    <div class="section-header">
      <div class="section-tag"><?= t('home_product_catalog_tag') ?></div>
      <h2><?= t('home_office_stationery') ?></h2>
      <p><?= t('home_products_browse_subtitle') ?></p>
    </div>
    <div class="products-banner">
      <div class="product-cat-card" onclick="location.href='<?= BASE_URL ?>/customer/products.php?cat=1'">
        <i class="fas fa-chair"></i><span><?= t('home_cat_office_supplies') ?></span>
      </div>
      <div class="product-cat-card" onclick="location.href='<?= BASE_URL ?>/customer/products.php?cat=2'">
        <i class="fas fa-pen-nib"></i><span><?= t('home_cat_stationery') ?></span>
      </div>
      <div class="product-cat-card" onclick="location.href='<?= BASE_URL ?>/customer/products.php?cat=3'">
        <i class="fas fa-laptop"></i><span><?= t('home_cat_technology') ?></span>
      </div>
      <div class="product-cat-card" onclick="location.href='<?= BASE_URL ?>/customer/products.php?cat=4'">
        <i class="fas fa-print"></i><span><?= t('home_cat_printing') ?></span>
      </div>
    </div>
    <div class="text-center mt-4">
      <a href="<?= BASE_URL ?>/customer/products.php" class="btn btn-primary"><?= t('home_browse_all_products') ?></a>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<?php if (!empty($testimonials)): ?>
<section class="section section-dark" id="testimonials">
  <div class="container">
    <div class="section-header light">
      <div class="section-tag"><?= t('home_testimonials_tag') ?></div>
      <h2><?= t('home_client_testimonials') ?></h2>
    </div>
    <div class="testimonials-slider">
      <?php foreach ($testimonials as $t): ?>
      <div class="testimonial-card">
        <div class="testimonial-stars">
          <?php for ($i=0;$i<$t['rating'];$i++): ?><i class="fas fa-star"></i><?php endfor; ?>
        </div>
        <p class="testimonial-text">"<?= htmlspecialchars($t['content']) ?>"</p>
        <div class="testimonial-author">
          <div class="author-avatar"><?= strtoupper(substr($t['author_name'],0,1)) ?></div>
          <div>
            <strong><?= htmlspecialchars($t['author_name']) ?></strong>
            <?php if ($t['author_title']): ?><span><?= htmlspecialchars($t['author_title']) ?></span><?php endif; ?>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ABOUT -->
<section class="section" id="about">
  <div class="container">
    <div class="about-grid">
      <div class="about-image">
        <div class="about-img-box">
          <div class="about-badge-top"><i class="fas fa-award"></i> <?= t('about_est') ?></div>
          <div class="about-visual">
            <img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo" style="object-fit:contain;border-radius:18px">
          </div>
          <div class="about-badge-bottom"><i class="fas fa-star"></i> <?= t('about_5star') ?></div>
        </div>
      </div>
      <div class="about-content">
        <div class="section-tag"><?= t('about_tag') ?></div>
        <h2><?= str_replace('{slogan}', '<span class="text-primary">'.htmlspecialchars(getSetting('site_slogan', 'Home of All Tech Solutions')).'</span>', t('about_title')) ?></h2>
        <p><?= t('about_p1') ?></p>
        <p><?= t('about_p2') ?></p>
        <div class="about-highlights">
          <div class="highlight"><i class="fas fa-check-circle"></i> <?= t('about_highlight1') ?></div>
          <div class="highlight"><i class="fas fa-check-circle"></i> <?= t('about_highlight2') ?></div>
          <div class="highlight"><i class="fas fa-check-circle"></i> <?= t('about_highlight3') ?></div>
          <div class="highlight"><i class="fas fa-check-circle"></i> <?= t('about_highlight4') ?></div>
          <div class="highlight"><i class="fas fa-check-circle"></i> <?= t('about_highlight5') ?></div>
          <div class="highlight"><i class="fas fa-check-circle"></i> <?= t('about_highlight6') ?></div>
        </div>
        <a href="<?= BASE_URL ?>/customer/about.php" class="btn btn-primary mt-3"><?= t('home_learn_about_us') ?></a>
      </div>
    </div>
  </div>
</section>

<!-- CONTACT -->
<section class="section bg-light" id="contact">
  <div class="container">
    <div class="section-header">
      <div class="section-tag"><?= t('contact_get_in_touch') ?></div>
      <h2><?= t('contact_us_title') ?></h2>
      <p><?= t('contact_lets_talk') ?></p>
    </div>
    <div class="contact-grid">
      <div class="contact-info">
        <div class="contact-card">
          <div class="contact-icon"><i class="fas fa-map-marker-alt"></i></div>
          <div><h4><?= t('contact_location') ?></h4><p><?= t('contact_location_value') ?></p></div>
        </div>
        <div class="contact-card">
          <div class="contact-icon"><i class="fas fa-envelope"></i></div>
          <div><h4><?= t('contact_email_label') ?></h4><p><?= htmlspecialchars(getSetting('site_email', 'atizpromltd@gmail.com')) ?></p></div>
        </div>
        <div class="contact-card">
          <div class="contact-icon"><i class="fas fa-phone"></i></div>
          <div><h4><?= t('contact_phone_label') ?></h4><p><?= htmlspecialchars(getSetting('site_phone', '+255626296753')) ?></p></div>
        </div>
        <div class="contact-social">
          <a href="<?= getSetting('facebook_url', 'https://facebook.com/AtizPromArts') ?>" target="_blank" class="social-btn fb"><i class="fab fa-facebook-f"></i> Facebook</a>
          <a href="<?= getSetting('instagram_url', 'https://instagram.com/atiz_prom') ?>" target="_blank" class="social-btn ig"><i class="fab fa-instagram"></i> Instagram</a>
          <a href="<?= getSetting('tiktok_url', 'https://tiktok.com/@atizpromarts') ?>" target="_blank" class="social-btn tt"><i class="fab fa-tiktok"></i> TikTok</a>
          <a href="<?= getSetting('youtube_url', 'https://youtube.com/@AtizPromArts') ?>" target="_blank" class="social-btn yt"><i class="fab fa-youtube"></i> YouTube</a>
        </div>
      </div>
      <div class="contact-form-wrap">
        <form class="contact-form" id="contactForm">
          <input type="hidden" name="csrf_token" value="<?= (new Auth())->getCSRFToken() ?>">
          <div class="form-row">
            <div class="form-group">
              <label><?= t('contact_full_name') ?> *</label>
              <input type="text" name="name" class="form-control" required placeholder="John Doe">
            </div>
            <div class="form-group">
              <label><?= t('contact_email_address') ?> *</label>
              <input type="email" name="email" class="form-control" required placeholder="john@example.com">
            </div>
          </div>
          <div class="form-group">
            <label><?= t('contact_subject_label') ?> *</label>
            <input type="text" name="subject" class="form-control" required placeholder="<?= t('contact_subject_placeholder') ?>">
          </div>
          <div class="form-group">
            <label><?= t('contact_message_label') ?> *</label>
            <textarea name="message" class="form-control" rows="5" required placeholder="<?= t('contact_message_placeholder') ?>"></textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-block">
            <i class="fas fa-paper-plane"></i> <?= t('contact_send_message_btn') ?>
          </button>
          <div id="contactAlert" class="alert mt-2" style="display:none"></div>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="footer">
  <div class="footer-top">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <div class="footer-logo">
            <div class="logo-icon"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div>
            <div class="logo-text"><strong>ATIZ PROM</strong><small><?= htmlspecialchars(getSetting('site_slogan', 'Home of All Tech Solutions')) ?></small></div>
          </div>
          <p><?= t('footer_brand_desc') ?></p>
          <div class="footer-social">
            <a href="<?= getSetting('facebook_url', 'https://facebook.com/AtizPromArts') ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
            <a href="<?= getSetting('instagram_url', 'https://instagram.com/atiz_prom') ?>" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="<?= getSetting('tiktok_url', 'https://tiktok.com/@atizpromarts') ?>" target="_blank"><i class="fab fa-tiktok"></i></a>
            <a href="<?= getSetting('youtube_url', 'https://youtube.com/@AtizPromArts') ?>" target="_blank"><i class="fab fa-youtube"></i></a>
          </div>
        </div>
        <div class="footer-links">
          <h4><?= t('footer_quick_links') ?></h4>
          <ul>
            <li><a href="#home"><?= t('nav_home') ?></a></li>
            <li><a href="#services"><?= t('nav_services') ?></a></li>
            <li><a href="#portfolio"><?= t('nav_portfolio') ?></a></li>
            <li><a href="#courses"><?= t('nav_courses') ?></a></li>
            <li><a href="#about"><?= t('nav_about') ?></a></li>
            <li><a href="#contact"><?= t('nav_contact') ?></a></li>
          </ul>
        </div>
        <div class="footer-links">
          <h4><?= t('footer_services_heading') ?></h4>
          <ul>
            <li><a href="<?= BASE_URL ?>/customer/booking.php?type=photography"><?= t('home_hero_photography') ?></a></li>
            <li><a href="<?= BASE_URL ?>/customer/booking.php?type=videography"><?= t('home_hero_videography') ?></a></li>
            <li><a href="<?= BASE_URL ?>/customer/booking.php?type=film"><?= t('footer_film_production') ?></a></li>
            <li><a href="<?= BASE_URL ?>/customer/booking.php?type=design"><?= t('footer_graphics_design') ?></a></li>
            <li><a href="<?= BASE_URL ?>/customer/booking.php?type=events"><?= t('footer_event_coverage') ?></a></li>
            <li><a href="<?= BASE_URL ?>/customer/courses.php"><?= t('footer_computer_courses') ?></a></li>
          </ul>
        </div>
        <div class="footer-contact">
          <h4><?= t('footer_contact_info') ?></h4>
          <p><i class="fas fa-map-marker-alt"></i> <?= t('contact_location_value') ?></p>
          <p><i class="fas fa-envelope"></i> <?= htmlspecialchars(getSetting('site_email', 'atizpromltd@gmail.com')) ?></p>
          <p><i class="fas fa-phone"></i> <?= htmlspecialchars(getSetting('site_phone', '+255626296753')) ?></p>
          <div class="footer-portal-links">
            <a href="<?= BASE_URL ?>/customer/" class="btn btn-sm btn-outline-light"><?= t('nav_customer_portal') ?></a>
            <a href="<?= BASE_URL ?>/admin/" class="btn btn-sm btn-outline-yellow"><?= t('auth_admin_portal') ?></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <div class="container">
      <p>&copy; <?= date('Y') ?> Atiz Prom. <?= t('footer_rights') ?> | <?= t('footer_designed_with') ?> <i class="fas fa-heart text-yellow"></i> <?= t('footer_in_tanzania') ?></p>
    </div>
  </div>
</footer>

<!-- BACK TO TOP -->
<button class="back-to-top" id="backToTop"><i class="fas fa-chevron-up"></i></button>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/home.js"></script>
</body>
</html>
