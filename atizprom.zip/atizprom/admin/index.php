<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/');
$auth->requireRole(['super_admin','admin','finance_officer','production_manager','graphic_designer','course_instructor','inventory_officer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$roleId = $_SESSION['user_role'];
$isExecutive = in_array($roleId, [1,2,3]); // super_admin, admin, finance_officer get the full dashboard
$notifCount = getNotificationCount($user['id']);

if ($isExecutive) {
    // ===== EXECUTIVE DASHBOARD (Super Admin / Admin / Finance Officer) =====
    $totalCustomers = $db->fetchOne("SELECT COUNT(*) as c FROM users WHERE role_id = 8")['c'] ?? 0;
    $totalBookings  = $db->fetchOne("SELECT COUNT(*) as c FROM bookings")['c'] ?? 0;
    $pendingBookings= $db->fetchOne("SELECT COUNT(*) as c FROM bookings WHERE status='pending'")['c'] ?? 0;
    $totalProjects  = $db->fetchOne("SELECT COUNT(*) as c FROM projects")['c'] ?? 0;
    $activeProjects = $db->fetchOne("SELECT COUNT(*) as c FROM projects WHERE status='in_progress'")['c'] ?? 0;
    $openTickets    = $db->fetchOne("SELECT COUNT(*) as c FROM tickets WHERE status='open'")['c'] ?? 0;
    $totalRevenue   = $db->fetchOne("SELECT COALESCE(SUM(amount),0) as r FROM payments WHERE status='confirmed'")['r'] ?? 0;
    $monthRevenue   = $db->fetchOne("SELECT COALESCE(SUM(amount),0) as r FROM payments WHERE status='confirmed' AND MONTH(payment_date)=MONTH(CURDATE()) AND YEAR(payment_date)=YEAR(CURDATE())")['r'] ?? 0;
    $totalEnrollments = $db->fetchOne("SELECT COUNT(*) as c FROM course_enrollments")['c'] ?? 0;
    $pendingQuotes  = $db->fetchOne("SELECT COUNT(*) as c FROM quotations WHERE status='sent'")['c'] ?? 0;
    $monthlyRevenue = $db->fetchAll("SELECT DATE_FORMAT(payment_date,'%b %Y') as month, SUM(amount) as total FROM payments WHERE status='confirmed' AND payment_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) GROUP BY YEAR(payment_date), MONTH(payment_date) ORDER BY payment_date ASC");
    $recentBookings = $db->fetchAll("SELECT b.*, s.name as service_name, CONCAT(u.first_name,' ',u.last_name) as customer_name FROM bookings b JOIN services s ON b.service_id=s.id JOIN users u ON b.customer_id=u.id ORDER BY b.created_at DESC LIMIT 8");
    $bookingsByService = $db->fetchAll("SELECT sc.name, COUNT(b.id) as total FROM bookings b JOIN services s ON b.service_id=s.id JOIN service_categories sc ON s.category_id=sc.id GROUP BY sc.id ORDER BY total DESC LIMIT 6");
} else {
    // ===== ROLE-SPECIFIC STAFF DASHBOARD =====
    $roleConfig = [
        4 => ['title' => 'Production Dashboard', 'icon' => 'fa-video', 'desc' => 'Your photography, videography, film & events workload'],
        5 => ['title' => 'Design Dashboard',     'icon' => 'fa-palette', 'desc' => 'Your graphics design projects and portfolio'],
        6 => ['title' => 'Instructor Dashboard', 'icon' => 'fa-graduation-cap', 'desc' => 'Your courses and student enrollments'],
        7 => ['title' => 'Inventory Dashboard',  'icon' => 'fa-box-open', 'desc' => 'Product catalog and stock status'],
    ];
    $cfg = $roleConfig[$roleId] ?? ['title'=>'Dashboard','icon'=>'fa-tachometer-alt','desc'=>'Welcome to your workspace'];

    if ($roleId == 4) { // Production Manager
        $totalBookings = $db->fetchOne("SELECT COUNT(*) as c FROM bookings")['c'] ?? 0;
        $pendingBookings = $db->fetchOne("SELECT COUNT(*) as c FROM bookings WHERE status='pending'")['c'] ?? 0;
        $activeProjects = $db->fetchOne("SELECT COUNT(*) as c FROM projects WHERE status='in_progress'")['c'] ?? 0;
        $completedProjects = $db->fetchOne("SELECT COUNT(*) as c FROM projects WHERE status='completed'")['c'] ?? 0;
        $recentBookings = $db->fetchAll("SELECT b.*, s.name as service_name, CONCAT(u.first_name,' ',u.last_name) as customer_name FROM bookings b JOIN services s ON b.service_id=s.id JOIN users u ON b.customer_id=u.id ORDER BY b.created_at DESC LIMIT 8");
    } elseif ($roleId == 5) { // Graphic Designer
        $totalProjects = $db->fetchOne("SELECT COUNT(*) as c FROM projects WHERE category LIKE '%design%' OR category LIKE '%graphic%'")['c'] ?? 0;
        $activeProjects = $db->fetchOne("SELECT COUNT(*) as c FROM projects WHERE status='in_progress'")['c'] ?? 0;
        $portfolioCount = $db->fetchOne("SELECT COUNT(*) as c FROM portfolio WHERE category='graphics_design'")['c'] ?? 0;
        $recentProjects = $db->fetchAll("SELECT * FROM projects ORDER BY created_at DESC LIMIT 8");
    } elseif ($roleId == 6) { // Course Instructor
        $totalCourses = $db->fetchOne("SELECT COUNT(*) as c FROM courses")['c'] ?? 0;
        $activeCourses = $db->fetchOne("SELECT COUNT(*) as c FROM courses WHERE is_active=1")['c'] ?? 0;
        $totalEnrollments = $db->fetchOne("SELECT COUNT(*) as c FROM course_enrollments")['c'] ?? 0;
        $activeEnrollments = $db->fetchOne("SELECT COUNT(*) as c FROM course_enrollments WHERE status='active'")['c'] ?? 0;
        $recentEnrollments = $db->fetchAll("SELECT ce.*, c.title as course_title, CONCAT(u.first_name,' ',u.last_name) as student_name FROM course_enrollments ce JOIN courses c ON ce.course_id=c.id JOIN users u ON ce.student_id=u.id ORDER BY ce.enrolled_at DESC LIMIT 8");
    } elseif ($roleId == 7) { // Inventory Officer
        $totalProducts = $db->fetchOne("SELECT COUNT(*) as c FROM products")['c'] ?? 0;
        $activeProducts = $db->fetchOne("SELECT COUNT(*) as c FROM products WHERE is_active=1")['c'] ?? 0;
        $outOfStock = $db->fetchOne("SELECT COUNT(*) as c FROM products WHERE stock_status='out_of_stock'")['c'] ?? 0;
        $featuredProducts = $db->fetchOne("SELECT COUNT(*) as c FROM products WHERE is_featured=1")['c'] ?? 0;
        $recentProducts = $db->fetchAll("SELECT * FROM products ORDER BY created_at DESC LIMIT 8");
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<?php if ($isExecutive): ?><script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script><?php endif; ?>
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar">
  <?php include __DIR__ . '/includes/sidebar.php'; ?>
</aside>
<div class="main-content" id="mainContent">

  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div>
        <div class="header-title">Dashboard</div>
        <div class="header-breadcrumb">Home / Dashboard</div>
      </div>
    </div>
    <div class="header-actions">
      <a href="<?= BASE_URL ?>/admin/notifications.php" class="header-icon-btn">
        <i class="fas fa-bell"></i>
        <?php if ($notifCount > 0): ?><span class="notif-badge"><?= $notifCount ?></span><?php endif; ?>
      </a>
      <a href="<?= BASE_URL ?>" target="_blank" class="header-icon-btn" title="View Website"><i class="fas fa-external-link-alt"></i></a>
      <div class="dropdown">
        <div class="user-avatar-btn" onclick="Admin.initDropdowns(); document.getElementById('userDropdown').classList.toggle('open')">
          <?php if ($user['profile_picture']): ?>
            <img src="<?= UPLOAD_URL . $user['profile_picture'] ?>" alt="Avatar" style="width:36px;height:36px;border-radius:50%;object-fit:cover;">
          <?php else: ?>
            <div class="user-avatar"><?= strtoupper(substr($user['first_name'],0,1)) ?></div>
          <?php endif; ?>
          <div class="user-info-text">
            <strong><?= htmlspecialchars($user['first_name']) ?></strong>
            <small><?= htmlspecialchars($user['role_name']) ?></small>
          </div>
          <i class="fas fa-chevron-down" style="font-size:0.75rem;color:var(--text-muted)"></i>
        </div>
        <div class="dropdown-menu" id="userDropdown">
          <a class="dropdown-item" href="<?= BASE_URL ?>/admin/profile.php"><i class="fas fa-user"></i> My Profile</a>
          <?php if ($roleId==1): ?><a class="dropdown-item" href="<?= BASE_URL ?>/admin/settings/"><i class="fas fa-cog"></i> Settings</a><?php endif; ?>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item danger" href="<?= BASE_URL ?>/admin/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
      </div>
    </div>
  </div>

  <div class="content-body">

  <?php if ($isExecutive): ?>
    <!-- ================= EXECUTIVE DASHBOARD ================= -->
    <div class="d-flex align-items-center justify-content-between mb-3">
      <div>
        <h2 style="font-size:1.4rem;margin-bottom:4px">Good <?= date('H')<12?'Morning':( date('H')<17?'Afternoon':'Evening') ?>, <?= htmlspecialchars($user['first_name']) ?>! 👋</h2>
        <p class="text-muted" style="margin:0;font-size:0.9rem">Here's what's happening with Atiz Prom today.</p>
      </div>
      <div class="d-flex gap-2">
        <a href="<?= BASE_URL ?>/admin/reports/" class="btn btn-outline-primary btn-sm"><i class="fas fa-file-alt"></i> Reports</a>
        <a href="<?= BASE_URL ?>/admin/bookings/create.php" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> New Booking</a>
      </div>
    </div>

    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-users"></i></div><div class="stat-info"><strong><?= number_format($totalCustomers) ?></strong><span>Total Customers</span></div></div>
      <div class="stat-card"><div class="stat-icon yellow"><i class="fas fa-calendar-check"></i></div><div class="stat-info"><strong><?= number_format($totalBookings) ?></strong><span>Total Bookings</span><?php if ($pendingBookings > 0): ?><div class="stat-change up"><i class="fas fa-circle"></i> <?= $pendingBookings ?> pending</div><?php endif; ?></div></div>
      <div class="stat-card"><div class="stat-icon green"><i class="fas fa-project-diagram"></i></div><div class="stat-info"><strong><?= number_format($totalProjects) ?></strong><span>Total Projects</span><?php if ($activeProjects > 0): ?><div class="stat-change up"><?= $activeProjects ?> in progress</div><?php endif; ?></div></div>
      <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-coins"></i></div><div class="stat-info"><strong><?= formatCurrency($monthRevenue) ?></strong><span>Monthly Revenue</span></div></div>
      <div class="stat-card"><div class="stat-icon purple"><i class="fas fa-graduation-cap"></i></div><div class="stat-info"><strong><?= number_format($totalEnrollments) ?></strong><span>Course Enrollments</span></div></div>
      <div class="stat-card"><div class="stat-icon red"><i class="fas fa-ticket-alt"></i></div><div class="stat-info"><strong><?= number_format($openTickets) ?></strong><span>Open Tickets</span></div></div>
      <div class="stat-card"><div class="stat-icon orange"><i class="fas fa-file-invoice"></i></div><div class="stat-info"><strong><?= number_format($pendingQuotes) ?></strong><span>Pending Quotations</span></div></div>
      <div class="stat-card"><div class="stat-icon green"><i class="fas fa-money-bill-wave"></i></div><div class="stat-info"><strong><?= formatCurrency($totalRevenue) ?></strong><span>Total Revenue</span></div></div>
    </div>

    <div class="dashboard-grid-2 mb-4">
      <div class="chart-card">
        <div class="chart-header"><h4><i class="fas fa-chart-line text-primary"></i> Revenue – Last 6 Months</h4><a href="<?= BASE_URL ?>/admin/reports/" class="btn btn-sm btn-outline-primary">View Report</a></div>
        <div class="chart-body"><canvas id="revenueChart" height="280"></canvas></div>
      </div>
      <div class="chart-card">
        <div class="chart-header"><h4><i class="fas fa-chart-pie text-primary"></i> Bookings by Service</h4></div>
        <div class="chart-body"><canvas id="servicesChart" height="280"></canvas></div>
      </div>
    </div>

    <div class="dashboard-grid-2 mb-4">
      <div class="chart-card">
        <div class="chart-header"><h4>Recent Bookings</h4><a href="<?= BASE_URL ?>/admin/bookings/" class="btn btn-sm btn-outline-primary">View All</a></div>
        <div class="chart-body" style="padding:0">
          <div class="table-wrap">
            <table class="table">
              <thead><tr><th>Booking #</th><th>Customer</th><th>Service</th><th>Date</th><th>Status</th></tr></thead>
              <tbody>
                <?php foreach ($recentBookings as $b): ?>
                <tr><td><a href="<?= BASE_URL ?>/admin/bookings/view.php?id=<?= $b['id'] ?>" style="font-weight:600;color:var(--blue)"><?= $b['booking_number'] ?></a></td><td><?= htmlspecialchars($b['customer_name']) ?></td><td><?= htmlspecialchars($b['service_name']) ?></td><td><?= formatDate($b['booking_date']) ?></td><td><?= getStatusBadge($b['status']) ?></td></tr>
                <?php endforeach; ?>
                <?php if (empty($recentBookings)): ?><tr><td colspan="5" class="text-center text-muted" style="padding:30px">No bookings yet</td></tr><?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="chart-card">
        <div class="chart-header"><h4>Quick Actions</h4></div>
        <div class="chart-body">
          <div class="quick-actions">
            <?php if ($roleId != 3): // hide booking/customer/project/ticket/course/portfolio shortcuts from finance ?>
            <a href="<?= BASE_URL ?>/admin/bookings/create.php" class="quick-action-btn"><i class="fas fa-calendar-plus"></i><span>New Booking</span></a>
            <a href="<?= BASE_URL ?>/admin/customers/create.php" class="quick-action-btn"><i class="fas fa-user-plus"></i><span>Add Customer</span></a>
            <?php endif; ?>
            <a href="<?= BASE_URL ?>/admin/quotations/" class="quick-action-btn"><i class="fas fa-file-invoice"></i><span>Quotations</span></a>
            <?php if ($roleId != 3): ?>
            <a href="<?= BASE_URL ?>/admin/projects/" class="quick-action-btn"><i class="fas fa-plus-circle"></i><span>Projects</span></a>
            <?php endif; ?>
            <a href="<?= BASE_URL ?>/admin/invoices/" class="quick-action-btn"><i class="fas fa-receipt"></i><span>Invoices</span></a>
            <?php if ($roleId != 3): ?>
            <a href="<?= BASE_URL ?>/admin/tickets/" class="quick-action-btn"><i class="fas fa-headset"></i><span>Support Tickets</span></a>
            <a href="<?= BASE_URL ?>/admin/courses/" class="quick-action-btn"><i class="fas fa-book"></i><span>Manage Courses</span></a>
            <a href="<?= BASE_URL ?>/admin/portfolio/" class="quick-action-btn"><i class="fas fa-images"></i><span>Portfolio</span></a>
            <?php else: ?>
            <a href="<?= BASE_URL ?>/admin/enrollments/" class="quick-action-btn"><i class="fas fa-user-graduate"></i><span>Enrollment Requests</span></a>
            <a href="<?= BASE_URL ?>/admin/payments/" class="quick-action-btn"><i class="fas fa-money-bill-wave"></i><span>Payments</span></a>
            <?php endif; ?>
            <a href="<?= BASE_URL ?>/admin/reports/" class="quick-action-btn"><i class="fas fa-chart-bar"></i><span>Reports</span></a>
          </div>
        </div>
      </div>
    </div>

  <?php else: ?>
    <!-- ================= ROLE-SPECIFIC STAFF DASHBOARD ================= -->
    <div class="d-flex align-items-center gap-3 mb-4">
      <div style="width:54px;height:54px;border-radius:14px;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center;font-size:1.5rem"><i class="fas <?= $cfg['icon'] ?>"></i></div>
      <div>
        <h2 style="font-size:1.4rem;margin-bottom:2px">Good <?= date('H')<12?'Morning':( date('H')<17?'Afternoon':'Evening') ?>, <?= htmlspecialchars($user['first_name']) ?>! 👋</h2>
        <p class="text-muted" style="margin:0;font-size:0.9rem"><?= $cfg['desc'] ?></p>
      </div>
    </div>

    <?php if ($roleId == 4): // Production Manager ?>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon yellow"><i class="fas fa-calendar-check"></i></div><div class="stat-info"><strong><?= number_format($totalBookings) ?></strong><span>Total Bookings</span></div></div>
      <div class="stat-card"><div class="stat-icon orange"><i class="fas fa-clock"></i></div><div class="stat-info"><strong><?= number_format($pendingBookings) ?></strong><span>Pending Bookings</span></div></div>
      <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-spinner"></i></div><div class="stat-info"><strong><?= number_format($activeProjects) ?></strong><span>Active Projects</span></div></div>
      <div class="stat-card"><div class="stat-icon green"><i class="fas fa-check-circle"></i></div><div class="stat-info"><strong><?= number_format($completedProjects) ?></strong><span>Completed Projects</span></div></div>
    </div>
    <div class="chart-card mb-4">
      <div class="chart-header"><h4>Recent Bookings to Produce</h4><a href="<?= BASE_URL ?>/admin/bookings/" class="btn btn-sm btn-outline-primary">View All</a></div>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>Booking #</th><th>Customer</th><th>Service</th><th>Event Date</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($recentBookings as $b): ?>
          <tr><td><a href="<?= BASE_URL ?>/admin/bookings/view.php?id=<?= $b['id'] ?>" style="color:var(--blue);font-weight:600"><?= $b['booking_number'] ?></a></td><td><?= htmlspecialchars($b['customer_name']) ?></td><td><?= htmlspecialchars($b['service_name']) ?></td><td><?= formatDate($b['event_date']) ?></td><td><?= getStatusBadge($b['status']) ?></td></tr>
          <?php endforeach; ?>
          <?php if (empty($recentBookings)): ?><tr><td colspan="5" class="text-center text-muted" style="padding:30px">No bookings yet</td></tr><?php endif; ?>
        </tbody>
      </table></div>
    </div>
    <div class="quick-actions">
      <a href="<?= BASE_URL ?>/admin/bookings/" class="quick-action-btn"><i class="fas fa-calendar-check"></i><span>Service Bookings</span></a>
      <a href="<?= BASE_URL ?>/admin/projects/" class="quick-action-btn"><i class="fas fa-project-diagram"></i><span>Projects</span></a>
      <a href="<?= BASE_URL ?>/admin/portfolio/" class="quick-action-btn"><i class="fas fa-images"></i><span>Portfolio</span></a>
    </div>

    <?php elseif ($roleId == 5): // Graphic Designer ?>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-project-diagram"></i></div><div class="stat-info"><strong><?= number_format($totalProjects) ?></strong><span>Design Projects</span></div></div>
      <div class="stat-card"><div class="stat-icon yellow"><i class="fas fa-spinner"></i></div><div class="stat-info"><strong><?= number_format($activeProjects) ?></strong><span>In Progress</span></div></div>
      <div class="stat-card"><div class="stat-icon green"><i class="fas fa-images"></i></div><div class="stat-info"><strong><?= number_format($portfolioCount) ?></strong><span>Portfolio Items</span></div></div>
    </div>
    <div class="chart-card mb-4">
      <div class="chart-header"><h4>Recent Projects</h4><a href="<?= BASE_URL ?>/admin/projects/" class="btn btn-sm btn-outline-primary">View All</a></div>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>Project #</th><th>Title</th><th>Progress</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($recentProjects as $p): ?>
          <tr><td><?= $p['project_number'] ?></td><td><?= htmlspecialchars($p['title']) ?></td><td><?= $p['progress'] ?>%</td><td><?= getStatusBadge($p['status']) ?></td></tr>
          <?php endforeach; ?>
          <?php if (empty($recentProjects)): ?><tr><td colspan="4" class="text-center text-muted" style="padding:30px">No projects yet</td></tr><?php endif; ?>
        </tbody>
      </table></div>
    </div>
    <div class="quick-actions">
      <a href="<?= BASE_URL ?>/admin/projects/" class="quick-action-btn"><i class="fas fa-project-diagram"></i><span>Design Projects</span></a>
      <a href="<?= BASE_URL ?>/admin/portfolio/" class="quick-action-btn"><i class="fas fa-images"></i><span>Portfolio</span></a>
    </div>

    <?php elseif ($roleId == 6): // Course Instructor ?>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-book"></i></div><div class="stat-info"><strong><?= number_format($totalCourses) ?></strong><span>Total Courses</span></div></div>
      <div class="stat-card"><div class="stat-icon green"><i class="fas fa-check-circle"></i></div><div class="stat-info"><strong><?= number_format($activeCourses) ?></strong><span>Active Courses</span></div></div>
      <div class="stat-card"><div class="stat-icon yellow"><i class="fas fa-users"></i></div><div class="stat-info"><strong><?= number_format($totalEnrollments) ?></strong><span>Total Enrollments</span></div></div>
      <div class="stat-card"><div class="stat-icon purple"><i class="fas fa-user-graduate"></i></div><div class="stat-info"><strong><?= number_format($activeEnrollments) ?></strong><span>Active Students</span></div></div>
    </div>
    <div class="chart-card mb-4">
      <div class="chart-header"><h4>Recent Enrollments</h4><a href="<?= BASE_URL ?>/admin/courses/" class="btn btn-sm btn-outline-primary">View Courses</a></div>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>Enrollment #</th><th>Student</th><th>Course</th><th>Progress</th><th>Status</th></tr></thead>
        <tbody>
          <?php foreach ($recentEnrollments as $e): ?>
          <tr><td><?= $e['enrollment_number'] ?></td><td><?= htmlspecialchars($e['student_name']) ?></td><td><?= htmlspecialchars($e['course_title']) ?></td><td><?= $e['progress'] ?>%</td><td><?= getStatusBadge($e['status']) ?></td></tr>
          <?php endforeach; ?>
          <?php if (empty($recentEnrollments)): ?><tr><td colspan="5" class="text-center text-muted" style="padding:30px">No enrollments yet</td></tr><?php endif; ?>
        </tbody>
      </table></div>
    </div>
    <div class="quick-actions">
      <a href="<?= BASE_URL ?>/admin/courses/" class="quick-action-btn"><i class="fas fa-graduation-cap"></i><span>Manage Courses</span></a>
      <a href="<?= BASE_URL ?>/admin/enrollments/" class="quick-action-btn"><i class="fas fa-user-graduate"></i><span>Enrollment Requests</span></a>
    </div>

    <?php elseif ($roleId == 7): // Inventory Officer ?>
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-box"></i></div><div class="stat-info"><strong><?= number_format($totalProducts) ?></strong><span>Total Products</span></div></div>
      <div class="stat-card"><div class="stat-icon green"><i class="fas fa-check-circle"></i></div><div class="stat-info"><strong><?= number_format($activeProducts) ?></strong><span>Active Listings</span></div></div>
      <div class="stat-card"><div class="stat-icon red"><i class="fas fa-exclamation-triangle"></i></div><div class="stat-info"><strong><?= number_format($outOfStock) ?></strong><span>Out of Stock</span></div></div>
      <div class="stat-card"><div class="stat-icon yellow"><i class="fas fa-star"></i></div><div class="stat-info"><strong><?= number_format($featuredProducts) ?></strong><span>Featured Products</span></div></div>
    </div>
    <div class="chart-card mb-4">
      <div class="chart-header"><h4>Recent Products</h4><a href="<?= BASE_URL ?>/admin/products/" class="btn btn-sm btn-outline-primary">View Catalog</a></div>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>Name</th><th>Price</th><th>Stock Status</th><th>Active</th></tr></thead>
        <tbody>
          <?php foreach ($recentProducts as $p): ?>
          <tr><td><?= htmlspecialchars($p['name']) ?></td><td><?= formatCurrency($p['price']) ?></td><td><?= getStatusBadge($p['stock_status']) ?></td><td><?= $p['is_active']?'<span class="badge badge-success">Yes</span>':'<span class="badge badge-secondary">No</span>' ?></td></tr>
          <?php endforeach; ?>
          <?php if (empty($recentProducts)): ?><tr><td colspan="4" class="text-center text-muted" style="padding:30px">No products yet</td></tr><?php endif; ?>
        </tbody>
      </table></div>
    </div>
    <div class="quick-actions">
      <a href="<?= BASE_URL ?>/admin/products/" class="quick-action-btn"><i class="fas fa-box-open"></i><span>Product Catalog</span></a>
    </div>
    <?php endif; ?>

  <?php endif; ?>

  </div>
</div>
</div>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
<?php if ($isExecutive): ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const revLabels = <?= json_encode(array_column($monthlyRevenue, 'month')) ?>;
  const revData   = <?= json_encode(array_map(function($r) { return (float)$r['total']; }, $monthlyRevenue)) ?>;
  Admin.initRevenueChart(revLabels.length ? revLabels : ['Jan','Feb','Mar','Apr','May','Jun'], revData.length ? revData : [0,0,0,0,0,0]);

  const svcLabels = <?= json_encode(array_column($bookingsByService, 'name')) ?>;
  const svcData   = <?= json_encode(array_map(function($r) { return (int)$r['total']; }, $bookingsByService)) ?>;
  Admin.initServicesChart(svcLabels.length ? svcLabels : ['No data'], svcData.length ? svcData : [1]);
});
</script>
<?php endif; ?>
</body>
</html>
