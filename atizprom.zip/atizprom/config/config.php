<?php
// =====================================================
// ATIZ PROM - System Configuration
// =====================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'atizprom_db');

define('BASE_URL', 'http://localhost/atizprom');
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

define('SITE_NAME', 'Atiz Prom');
define('SITE_SLOGAN', 'Atiz Prom – Home of All Tech Solutions');
define('SITE_EMAIL', 'atizpromltd@gmail.com');
define('SITE_PHONE', '+255626296753');

define('UPLOAD_DIR', BASE_PATH . '/uploads/');
define('UPLOAD_URL', BASE_URL . '/uploads/');
define('MAX_FILE_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg','image/png','image/gif','image/webp']);
define('ALLOWED_DOC_TYPES', ['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/zip','audio/mpeg','video/mp4']);

define('CURRENCY', 'TZS');
define('TAX_RATE', 0.18);

define('SESSION_TIMEOUT', 7200); // 2 hours
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOCKOUT_DURATION', 1800); // 30 minutes

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'atizpromltd@gmail.com');
define('SMTP_PASS', '');
define('SMTP_FROM_NAME', 'Atiz Prom');

define('VERSION', '1.0.0');
define('INSTALLED', true);

// Error reporting (errors are logged, not displayed, to avoid leaking details to visitors)
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Timezone
date_default_timezone_set('Africa/Dar_es_Salaam');
