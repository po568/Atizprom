<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','production_manager']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();

$error = ''; $success = '';

if (isPost()) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } else {
        $bookingNum = $auth->generateNumber('BK', 'bookings', 'booking_number');
        $attachments = [];
        if (!empty($_FILES['attachments']['name'][0])) {
            foreach ($_FILES['attachments']['tmp_name'] as $k => $tmp) {
                if ($tmp) {
                    $file = ['name'=>$_FILES['attachments']['name'][$k],'type'=>$_FILES['attachments']['type'][$k],'tmp_name'=>$tmp,'size'=>$_FILES['attachments']['size'][$k]];
                    $res = uploadFile($file, 'projects');
                    if ($res['success']) $attachments[] = $res['path'];
                }
            }
        }
        $id = $db->insert(
            "INSERT INTO bookings (booking_number, customer_id, service_id, branch_id, booking_date, event_date, event_time, venue, guests_count, special_requirements, file_attachments, total_amount, notes, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            [$bookingNum, $_POST['customer_id'], $_POST['service_id'], $user['branch_id'], date('Y-m-d'), $_POST['event_date']?:null, $_POST['event_time']?:null, $_POST['venue']?:null, $_POST['guests_count']?:null, $_POST['special_requirements']?:null, $attachments?json_encode($attachments):null, $_POST['total_amount']?:null, $_POST['notes']?:null, $_POST['status']??'pending']
        );
        if ($id) {
            // Notification
            $db->execute("INSERT INTO notifications (user_id, title, message, type, link) VALUES (?,?,?,?,?)",
                [$_POST['customer_id'], 'Booking Confirmed', "Your booking #{$bookingNum} has been received.", 'booking', BASE_URL.'/customer/bookings/view.php?id='.$id]);
            $auth->logAudit($user['id'], 'BOOKING_CREATE', 'bookings', $id);
            redirect(BASE_URL . '/admin/bookings/view.php?id=' . $id . '&created=1');
        } else {
            $error = 'Failed to create booking. Please try again.';
        }
    }
}

$customers = $db->fetchAll("SELECT id, CONCAT(first_name,' ',last_name,' (',email,')') as label FROM users WHERE role_id=8 AND is_active=1 ORDER BY first_name");
$services  = $db->fetchAll("SELECT s.id, s.name, sc.name as cat FROM services s JOIN service_categories sc ON s.category_id=sc.id WHERE s.is_active=1 ORDER BY sc.sort_order, s.name");
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>New Booking – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div>
        <div class="header-title">New Booking</div>
        <div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> <a href="<?= BASE_URL ?>/admin/bookings/">Bookings</a> <span class="sep">/</span> New</div>
      </div>
    </div>
  </div>
  <div class="content-body">
    <div style="max-width:860px;margin:0 auto">
    <?php if ($error): ?><div class="alert alert-danger mb-3"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <div class="card mb-3">
        <div class="card-header"><h4><i class="fas fa-info-circle text-primary"></i> Booking Details</h4></div>
        <div class="card-body">
          <div class="form-row">
            <div class="form-group">
              <label>Customer *</label>
              <select name="customer_id" class="form-control" required>
                <option value="">Select Customer...</option>
                <?php foreach ($customers as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['label']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Service *</label>
              <select name="service_id" class="form-control" required id="serviceSelect">
                <option value="">Select Service...</option>
                <?php $lastCat=''; foreach ($services as $s): ?>
                <?php if ($s['cat']!==$lastCat): ?><optgroup label="<?= htmlspecialchars($s['cat']) ?>"><?php $lastCat=$s['cat']; endif; ?>
                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Event Date</label>
              <input type="date" name="event_date" class="form-control" min="<?= date('Y-m-d') ?>">
            </div>
            <div class="form-group">
              <label>Event Time</label>
              <input type="time" name="event_time" class="form-control">
            </div>
          </div>
          <div class="form-group">
            <label>Venue / Location</label>
            <input type="text" name="venue" class="form-control" placeholder="Event venue or location">
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Estimated Guests</label>
              <input type="number" name="guests_count" class="form-control" placeholder="0" min="0">
            </div>
            <div class="form-group">
              <label>Total Amount (TZS)</label>
              <input type="number" name="total_amount" class="form-control" placeholder="0" min="0" step="1000">
            </div>
          </div>
          <div class="form-group">
            <label>Special Requirements</label>
            <textarea name="special_requirements" class="form-control" rows="3" placeholder="Any special requirements or notes from the customer..."></textarea>
          </div>
          <div class="form-group">
            <label>Internal Notes</label>
            <textarea name="notes" class="form-control" rows="2" placeholder="Internal staff notes (not visible to customer)..."></textarea>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>Status</label>
              <select name="status" class="form-control">
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="in_progress">In Progress</option>
              </select>
            </div>
            <div class="form-group">
              <label>File Attachments</label>
              <div class="file-upload-area" style="border:2px dashed var(--border);border-radius:var(--radius-sm);padding:20px;text-align:center;cursor:pointer">
                <input type="file" name="attachments[]" multiple style="display:none" accept="image/*,.pdf,.zip,.doc,.docx">
                <i class="fas fa-cloud-upload-alt" style="font-size:1.5rem;color:var(--text-muted)"></i>
                <p class="file-upload-label text-muted" style="margin:8px 0 0;font-size:0.85rem">Click or drag files here</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="d-flex gap-2 justify-content-end">
        <a href="<?= BASE_URL ?>/admin/bookings/" class="btn" style="border:1px solid var(--border)">Cancel</a>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create Booking</button>
      </div>
    </form>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
