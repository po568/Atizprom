-- =====================================================
-- ATIZ PROM COMPANY MANAGEMENT SYSTEM
-- Complete Database Schema v1.0
-- =====================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

CREATE DATABASE IF NOT EXISTS `atizprom_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `atizprom_db`;

-- =====================================================
-- BRANCHES
-- =====================================================
CREATE TABLE `branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `location` varchar(255) NOT NULL,
  `address` text,
  `phone` varchar(20),
  `email` varchar(100),
  `manager_name` varchar(150),
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `branches` (`name`, `location`, `address`, `phone`, `email`, `manager_name`) VALUES
('Kyerwa Branch', 'Kyerwa, Kagera, Tanzania', 'Main Office, Kyerwa Town', '+255626296753', 'atizpromltd@gmail.com', 'Atiz Prom Management');

-- =====================================================
-- ROLES
-- =====================================================
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `slug` varchar(80) NOT NULL,
  `description` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `roles` (`name`, `slug`, `description`) VALUES
('Super Admin', 'super_admin', 'Full system access and management'),
('Admin', 'admin', 'Manage customers, services, bookings, quotations, projects'),
('Finance Officer', 'finance_officer', 'Revenue, invoice, and payment management'),
('Production Manager', 'production_manager', 'Film, photography, videography, event projects'),
('Graphic Designer', 'graphic_designer', 'Design requests and graphics projects'),
('Course Instructor', 'course_instructor', 'Course management and online classes'),
('Inventory Officer', 'inventory_officer', 'Product advertisements and office supplies catalog'),
('Customer', 'customer', 'Access own account only');

-- =====================================================
-- USERS
-- =====================================================
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL DEFAULT 8,
  `branch_id` int(11) DEFAULT 1,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20),
  `password` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `address` text,
  `city` varchar(100),
  `country` varchar(100) DEFAULT 'Tanzania',
  `is_active` tinyint(1) DEFAULT 1,
  `email_verified` tinyint(1) DEFAULT 0,
  `verification_token` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expires` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `login_attempts` int(11) DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `role_id` (`role_id`),
  KEY `branch_id` (`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default password for ALL seed accounts below: password
INSERT INTO `users` (`role_id`, `branch_id`, `first_name`, `last_name`, `email`, `phone`, `password`, `is_active`, `email_verified`) VALUES
(1, 1, 'Super', 'Admin', 'superadmin@atizprom.com', '+255700000001', '$2b$12$xK7u0AG8voAO6w3YJn/inOvY9Cm0Tw5mO4bbnr3lHjVgqUP5dvNLa', 1, 1),
(2, 1, 'Branch', 'Admin', 'admin@atizprom.com', '+255700000002', '$2b$12$xK7u0AG8voAO6w3YJn/inOvY9Cm0Tw5mO4bbnr3lHjVgqUP5dvNLa', 1, 1),
(3, 1, 'Finance', 'Officer', 'finance@atizprom.com', '+255700000003', '$2b$12$xK7u0AG8voAO6w3YJn/inOvY9Cm0Tw5mO4bbnr3lHjVgqUP5dvNLa', 1, 1),
(4, 1, 'Production', 'Manager', 'production@atizprom.com', '+255700000004', '$2b$12$xK7u0AG8voAO6w3YJn/inOvY9Cm0Tw5mO4bbnr3lHjVgqUP5dvNLa', 1, 1),
(5, 1, 'Grace', 'Designer', 'designer@atizprom.com', '+255700000005', '$2b$12$xK7u0AG8voAO6w3YJn/inOvY9Cm0Tw5mO4bbnr3lHjVgqUP5dvNLa', 1, 1),
(6, 1, 'Course', 'Instructor', 'instructor@atizprom.com', '+255700000006', '$2b$12$xK7u0AG8voAO6w3YJn/inOvY9Cm0Tw5mO4bbnr3lHjVgqUP5dvNLa', 1, 1),
(7, 1, 'Inventory', 'Officer', 'inventory@atizprom.com', '+255700000007', '$2b$12$xK7u0AG8voAO6w3YJn/inOvY9Cm0Tw5mO4bbnr3lHjVgqUP5dvNLa', 1, 1),
(8, 1, 'Demo', 'Customer', 'customer@demo.com', '+255700000099', '$2b$12$xK7u0AG8voAO6w3YJn/inOvY9Cm0Tw5mO4bbnr3lHjVgqUP5dvNLa', 1, 1);

-- =====================================================
-- AUDIT LOGS
-- =====================================================
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `table_name` varchar(100),
  `record_id` int(11),
  `old_values` text,
  `new_values` text,
  `ip_address` varchar(45),
  `user_agent` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- LOGIN LOGS
-- =====================================================
CREATE TABLE `login_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `email` varchar(150),
  `status` enum('success','failed','locked') NOT NULL,
  `ip_address` varchar(45),
  `user_agent` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- SERVICES
-- =====================================================
CREATE TABLE `service_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `icon` varchar(100),
  `description` text,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `service_categories` (`name`, `slug`, `icon`, `description`, `sort_order`) VALUES
('Photography', 'photography', 'fa-camera', 'Professional photography services for all occasions', 1),
('Videography', 'videography', 'fa-video', 'High quality video production and editing', 2),
('Film Production', 'film-production', 'fa-film', 'Full scale movie and film production services', 3),
('Graphics Design', 'graphics-design', 'fa-palette', 'Creative graphic design for brands and businesses', 4),
('Events Coverage', 'events-coverage', 'fa-calendar-star', 'Complete event media coverage services', 5),
('Computer Courses', 'computer-courses', 'fa-laptop-code', 'Professional IT and computer training courses', 6),
('Technology Services', 'technology-services', 'fa-microchip', 'IT solutions and technology services', 7),
('Stationery & Supplies', 'stationery-supplies', 'fa-box-open', 'Office stationery and supply advertisements', 8);

CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `description` text,
  `price_from` decimal(12,2) DEFAULT NULL,
  `price_to` decimal(12,2) DEFAULT NULL,
  `price_label` varchar(100) DEFAULT 'Starting from',
  `duration` varchar(100),
  `image` varchar(255),
  `features` text,
  `is_active` tinyint(1) DEFAULT 1,
  `is_featured` tinyint(1) DEFAULT 0,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `services` (`category_id`, `name`, `slug`, `description`, `price_from`, `price_label`, `duration`, `is_featured`) VALUES
(1, 'Wedding Photography', 'wedding-photography', 'Professional wedding photography coverage', 500000, 'Starting from TZS', '1 Day', 1),
(1, 'Graduation Photography', 'graduation-photography', 'Memorable graduation photo sessions', 150000, 'Starting from TZS', '2-3 Hours', 1),
(1, 'Corporate Photography', 'corporate-photography', 'Professional corporate and business photography', 300000, 'Starting from TZS', '4 Hours', 0),
(1, 'Product Photography', 'product-photography', 'High quality product photography for marketing', 100000, 'Starting from TZS', '2 Hours', 0),
(1, 'Studio Photography', 'studio-photography', 'Professional studio photo sessions', 80000, 'Starting from TZS', '1 Hour', 0),
(1, 'Event Photography', 'event-photography', 'Full event photography coverage', 250000, 'Starting from TZS', 'Per Event', 0),
(2, 'Wedding Videography', 'wedding-videography', 'Cinematic wedding video production', 800000, 'Starting from TZS', '1 Day', 1),
(2, 'Documentary Production', 'documentary-production', 'Professional documentary film production', 1500000, 'Starting from TZS', 'Custom', 0),
(2, 'Music Videos', 'music-videos', 'Creative music video production', 500000, 'Starting from TZS', '1-2 Days', 1),
(2, 'Commercial Videos', 'commercial-videos', 'Business and commercial video production', 600000, 'Starting from TZS', '1-2 Days', 0),
(2, 'Corporate Videos', 'corporate-videos', 'Professional corporate video content', 400000, 'Starting from TZS', '1 Day', 0),
(2, 'Social Media Videos', 'social-media-videos', 'Engaging social media video content', 150000, 'Starting from TZS', 'Per Video', 0),
(3, 'Movie Production', 'movie-production', 'Full scale movie and film production', 5000000, 'Starting from TZS', 'Custom', 1),
(3, 'Film Shooting', 'film-shooting', 'Professional film shooting services', 1000000, 'Starting from TZS', 'Custom', 0),
(3, 'Film Editing', 'film-editing', 'Professional film post-production editing', 500000, 'Starting from TZS', 'Custom', 0),
(4, 'Logo Design', 'logo-design', 'Professional brand logo design', 80000, 'Starting from TZS', '3-5 Days', 1),
(4, 'Poster Design', 'poster-design', 'Eye-catching poster and banner design', 50000, 'Starting from TZS', '1-2 Days', 0),
(4, 'Branding Package', 'branding-package', 'Complete brand identity package', 300000, 'Starting from TZS', '1-2 Weeks', 1),
(4, 'Social Media Designs', 'social-media-designs', 'Social media graphics and content', 100000, 'Starting from TZS', 'Per Package', 0),
(5, 'Wedding Coverage', 'wedding-coverage', 'Complete wedding photo and video coverage', 1200000, 'Starting from TZS', '1 Day', 1),
(5, 'Conference Coverage', 'conference-coverage', 'Professional conference media coverage', 400000, 'Starting from TZS', 'Per Day', 0),
(5, 'Concert Coverage', 'concert-coverage', 'Live concert and performance coverage', 500000, 'Starting from TZS', 'Per Event', 0);

-- =====================================================
-- BOOKINGS
-- =====================================================
CREATE TABLE `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_number` varchar(20) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT 1,
  `assigned_staff_id` int(11) DEFAULT NULL,
  `booking_date` date NOT NULL,
  `booking_time` time DEFAULT NULL,
  `event_date` date,
  `event_time` time,
  `venue` varchar(255),
  `guests_count` int(11),
  `special_requirements` text,
  `file_attachments` text,
  `status` enum('pending','confirmed','in_progress','completed','cancelled') DEFAULT 'pending',
  `total_amount` decimal(12,2) DEFAULT NULL,
  `paid_amount` decimal(12,2) DEFAULT 0,
  `notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `booking_number` (`booking_number`),
  KEY `customer_id` (`customer_id`),
  KEY `service_id` (`service_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- QUOTATIONS
-- =====================================================
CREATE TABLE `quotations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation_number` varchar(20) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `service_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT 1,
  `title` varchar(255) NOT NULL,
  `description` text,
  `items` longtext,
  `subtotal` decimal(12,2) DEFAULT 0,
  `discount` decimal(12,2) DEFAULT 0,
  `tax` decimal(12,2) DEFAULT 0,
  `total` decimal(12,2) DEFAULT 0,
  `valid_until` date,
  `status` enum('draft','sent','accepted','rejected','approved','expired') DEFAULT 'draft',
  `customer_notes` text,
  `admin_notes` text,
  `file_attachments` text,
  `created_by` int(11),
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quotation_number` (`quotation_number`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- PROJECTS
-- =====================================================
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_number` varchar(20) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `quotation_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT 1,
  `manager_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `category` varchar(100),
  `start_date` date,
  `end_date` date,
  `deadline` date,
  `progress` int(11) DEFAULT 0,
  `status` enum('pending','approved','in_progress','review','completed','delivered','cancelled') DEFAULT 'pending',
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `budget` decimal(12,2),
  `paid_amount` decimal(12,2) DEFAULT 0,
  `notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_number` (`project_number`),
  KEY `customer_id` (`customer_id`),
  KEY `manager_id` (`manager_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `project_milestones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `due_date` date,
  `status` enum('pending','in_progress','completed') DEFAULT 'pending',
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `project_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) NOT NULL,
  `uploaded_by` int(11),
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(100),
  `file_size` int(11),
  `description` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- PAYMENTS / INVOICES
-- =====================================================
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(20) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `quotation_id` int(11) DEFAULT NULL,
  `enrollment_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT 1,
  `items` longtext,
  `subtotal` decimal(12,2) DEFAULT 0,
  `discount` decimal(12,2) DEFAULT 0,
  `tax` decimal(12,2) DEFAULT 0,
  `total` decimal(12,2) DEFAULT 0,
  `amount_paid` decimal(12,2) DEFAULT 0,
  `balance` decimal(12,2) DEFAULT 0,
  `due_date` date,
  `status` enum('draft','sent','partial','paid','overdue','cancelled') DEFAULT 'draft',
  `notes` text,
  `created_by` int(11),
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_method` enum('cash','mpesa','airtel_money','tigo_pesa','halopesa','bank_transfer') DEFAULT 'cash',
  `transaction_ref` varchar(100),
  `payment_date` date NOT NULL,
  `status` enum('pending','confirmed','failed','refunded') DEFAULT 'confirmed',
  `notes` text,
  `confirmed_by` int(11),
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- COURSES
-- =====================================================
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instructor_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT 1,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text,
  `category` enum('computer_basics','microsoft_office','graphic_design','web_development','video_editing','networking','programming','digital_marketing') NOT NULL,
  `mode` enum('online','offline','hybrid') DEFAULT 'offline',
  `duration` varchar(100),
  `price` decimal(12,2) DEFAULT 0,
  `max_students` int(11) DEFAULT 30,
  `thumbnail` varchar(255),
  `syllabus` text,
  `requirements` text,
  `certificate_template` varchar(255),
  `is_active` tinyint(1) DEFAULT 1,
  `is_featured` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `instructor_id` (`instructor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `courses` (`instructor_id`, `title`, `slug`, `description`, `category`, `mode`, `duration`, `price`, `max_students`, `is_active`, `is_featured`) VALUES
(NULL, 'Computer Basics for Beginners', 'computer-basics', 'Learn the fundamentals of computer usage and operation', 'computer_basics', 'offline', '4 Weeks', 80000, 25, 1, 1),
(NULL, 'Microsoft Office Mastery', 'microsoft-office-mastery', 'Complete Microsoft Office Suite training (Word, Excel, PowerPoint)', 'microsoft_office', 'hybrid', '6 Weeks', 120000, 20, 1, 1),
(NULL, 'Graphic Design with Photoshop & Illustrator', 'graphic-design-ps', 'Professional graphic design using industry-standard tools', 'graphic_design', 'offline', '8 Weeks', 200000, 15, 1, 1),
(NULL, 'Web Development Fundamentals', 'web-development', 'HTML, CSS, and JavaScript for beginners', 'web_development', 'online', '10 Weeks', 250000, 30, 1, 1),
(NULL, 'Video Editing with Premiere Pro', 'video-editing', 'Professional video editing from beginner to advanced', 'video_editing', 'offline', '6 Weeks', 180000, 15, 1, 0),
(NULL, 'Digital Marketing Essentials', 'digital-marketing', 'Social media marketing, SEO and digital advertising', 'digital_marketing', 'online', '8 Weeks', 150000, 30, 1, 1);

CREATE TABLE `course_enrollments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `enrollment_number` varchar(20) NOT NULL,
  `status` enum('pending','admin_approved','active','completed','dropped','suspended') DEFAULT 'pending',
  `admin_approved` tinyint(1) DEFAULT 0,
  `admin_approved_by` int(11) DEFAULT NULL,
  `admin_approved_at` datetime DEFAULT NULL,
  `finance_approved` tinyint(1) DEFAULT 0,
  `finance_approved_by` int(11) DEFAULT NULL,
  `finance_approved_at` datetime DEFAULT NULL,
  `progress` int(11) DEFAULT 0,
  `payment_status` enum('unpaid','partial','paid') DEFAULT 'unpaid',
  `amount_paid` decimal(12,2) DEFAULT 0,
  `enrolled_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` datetime DEFAULT NULL,
  `certificate_issued` tinyint(1) DEFAULT 0,
  `certificate_number` varchar(50),
  PRIMARY KEY (`id`),
  UNIQUE KEY `enrollment_number` (`enrollment_number`),
  KEY `course_id` (`course_id`),
  KEY `student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `course_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `file_path` varchar(255) NOT NULL,
  `file_type` varchar(50),
  `uploaded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`),
  KEY `lesson_id` (`lesson_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `course_lessons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `content` longtext,
  `video_url` varchar(500),
  `file_attachment` varchar(255),
  `duration_minutes` int(11) DEFAULT 0,
  `scheduled_date` date DEFAULT NULL,
  `scheduled_time` time DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `course_id` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `course_assignments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `lesson_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `due_date` datetime,
  `max_score` int(11) DEFAULT 100,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `assignment_submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assignment_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `file_path` varchar(500),
  `notes` text,
  `score` int(11) DEFAULT NULL,
  `feedback` text,
  `status` enum('submitted','graded') DEFAULT 'submitted',
  `submitted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `graded_at` datetime DEFAULT NULL,
  `graded_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assignment_id` (`assignment_id`),
  KEY `student_id` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `quizzes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `duration_minutes` int(11) DEFAULT 60,
  `pass_score` int(11) DEFAULT 70,
  `max_attempts` int(11) DEFAULT 3,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `quiz_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) NOT NULL,
  `question` text NOT NULL,
  `option_a` varchar(500),
  `option_b` varchar(500),
  `option_c` varchar(500),
  `option_d` varchar(500),
  `correct_answer` enum('a','b','c','d') NOT NULL,
  `explanation` text,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `quiz_id` (`quiz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `quiz_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quiz_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `answers` longtext,
  `score` int(11),
  `percentage` decimal(5,2),
  `passed` tinyint(1),
  `started_at` datetime,
  `completed_at` datetime,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- PRODUCTS (Advertisement Catalog)
-- =====================================================
CREATE TABLE `product_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `description` text,
  `image` varchar(255),
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `product_categories` (`name`, `slug`, `description`, `sort_order`) VALUES
('Office Supplies', 'office-supplies', 'Professional office supplies and equipment', 1),
('Stationery', 'stationery', 'Writing materials, notebooks, and stationery', 2),
('Technology Products', 'technology-products', 'Computers, accessories, and tech gadgets', 3),
('Printing Materials', 'printing-materials', 'Printing paper, ink, toners and related materials', 4);

CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT 1,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text,
  `price` decimal(12,2) NOT NULL,
  `unit` varchar(50) DEFAULT 'piece',
  `sku` varchar(100),
  `stock_status` enum('in_stock','out_of_stock','limited') DEFAULT 'in_stock',
  `quantity_in_stock` int(11) DEFAULT 0,
  `images` text,
  `specifications` text,
  `is_active` tinyint(1) DEFAULT 1,
  `is_featured` tinyint(1) DEFAULT 0,
  `views` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `products` (`category_id`, `name`, `slug`, `description`, `price`, `unit`, `sku`, `stock_status`, `is_featured`) VALUES
(1, 'Executive Office Chair', 'executive-office-chair', 'Comfortable and ergonomic office chair for long working hours', 350000, 'piece', 'OFC-001', 'in_stock', 1),
(1, 'Office Desk - Standard', 'office-desk-standard', 'Durable standard office desk with drawer compartment', 450000, 'piece', 'OFD-001', 'in_stock', 1),
(1, 'File Cabinet (4 Drawer)', 'file-cabinet-4-drawer', 'Steel file cabinet with 4 drawers and lock', 280000, 'piece', 'OFC-002', 'in_stock', 0),
(2, 'A4 Printing Paper (500 sheets)', 'a4-paper-ream', 'High quality A4 80gsm printing paper', 12000, 'ream', 'STN-001', 'in_stock', 1),
(2, 'Ballpoint Pens - Blue (Box)', 'ballpoint-pens-blue-box', 'Box of 50 ballpoint pens - blue ink', 8000, 'box', 'STN-002', 'in_stock', 0),
(2, 'Spiral Notebooks A4', 'spiral-notebooks-a4', 'A4 spiral bound notebook 100 pages', 4500, 'piece', 'STN-003', 'in_stock', 0),
(3, 'HP Laptop 15-inch', 'hp-laptop-15', 'HP laptop with Intel Core i5, 8GB RAM, 512GB SSD', 1850000, 'piece', 'TECH-001', 'in_stock', 1),
(3, 'Wireless Mouse', 'wireless-mouse', 'Ergonomic wireless mouse with USB receiver', 35000, 'piece', 'TECH-002', 'in_stock', 0),
(3, 'USB Flash Drive 32GB', 'usb-flash-32gb', 'High speed USB 3.0 flash drive 32GB', 15000, 'piece', 'TECH-003', 'in_stock', 0),
(4, 'Ink Cartridge - Black', 'ink-cartridge-black', 'Compatible ink cartridge for HP printers - black', 45000, 'piece', 'PRN-001', 'in_stock', 0),
(4, 'Glossy Photo Paper A4', 'glossy-photo-paper-a4', '220gsm glossy photo paper A4 (50 sheets)', 28000, 'pack', 'PRN-002', 'in_stock', 1);

CREATE TABLE `inventory_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `item_name` varchar(255) NOT NULL,
  `movement_type` enum('stock_in','stock_out','adjustment','damaged','returned') NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_cost` decimal(12,2) DEFAULT NULL,
  `supplier` varchar(150),
  `reference` varchar(100),
  `notes` text,
  `recorded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- PORTFOLIO
-- =====================================================
CREATE TABLE `portfolio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` enum('photography','videography','films','graphics_design','events_coverage') NOT NULL,
  `branch_id` int(11) DEFAULT 1,
  `title` varchar(255) NOT NULL,
  `description` text,
  `client_name` varchar(150),
  `project_date` date,
  `thumbnail` varchar(255),
  `images` text,
  `video_url` varchar(500),
  `tags` varchar(500),
  `is_featured` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `views` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `portfolio` (`category`, `title`, `description`, `client_name`, `project_date`, `is_featured`) VALUES
('photography', 'Mwamba & Sonia Wedding', 'Elegant wedding photography in Kyerwa capturing beautiful moments of love and joy', 'Mwamba Family', '2024-06-15', 1),
('photography', 'Graduation Ceremony 2024', 'University graduation ceremony photography session', 'Kagera University', '2024-07-20', 1),
('videography', 'Corporate Brand Film', 'High quality corporate brand promotional video', 'Kagera Business Center', '2024-08-10', 1),
('films', 'Habari za Nyumbani - Short Film', 'A touching short film about family and community values', 'Atiz Prom Productions', '2024-05-01', 1),
('graphics_design', 'Brand Identity Package', 'Complete brand identity design for local business', 'Kyerwa Traders', '2024-09-05', 1),
('events_coverage', 'Annual Conference Coverage', 'Full media coverage of regional business conference', 'Kagera Chamber of Commerce', '2024-10-12', 1);

-- =====================================================
-- SUPPORT TICKETS
-- =====================================================
CREATE TABLE `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_number` varchar(20) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `category` enum('inquiry','complaint','technical','billing','other') DEFAULT 'inquiry',
  `priority` enum('low','normal','high','urgent') DEFAULT 'normal',
  `status` enum('open','in_progress','resolved','closed') DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `closed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ticket_number` (`ticket_number`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `ticket_replies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_internal` tinyint(1) DEFAULT 0,
  `attachments` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- CHAT
-- =====================================================
CREATE TABLE `chat_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `status` enum('waiting','active','closed') DEFAULT 'waiting',
  `started_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ended_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- CONTRACTS
-- =====================================================
CREATE TABLE `contracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_number` varchar(20) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `project_id` int(11) DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `value` decimal(12,2),
  `start_date` date,
  `end_date` date,
  `status` enum('draft','sent','signed','expired','cancelled') DEFAULT 'draft',
  `customer_signature` text,
  `admin_signature` text,
  `customer_signed_at` datetime DEFAULT NULL,
  `admin_signed_at` datetime DEFAULT NULL,
  `created_by` int(11),
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contract_number` (`contract_number`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- TESTIMONIALS
-- =====================================================
CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `author_name` varchar(150) NOT NULL,
  `author_title` varchar(150),
  `content` text NOT NULL,
  `rating` tinyint(1) DEFAULT 5,
  `is_approved` tinyint(1) DEFAULT 0,
  `is_featured` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `testimonials` (`author_name`, `author_title`, `content`, `rating`, `is_approved`, `is_featured`) VALUES
('Amina Hassan', 'Bride', 'Atiz Prom captured our wedding day perfectly. Every moment was beautifully preserved. We are so grateful!', 5, 1, 1),
('John Mwangi', 'Business Owner', 'The branding package they created for my business transformed our image. Very professional team!', 5, 1, 1),
('Prof. Sarah Kileo', 'University Lecturer', 'Excellent photography service for our graduation ceremony. Very organized and professional.', 5, 1, 1),
('David Omondi', 'Event Organizer', 'They covered our conference flawlessly. High quality photos and videos delivered on time.', 5, 1, 1);

-- =====================================================
-- TEAM MEMBERS
-- =====================================================
CREATE TABLE `team_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `position` varchar(150) NOT NULL,
  `bio` text,
  `photo` varchar(255),
  `email` varchar(150),
  `phone` varchar(20),
  `branch_id` int(11) DEFAULT 1,
  `social_links` text,
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- NOTIFICATIONS
-- =====================================================
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(50) DEFAULT 'info',
  `link` varchar(500),
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- SETTINGS
-- =====================================================
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text,
  `setting_group` varchar(100) DEFAULT 'general',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_group`) VALUES
('site_name', 'Atiz Prom', 'general'),
('site_slogan', 'Atiz Prom – Home of All Tech Solutions', 'general'),
('site_email', 'atizpromltd@gmail.com', 'general'),
('site_phone', '+255626296753', 'general'),
('site_address', 'Kyerwa, Kagera, Tanzania', 'general'),
('currency', 'TZS', 'financial'),
('currency_symbol', 'TZS', 'financial'),
('tax_rate', '18', 'financial'),
('smtp_host', 'smtp.gmail.com', 'email'),
('smtp_port', '587', 'email'),
('smtp_user', 'atizpromltd@gmail.com', 'email'),
('smtp_pass', '', 'email'),
('smtp_from_name', 'Atiz Prom', 'email'),
('facebook_url', 'https://facebook.com/AtizPromArts', 'social'),
('instagram_url', 'https://instagram.com/atiz_prom', 'social'),
('tiktok_url', 'https://tiktok.com/@atizpromarts', 'social'),
('youtube_url', 'https://youtube.com/@AtizPromArts', 'social'),
('maintenance_mode', '0', 'general'),
('allow_registration', '1', 'general');

-- =====================================================
-- FOREIGN KEYS
-- =====================================================
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  ADD CONSTRAINT `fk_users_branch` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`);

ALTER TABLE `bookings`
  ADD CONSTRAINT `fk_bookings_customer` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `fk_bookings_service` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`);

ALTER TABLE `quotations`
  ADD CONSTRAINT `fk_quotations_customer` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`);

ALTER TABLE `projects`
  ADD CONSTRAINT `fk_projects_customer` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`);

ALTER TABLE `tickets`
  ADD CONSTRAINT `fk_tickets_customer` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`);

ALTER TABLE `course_enrollments`
  ADD CONSTRAINT `fk_enrollments_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  ADD CONSTRAINT `fk_enrollments_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`);

COMMIT;
