// =====================================================
// ATIZ PROM - Home Page JavaScript
// =====================================================

document.addEventListener('DOMContentLoaded', () => {
  initPortfolioFilter();
  initScrollAnimations();
  initCounters();
});

// ===== PORTFOLIO FILTER =====
function initPortfolioFilter() {
  const btns = document.querySelectorAll('.filter-btn');
  const items = document.querySelectorAll('.portfolio-item');
  if (!btns.length) return;

  btns.forEach(btn => {
    btn.addEventListener('click', () => {
      btns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.dataset.filter;
      items.forEach(item => {
        if (filter === 'all' || item.dataset.category === filter) {
          item.style.display = 'block';
          item.style.animation = 'fadeIn 0.4s ease';
        } else {
          item.style.display = 'none';
        }
      });
    });
  });
}

// ===== SCROLL ANIMATIONS =====
function initScrollAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animated');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('[data-aos], .service-card, .course-card, .feature-item').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
  });

  // Add animated class styles
  const style = document.createElement('style');
  style.textContent = `.animated { opacity: 1 !important; transform: translateY(0) !important; }
  @keyframes fadeIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }`;
  document.head.appendChild(style);
}

// ===== COUNTER ANIMATION =====
function initCounters() {
  const counters = document.querySelectorAll('.stat strong');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  counters.forEach(el => observer.observe(el));
}

function animateCounter(el) {
  const text = el.textContent;
  const num = parseInt(text.replace(/\D/g, ''));
  const suffix = text.replace(/[\d]/g, '');
  if (!num) return;
  let start = 0;
  const duration = 1500;
  const step = Math.ceil(num / (duration / 16));
  const timer = setInterval(() => {
    start = Math.min(start + step, num);
    el.textContent = start + suffix;
    if (start >= num) clearInterval(timer);
  }, 16);
}
