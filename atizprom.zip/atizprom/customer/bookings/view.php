<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/customer/login.php');
$user = $auth->getCurrentUser();
if ($user['role_slug'] !== 'customer') redirect(BASE_URL . '/admin/');

$db = Database::getInstance();
$id = (int)($_GET['id'] ?? 0);
$booking = $db->fetchOne("SELECT b.*, s.name as service_name, sc.name as category FROM bookings b JOIN services s ON b.service_id=s.id JOIN service_categories sc ON s.category_id=sc.id WHERE b.id=? AND b.customer_id=?", [$id, $user['id']]);
if (!$booking) redirect(BASE_URL . '/customer/bookings/');

$attachments = $booking['file_attachments'] ? json_decode($booking['file_attachments'], true) : [];

$statusSteps = ['pending','confirmed','in_progress','completed'];
$currentStepIndex = array_search($booking['status'], $statusSteps);
if ($currentStepIndex === false) $currentStepIndex = -1;
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Booking <?= $booking['booking_number'] ?> – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/customer.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<?php include BASE_PATH . '/customer/includes/header.php'; ?>
<div class="customer-layout">
  <?php include BASE_PATH . '/customer/includes/sidebar.php'; ?>
  <main class="customer-main">
    <div class="customer-content" style="max-width:800px">
      <a href="<?= BASE_URL ?>/customer/bookings/" class="customer-breadcrumb" style="display:inline-block"><i class="fas fa-arrow-left"></i> Back to Bookings</a>

      <div class="d-flex align-items-center justify-content-between mt-3 mb-4">
        <div>
          <h2 style="margin-bottom:4px"><?= htmlspecialchars($booking['service_name']) ?></h2>
          <p class="text-muted" style="margin:0">Booking #<?= $booking['booking_number'] ?> · <?= htmlspecialchars($booking['category']) ?></p>
        </div>
        <?= getStatusBadge($booking['status']) ?>
      </div>

      <?php if ($booking['status'] !== 'cancelled'): ?>
      <!-- Progress Timeline -->
      <div class="card mb-4">
        <div class="card-body">
          <div style="display:flex;justify-content:space-between;position:relative">
            <div style="position:absolute;top:14px;left:5%;right:5%;height:3px;background:var(--border);z-index:0"></div>
            <div style="position:absolute;top:14px;left:5%;height:3px;background:var(--blue);z-index:1;width:<?= $currentStepIndex>=0 ? ($currentStepIndex/(count($statusSteps)-1))*90 : 0 ?>%"></div>
            <?php foreach ($statusSteps as $i => $step): ?>
            <div style="text-align:center;flex:1;position:relative;z-index:2">
              <div style="width:30px;height:30px;border-radius:50%;background:<?= $i<=$currentStepIndex?'var(--blue)':'var(--border)' ?>;color:#fff;display:flex;align-items:center;justify-content:center;margin:0 auto 8px;font-size:0.8rem">
                <?php if ($i < $currentStepIndex): ?><i class="fas fa-check"></i><?php else: ?><?= $i+1 ?><?php endif; ?>
              </div>
              <small style="font-size:0.75rem;color:<?= $i<=$currentStepIndex?'var(--blue)':'var(--text-muted)' ?>;font-weight:600"><?= ucfirst(str_replace('_',' ',$step)) ?></small>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <?php endif; ?>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
        <div class="card">
          <div class="card-header"><h4>Booking Information</h4></div>
          <div class="card-body">
            <div style="display:flex;flex-direction:column;gap:12px;font-size:0.9rem">
              <div class="d-flex justify-content-between"><span class="text-muted">Event Date</span><strong><?= $booking['event_date']?formatDate($booking['event_date']):'TBD' ?></strong></div>
              <div class="d-flex justify-content-between"><span class="text-muted">Event Time</span><strong><?= $booking['event_time']?date('H:i',strtotime($booking['event_time'])):'TBD' ?></strong></div>
              <div class="d-flex justify-content-between"><span class="text-muted">Venue</span><strong><?= htmlspecialchars($booking['venue'] ?: 'Not specified') ?></strong></div>
              <div class="d-flex justify-content-between"><span class="text-muted">Guests</span><strong><?= $booking['guests_count'] ?: 'Not specified' ?></strong></div>
              <div class="d-flex justify-content-between"><span class="text-muted">Booked On</span><strong><?= formatDate($booking['created_at']) ?></strong></div>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-header"><h4>Payment Information</h4></div>
          <div class="card-body">
            <div style="display:flex;flex-direction:column;gap:12px;font-size:0.9rem">
              <div class="d-flex justify-content-between"><span class="text-muted">Total Amount</span><strong><?= $booking['total_amount']?formatCurrency($booking['total_amount']):'Pending Quote' ?></strong></div>
              <div class="d-flex justify-content-between"><span class="text-muted">Paid Amount</span><strong style="color:#155724"><?= formatCurrency($booking['paid_amount']) ?></strong></div>
              <div class="d-flex justify-content-between"><span class="text-muted">Balance</span><strong style="color:#721C24"><?= formatCurrency(($booking['total_amount']??0) - $booking['paid_amount']) ?></strong></div>
            </div>
            <div style="margin-top:16px;padding-top:16px;border-top:1px solid var(--border)">
              <small class="text-muted">Accepted payment methods:</small>
              <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap">
                <span class="badge badge-light">Cash</span>
                <span class="badge badge-light">M-Pesa</span>
                <span class="badge badge-light">Airtel Money</span>
                <span class="badge badge-light">Tigo Pesa</span>
                <span class="badge badge-light">Bank Transfer</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <?php if ($booking['special_requirements']): ?>
      <div class="card mt-3">
        <div class="card-header"><h4>Special Requirements</h4></div>
        <div class="card-body"><p><?= nl2br(htmlspecialchars($booking['special_requirements'])) ?></p></div>
      </div>
      <?php endif; ?>

      <?php if (!empty($attachments)): ?>
      <div class="card mt-3">
        <div class="card-header"><h4>Attachments</h4></div>
        <div class="card-body">
          <?php foreach ($attachments as $a): ?>
          <a href="<?= UPLOAD_URL . $a ?>" target="_blank" class="d-flex align-items-center gap-2" style="padding:8px 0;border-bottom:1px solid var(--border)">
            <i class="fas fa-paperclip text-primary"></i> <?= basename($a) ?>
          </a>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <div class="d-flex gap-2 justify-content-end mt-4">
        <a href="<?= BASE_URL ?>/customer/tickets/" class="btn" style="border:1px solid var(--border)"><i class="fas fa-headset"></i> Need Help?</a>
        <?php if (in_array($booking['status'], ['pending'])): ?>
        <button class="btn btn-danger" onclick="if(confirm('Cancel this booking?')) alert('Please contact support to cancel this booking.')"><i class="fas fa-times"></i> Cancel Booking</button>
        <?php endif; ?>
      </div>
    </div>
  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
</body>
</html>
