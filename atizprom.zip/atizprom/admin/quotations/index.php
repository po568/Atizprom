<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','finance_officer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();

// Handle quote response (admin sends price)
if (isPost() && isset($_POST['action']) && $_POST['action']==='send_quote') {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $qid = (int)$_POST['quotation_id'];
        $total = (float)$_POST['total'];
        $db->execute("UPDATE quotations SET total=?, subtotal=?, admin_notes=?, status='sent', created_by=? WHERE id=?",
            [$total,$total,$_POST['admin_notes']??null,$user['id'],$qid]);
        $q = $db->fetchOne("SELECT * FROM quotations WHERE id=?", [$qid]);
        $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
            [$q['customer_id'],'Quotation Ready',"Your quotation #{$q['quotation_number']} is ready for review.",'quotation',BASE_URL.'/customer/quotations/view.php?id='.$qid]);
        redirect(BASE_URL.'/admin/quotations/?sent=1');
    }
}

// Handle final approval — only admin can lock in a quotation the customer has accepted
if (isPost() && isset($_POST['action']) && $_POST['action']==='final_approve') {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $qid = (int)$_POST['quotation_id'];
        $q = $db->fetchOne("SELECT * FROM quotations WHERE id=? AND status='accepted'", [$qid]);
        if ($q) {
            $db->execute("UPDATE quotations SET status='approved' WHERE id=?", [$qid]);
            $auth->logAudit($user['id'], 'QUOTATION_FINAL_APPROVED', 'quotations', $qid);
            $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                [$q['customer_id'], 'Quotation Approved', "Your quotation #{$q['quotation_number']} has been fully approved by Atiz Prom. We'll be in touch to begin work.", 'quotation', BASE_URL.'/customer/quotations/view.php?id='.$qid]);
            redirect(BASE_URL.'/admin/quotations/?approved=1');
        }
    }
}

$status = $_GET['status'] ?? '';
$where = ['1=1']; $params=[]; $types='';
if ($status) { $where[]='q.status=?'; $params[]=$status; $types.='s'; }

$quotations = $db->fetchAll("SELECT q.*, CONCAT(u.first_name,' ',u.last_name) as customer_name, u.email FROM quotations q JOIN users u ON q.customer_id=u.id WHERE ".implode(' AND ',$where)." ORDER BY q.created_at DESC", $params, $types);
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Quotations – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Quotations</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Quotations</div></div>
    </div>
  </div>
  <div class="content-body">
    <?php if (isset($_GET['sent'])): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> Quotation sent to customer!</div><?php endif; ?>
    <?php if (isset($_GET['approved'])): ?><div class="alert alert-success mb-3"><i class="fas fa-check-circle"></i> Quotation fully approved!</div><?php endif; ?>
    <div class="card">
      <div class="card-body">
        <div class="dt-toolbar">
          <div class="dt-filters">
            <a href="?" class="btn btn-sm <?= !$status?'btn-primary':'btn-outline-primary' ?>">All</a>
            <?php foreach (['draft'=>'Draft','sent'=>'Sent','accepted'=>'Accepted','approved'=>'Approved','rejected'=>'Rejected','expired'=>'Expired'] as $k=>$v): ?>
            <a href="?status=<?= $k ?>" class="btn btn-sm <?= $status===$k?'btn-primary':'btn-outline-primary' ?>"><?= $v ?></a>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><th>Quote #</th><th>Customer</th><th>Title</th><th>Amount</th><th>Valid Until</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              <?php foreach ($quotations as $q): ?>
              <tr>
                <td><strong style="color:var(--blue)"><?= $q['quotation_number'] ?></strong></td>
                <td><?= htmlspecialchars($q['customer_name']) ?><br><small class="text-muted"><?= htmlspecialchars($q['email']) ?></small></td>
                <td><?= htmlspecialchars($q['title']) ?></td>
                <td><?= $q['total']>0 ? formatCurrency($q['total']) : '<span class="text-muted">Pending</span>' ?></td>
                <td><?= $q['valid_until'] ? formatDate($q['valid_until']) : '-' ?></td>
                <td><?= getStatusBadge($q['status']) ?></td>
                <td>
                  <div class="d-flex gap-1">
                    <button onclick="viewQuote(<?= htmlspecialchars(json_encode($q)) ?>)" class="btn btn-sm btn-outline-primary"><i class="fas fa-eye"></i></button>
                    <?php if ($q['status']==='draft' || ($q['total']==0 && $q['status'] !== 'accepted')): ?>
                    <button onclick="openSendQuote(<?= $q['id'] ?>, '<?= addslashes($q['customer_name']) ?>')" class="btn btn-sm btn-primary"><i class="fas fa-paper-plane"></i></button>
                    <?php endif; ?>
                    <?php if ($q['status']==='accepted'): ?>
                    <form method="POST" style="display:inline" onsubmit="return confirm('Give final approval for this quotation? This locks in the agreement.')">
                      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
                      <input type="hidden" name="action" value="final_approve">
                      <input type="hidden" name="quotation_id" value="<?= $q['id'] ?>">
                      <button type="submit" class="btn btn-sm btn-success" title="Final Approve"><i class="fas fa-check-double"></i></button>
                    </form>
                    <?php endif; ?>
                    <?php if ($q['status']==='approved'): ?>
                    <a href="<?= BASE_URL ?>/admin/invoices/create.php?quotation_id=<?= $q['id'] ?>" class="btn btn-sm btn-primary" title="Create Invoice"><i class="fas fa-file-invoice-dollar"></i></a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($quotations)): ?>
              <tr><td colspan="7" class="text-center text-muted" style="padding:40px">No quotation requests yet</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>

<!-- View Modal -->
<div class="modal-overlay" id="viewQuoteModal">
  <div class="modal" style="max-width:600px">
    <div class="modal-header"><h4 id="viewQuoteTitle">Quotation Details</h4><button class="modal-close" onclick="AtizProm.closeModal('viewQuoteModal')"><i class="fas fa-times"></i></button></div>
    <div class="modal-body" id="viewQuoteBody"></div>
  </div>
</div>

<!-- Send Quote Modal -->
<div class="modal-overlay" id="sendQuoteModal">
  <div class="modal">
    <div class="modal-header"><h4>Send Price Quotation</h4><button class="modal-close" onclick="AtizProm.closeModal('sendQuoteModal')"><i class="fas fa-times"></i></button></div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
        <input type="hidden" name="action" value="send_quote">
        <input type="hidden" name="quotation_id" id="sq_id">
        <p>Sending quotation to: <strong id="sq_customer"></strong></p>
        <div class="form-group">
          <label>Total Amount (TZS) *</label>
          <input type="number" name="total" class="form-control" required min="0" step="1000" placeholder="0">
        </div>
        <div class="form-group">
          <label>Admin Notes (visible to customer)</label>
          <textarea name="admin_notes" class="form-control" rows="3" placeholder="Pricing breakdown, terms, validity period notes..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" onclick="AtizProm.closeModal('sendQuoteModal')" class="btn" style="border:1px solid var(--border)">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send Quotation</button>
      </div>
    </form>
  </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
<script>
function viewQuote(q) {
  document.getElementById('viewQuoteTitle').textContent = 'Quotation ' + q.quotation_number;
  const items = q.items ? JSON.parse(q.items) : [];
  let itemsHtml = items.length ? items.map(i => `<tr><td>${i.name}</td><td>${i.qty}</td><td>TZS ${Number(i.unit_price).toLocaleString()}</td><td>TZS ${Number(i.total).toLocaleString()}</td></tr>`).join('') : '<tr><td colspan="4" class="text-muted text-center">No itemized list</td></tr>';
  document.getElementById('viewQuoteBody').innerHTML = `
    <p><strong>Title:</strong> ${q.title}</p>
    <p><strong>Description:</strong><br>${q.description || '-'}</p>
    <table class="table mt-2"><thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>${itemsHtml}</tbody></table>
    <p class="mt-2"><strong>Status:</strong> ${q.status}</p>
    ${q.customer_notes ? `<p><strong>Customer Notes:</strong> ${q.customer_notes}</p>` : ''}
  `;
  AtizProm.openModal('viewQuoteModal');
}
function openSendQuote(id, customer) {
  document.getElementById('sq_id').value = id;
  document.getElementById('sq_customer').textContent = customer;
  AtizProm.openModal('sendQuoteModal');
}
</script>
</body>
</html>
