<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$id = (int)($_GET['id'] ?? 0);

if (isPost()) {
    if ($auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $postId = (int)($_POST['contract_id'] ?? $id);
        if (isset($_POST['save_draft'])) {
            $db->execute("UPDATE contracts SET title=?, content=?, value=?, start_date=?, end_date=? WHERE id=?",
                [trim($_POST['title']), $_POST['content'], $_POST['value']?:null, $_POST['start_date']?:null, $_POST['end_date']?:null, $postId]);
            redirect(BASE_URL.'/admin/contracts/view.php?id='.$postId.'&saved=1');
        } elseif (isset($_POST['send_contract'])) {
            $c = $db->fetchOne("SELECT * FROM contracts WHERE id=?", [$postId]);
            $db->execute("UPDATE contracts SET status='sent' WHERE id=?", [$postId]);
            $auth->logAudit($user['id'], 'CONTRACT_SENT', 'contracts', $postId);
            $db->execute("INSERT INTO notifications (user_id,title,message,type,link) VALUES (?,?,?,?,?)",
                [$c['customer_id'], 'Contract Ready for Signature', "Your contract \"{$c['title']}\" (#{$c['contract_number']}) is ready for your review and signature.", 'contract', BASE_URL.'/customer/contracts.php?id='.$postId]);
            redirect(BASE_URL.'/admin/contracts/view.php?id='.$postId.'&sent=1');
        } elseif (isset($_POST['admin_sign'])) {
            $db->execute("UPDATE contracts SET admin_signature=?, admin_signed_at=NOW() WHERE id=?", [trim($_POST['admin_signature']), $postId]);
            // If customer has already signed too, mark fully signed
            $c = $db->fetchOne("SELECT * FROM contracts WHERE id=?", [$postId]);
            if ($c['customer_signature']) {
                $db->execute("UPDATE contracts SET status='signed' WHERE id=?", [$postId]);
            }
            $auth->logAudit($user['id'], 'CONTRACT_ADMIN_SIGNED', 'contracts', $postId);
            redirect(BASE_URL.'/admin/contracts/view.php?id='.$postId.'&signed=1');
        } elseif (isset($_POST['cancel_contract'])) {
            $db->execute("UPDATE contracts SET status='cancelled' WHERE id=?", [$postId]);
            redirect(BASE_URL.'/admin/contracts/view.php?id='.$postId.'&cancelled=1');
        }
    }
}

$contract = $db->fetchOne("SELECT c.*, CONCAT(u.first_name,' ',u.last_name) as customer_name, u.email, b.booking_number, p.project_number FROM contracts c JOIN users u ON c.customer_id=u.id LEFT JOIN bookings b ON c.booking_id=b.id LEFT JOIN projects p ON c.project_id=p.id WHERE c.id=?", [$id]);
if (!$contract) redirect(BASE_URL.'/admin/contracts/');
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contract <?= $contract['contract_number'] ?> – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Contract <?= $contract['contract_number'] ?></div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/contracts/">Contracts</a> <span class="sep">/</span> View</div></div>
    </div>
  </div>
  <div class="content-body" style="max-width:800px">
    <?php if (isset($_GET['saved'])): ?><div class="alert alert-success mb-3">Contract draft saved!</div><?php endif; ?>
    <?php if (isset($_GET['sent'])): ?><div class="alert alert-success mb-3">Contract sent to customer for signature!</div><?php endif; ?>
    <?php if (isset($_GET['signed'])): ?><div class="alert alert-success mb-3">Your signature has been recorded!</div><?php endif; ?>
    <?php if (isset($_GET['cancelled'])): ?><div class="alert alert-success mb-3">Contract cancelled.</div><?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
      <div>
        <p class="text-muted" style="margin:0">Customer: <strong><?= htmlspecialchars($contract['customer_name']) ?></strong> (<?= htmlspecialchars($contract['email']) ?>)</p>
        <p class="text-muted" style="margin:0">Linked to: <?= $contract['booking_number'] ? 'Booking '.$contract['booking_number'] : ($contract['project_number'] ? 'Project '.$contract['project_number'] : 'N/A') ?></p>
      </div>
      <?= getStatusBadge($contract['status']) ?>
    </div>

    <?php if ($contract['status'] === 'draft'): ?>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <input type="hidden" name="save_draft" value="1">
      <input type="hidden" name="contract_id" value="<?= $contract['id'] ?>">
      <div class="card mb-3">
        <div class="card-header"><h4>Edit Contract (Draft)</h4></div>
        <div class="card-body">
          <div class="form-group"><label>Title</label><input type="text" name="title" class="form-control" value="<?= htmlspecialchars($contract['title']) ?>"></div>
          <div class="form-group"><label>Contract Text</label><textarea name="content" class="form-control" rows="14" style="font-family:monospace;font-size:0.85rem"><?= htmlspecialchars($contract['content']) ?></textarea></div>
          <div class="form-row">
            <div class="form-group"><label>Value (TZS)</label><input type="number" name="value" class="form-control" value="<?= $contract['value'] ?>" min="0" step="1000"></div>
            <div class="form-group"><label>Start Date</label><input type="date" name="start_date" class="form-control" value="<?= $contract['start_date'] ?>"></div>
            <div class="form-group"><label>End Date</label><input type="date" name="end_date" class="form-control" value="<?= $contract['end_date'] ?>"></div>
          </div>
        </div>
        <div class="card-footer d-flex justify-content-end gap-2">
          <button type="submit" class="btn" style="border:1px solid var(--border)"><i class="fas fa-save"></i> Save Draft</button>
        </div>
      </div>
    </form>
    <form method="POST" onsubmit="return confirm('Send this contract to the customer for signature? You will not be able to edit the text after this.')">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <input type="hidden" name="send_contract" value="1">
      <input type="hidden" name="contract_id" value="<?= $contract['id'] ?>">
      <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-paper-plane"></i> Send Contract to Customer for Signature</button>
    </form>
    <?php else: ?>
    <div class="card mb-3">
      <div class="card-header"><h4><?= htmlspecialchars($contract['title']) ?></h4></div>
      <div class="card-body" style="white-space:pre-line;font-size:0.92rem;line-height:1.7"><?= htmlspecialchars($contract['content']) ?></div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
      <div class="card">
        <div class="card-header"><h5>Customer Signature</h5></div>
        <div class="card-body">
          <?php if ($contract['customer_signature']): ?>
          <div style="font-family:cursive;font-size:1.3rem;border-bottom:2px solid var(--border);padding-bottom:6px"><?= htmlspecialchars($contract['customer_signature']) ?></div>
          <small class="text-muted">Signed <?= formatDate($contract['customer_signed_at']) ?></small>
          <?php else: ?>
          <p class="text-muted">Awaiting customer signature</p>
          <?php endif; ?>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h5>Atiz Prom Signature</h5></div>
        <div class="card-body">
          <?php if ($contract['admin_signature']): ?>
          <div style="font-family:cursive;font-size:1.3rem;border-bottom:2px solid var(--border);padding-bottom:6px"><?= htmlspecialchars($contract['admin_signature']) ?></div>
          <small class="text-muted">Signed <?= formatDate($contract['admin_signed_at']) ?></small>
          <?php elseif ($contract['status'] !== 'cancelled'): ?>
          <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
            <input type="hidden" name="admin_sign" value="1">
            <input type="hidden" name="contract_id" value="<?= $contract['id'] ?>">
            <input type="text" name="admin_signature" class="form-control mb-2" placeholder="Type full name to sign" required>
            <button type="submit" class="btn btn-sm btn-primary btn-block">Sign as Atiz Prom Representative</button>
          </form>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <?php if (!in_array($contract['status'], ['signed','cancelled'])): ?>
    <form method="POST" class="mt-3" onsubmit="return confirm('Cancel this contract?')">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <input type="hidden" name="cancel_contract" value="1">
      <input type="hidden" name="contract_id" value="<?= $contract['id'] ?>">
      <button type="submit" class="btn" style="border:1px solid #DC3545;color:#DC3545"><i class="fas fa-times"></i> Cancel Contract</button>
    </form>
    <?php endif; ?>
    <?php endif; ?>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
