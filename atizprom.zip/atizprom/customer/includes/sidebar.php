<?php
$currentPage = basename($_SERVER['PHP_SELF']);
$currentDir  = basename(dirname($_SERVER['PHP_SELF']));
?>
<aside class="customer-sidebar" id="custSidebar">
  <div class="customer-sidebar-brand">
    <a href="<?= BASE_URL ?>/customer/" style="display:flex;align-items:center;gap:10px;text-decoration:none">
      <div class="logo-icon"><img src="<?= BASE_URL ?>/assets/images/logo.webp" alt="Atiz Prom Logo"></div>
      <div>
        <strong style="display:block">ATIZ PROM</strong>
        <small><?= t('nav_customer_portal') ?></small>
      </div>
    </a>
  </div>
  <nav class="customer-nav">
    <div class="customer-nav-section"><?= t('sidebar_main') ?></div>
    <a href="<?= BASE_URL ?>/customer/" class="customer-nav-link <?= $currentDir==='customer'&&$currentPage==='index.php'?'active':'' ?>">
      <i class="fas fa-home"></i> <?= t('csidebar_dashboard') ?>
    </a>

    <div class="customer-nav-section"><?= t('csidebar_section_services') ?></div>
    <a href="<?= BASE_URL ?>/customer/services.php" class="customer-nav-link <?= $currentPage==='services.php'?'active':'' ?>">
      <i class="fas fa-concierge-bell"></i> <?= t('csidebar_our_services') ?>
    </a>
    <a href="<?= BASE_URL ?>/customer/booking.php" class="customer-nav-link <?= $currentPage==='booking.php'?'active':'' ?>">
      <i class="fas fa-calendar-plus"></i> <?= t('csidebar_book_service') ?>
    </a>
    <a href="<?= BASE_URL ?>/customer/quotation.php" class="customer-nav-link <?= $currentPage==='quotation.php'?'active':'' ?>">
      <i class="fas fa-file-invoice-dollar"></i> <?= t('quote_request_title') ?>
    </a>

    <div class="customer-nav-section"><?= t('csidebar_section_activity') ?></div>
    <a href="<?= BASE_URL ?>/customer/bookings/" class="customer-nav-link <?= $currentDir==='bookings'?'active':'' ?>">
      <i class="fas fa-calendar-check"></i> <?= t('csidebar_bookings') ?>
    </a>
    <a href="<?= BASE_URL ?>/customer/projects/" class="customer-nav-link <?= $currentDir==='projects'?'active':'' ?>">
      <i class="fas fa-project-diagram"></i> <?= t('csidebar_projects') ?>
    </a>
    <a href="<?= BASE_URL ?>/customer/quotations/" class="customer-nav-link <?= $currentDir==='quotations'?'active':'' ?>">
      <i class="fas fa-file-alt"></i> <?= t('csidebar_quotations') ?>
    </a>
    <a href="<?= BASE_URL ?>/customer/invoices.php" class="customer-nav-link <?= $currentPage==='invoices.php'?'active':'' ?>">
      <i class="fas fa-receipt"></i> <?= t('csidebar_invoices') ?>
    </a>
    <a href="<?= BASE_URL ?>/customer/contracts.php" class="customer-nav-link <?= $currentPage==='contracts.php'?'active':'' ?>">
      <i class="fas fa-file-signature"></i> <?= t('csidebar_contracts') ?>
    </a>

    <div class="customer-nav-section"><?= t('csidebar_section_learning') ?></div>
    <a href="<?= BASE_URL ?>/customer/courses.php" class="customer-nav-link <?= $currentPage==='courses.php'?'active':'' ?>">
      <i class="fas fa-book-open"></i> <?= t('csidebar_browse_courses') ?>
    </a>
    <a href="<?= BASE_URL ?>/customer/my-courses.php" class="customer-nav-link <?= $currentPage==='my-courses.php'?'active':'' ?>">
      <i class="fas fa-graduation-cap"></i> <?= t('csidebar_courses') ?>
    </a>

    <div class="customer-nav-section"><?= t('csidebar_section_catalog') ?></div>
    <a href="<?= BASE_URL ?>/customer/products.php" class="customer-nav-link <?= $currentPage==='products.php'?'active':'' ?>">
      <i class="fas fa-box-open"></i> <?= t('sidebar_product_catalog') ?>
    </a>
    <a href="<?= BASE_URL ?>/customer/portfolio.php" class="customer-nav-link <?= $currentPage==='portfolio.php'?'active':'' ?>">
      <i class="fas fa-images"></i> <?= t('nav_portfolio') ?>
    </a>

    <div class="customer-nav-section"><?= t('csidebar_section_support') ?></div>
    <a href="<?= BASE_URL ?>/customer/tickets/" class="customer-nav-link <?= $currentDir==='tickets'?'active':'' ?>">
      <i class="fas fa-headset"></i> <?= t('sidebar_support_tickets') ?>
    </a>
    <a href="<?= BASE_URL ?>/customer/chat.php" class="customer-nav-link <?= $currentPage==='chat.php'?'active':'' ?>">
      <i class="fas fa-comments"></i> <?= t('csidebar_chat') ?>
    </a>

    <div class="customer-nav-section"><?= t('csidebar_section_account') ?></div>
    <a href="<?= BASE_URL ?>/customer/profile.php" class="customer-nav-link <?= $currentPage==='profile.php'?'active':'' ?>">
      <i class="fas fa-user-circle"></i> <?= t('nav_my_profile') ?>
    </a>
    <a href="<?= BASE_URL ?>/customer/logout.php" class="customer-nav-link" style="color:#DC3545">
      <i class="fas fa-sign-out-alt"></i> <?= t('csidebar_logout') ?>
    </a>
  </nav>
</aside>
