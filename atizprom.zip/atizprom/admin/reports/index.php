<?php
define('BASE_PATH', dirname(dirname(__DIR__)));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$auth->requireLogin(BASE_URL . '/admin/login.php');
$auth->requireRole(['super_admin','admin','finance_officer']);

$db = Database::getInstance();
$user = $auth->getCurrentUser();
$tableName = None;
$rows = [];
if ($tableName) {
    try { $rows = $db->fetchAll("SELECT * FROM `$tableName` ORDER BY id DESC LIMIT 50"); } catch (Exception $e) { $rows = []; }
}
$cols = [];
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reports – Atiz Prom Admin</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="layout-wrapper">
<aside class="sidebar" id="sidebar"><?php include BASE_PATH . '/admin/includes/sidebar.php'; ?></aside>
<div class="main-content" id="mainContent">
  <div class="top-header">
    <div class="header-left">
      <button class="header-icon-btn" id="mobileSidebarToggle"><i class="fas fa-bars"></i></button>
      <div><div class="header-title">Reports</div><div class="header-breadcrumb"><a href="<?= BASE_URL ?>/admin/">Home</a> <span class="sep">/</span> Reports</div></div>
    </div>
  </div>
  <div class="content-body">
    <div class="card">
      <div class="card-body">
        <div class="d-flex align-items-center gap-3 mb-3">
          <div style="width:50px;height:50px;border-radius:14px;background:var(--blue-light);color:var(--blue);display:flex;align-items:center;justify-content:center;font-size:1.4rem"><i class="fas fa-chart-line"></i></div>
          <div><h3 style="margin-bottom:2px">Reports</h3><p class="text-muted" style="margin:0">Revenue, bookings, and performance analytics.</p></div>
        </div>
        <?php if (empty($cols)): ?>
        <div class="text-center" style="padding:50px">
          <i class="fas fa-chart-bar" style="font-size:3rem;color:var(--border);display:block;margin-bottom:16px"></i>
          <h4>Reports Module</h4>
          <p class="text-muted">Detailed revenue and performance reports are available on the main dashboard.</p>
          <a href="<?= BASE_URL ?>/admin/" class="btn btn-primary mt-2">Go to Dashboard</a>
        </div>
        <?php else: ?>
        <div class="table-wrap">
          <table class="table">
            <thead><tr><?php foreach ($cols as $c): ?><th><?= ucwords(str_replace('_',' ',$c)) ?></th><?php endforeach; ?></tr></thead>
            <tbody>
              <?php foreach ($rows as $r): ?>
              <tr><?php foreach ($cols as $c): ?><td><?= htmlspecialchars($r[$c] ?? '-') ?></td><?php endforeach; ?></tr>
              <?php endforeach; ?>
              <?php if (empty($rows)): ?>
              <tr><td colspan="<?= count($cols) ?>" class="text-center text-muted" style="padding:40px">No records yet</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
</div>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
<script src="<?= BASE_URL ?>/assets/js/theme-toggle.js"></script>
<script src="<?= BASE_URL ?>/assets/js/lang-switch.js"></script>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>
