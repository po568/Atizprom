<?php
define('BASE_PATH', dirname(__DIR__));
require_once BASE_PATH . '/includes/bootstrap.php';
$auth = new Auth();
$db = Database::getInstance();
$success = ''; $error = '';

$token = $_GET['token'] ?? ($_POST['token'] ?? '');
$tokenRow = null;
if ($token) {
    $tokenRow = $db->fetchOne("SELECT id, reset_token_expires FROM users WHERE reset_token=?", [$token]);
    if ($tokenRow && strtotime($tokenRow['reset_token_expires']) < time()) {
        $tokenRow = null;
        $error = 'This reset link has expired. Please request a new one.';
    }
}

if (isPost() && $tokenRow) {
    if (!$auth->validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token.';
    } elseif (($_POST['new_password'] ?? '') !== ($_POST['confirm_password'] ?? '')) {
        $error = 'Passwords do not match.';
    } elseif (strlen($_POST['new_password'] ?? '') < 8) {
        $error = 'Password must be at least 8 characters.';
    } else {
        $hashed = password_hash($_POST['new_password'], PASSWORD_BCRYPT, ['cost' => 12]);
        $db->execute("UPDATE users SET password=?, reset_token=NULL, reset_token_expires=NULL WHERE id=?", [$hashed, $tokenRow['id']]);
        $auth->logAudit($tokenRow['id'], 'PASSWORD_RESET', 'users', $tokenRow['id']);
        $success = 'Your password has been reset successfully. You can now log in.';
        $tokenRow = null; // prevent re-submission
    }
}
?>
<!DOCTYPE html>
<html lang="en" <?= themeAttr() ?>>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reset Password – Atiz Prom</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/main.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>body{background:linear-gradient(135deg,var(--dark-2),var(--dark-3));min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.auth-box{background:#fff;border-radius:20px;max-width:440px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,0.4);overflow:hidden}
.auth-header{background:linear-gradient(135deg,var(--blue),var(--blue-dark));padding:28px;text-align:center}
.auth-header h2{color:#fff;margin-bottom:4px}.auth-header p{color:rgba(255,255,255,0.7);margin:0;font-size:0.85rem}
.auth-body{padding:32px}</style>
</head>
<body>
<div class="auth-box">
  <div class="auth-header">
    <i class="fas fa-lock" style="font-size:2rem;color:#fff;margin-bottom:10px;display:block"></i>
    <h2>Reset Your Password</h2>
    <p>Choose a new, secure password</p>
  </div>
  <div class="auth-body">
    <?php if ($success): ?>
    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
    <a href="<?= BASE_URL ?>/customer/login.php" class="btn btn-primary btn-block mt-2">Go to Login</a>
    <?php elseif (!$tokenRow): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error ?: 'Invalid or expired reset link.') ?></div>
    <a href="<?= BASE_URL ?>/customer/forgot-password.php" class="btn btn-primary btn-block mt-2">Request New Link</a>
    <?php else: ?>
    <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= $auth->getCSRFToken() ?>">
      <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
      <div class="form-group">
        <label>New Password *</label>
        <input type="password" name="new_password" class="form-control" required minlength="8" placeholder="Min 8 characters">
      </div>
      <div class="form-group">
        <label>Confirm New Password *</label>
        <input type="password" name="confirm_password" class="form-control" required minlength="8" placeholder="Repeat new password">
      </div>
      <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-key"></i> Reset Password</button>
    </form>
    <?php endif; ?>
    <p class="text-center mt-3"><a href="<?= BASE_URL ?>/customer/login.php" style="font-size:0.85rem"><i class="fas fa-arrow-left"></i> Back to Login</a></p>
  </div>
</div>
</body>
</html>
